# hydra

![Version: 0.1.2](https://img.shields.io/badge/Version-0.1.2-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: v26.2.0](https://img.shields.io/badge/AppVersion-v26.2.0-informational?style=flat-square)

## Prerequisites

- Helm v3
- Config Connector installed (v1.6.0)

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| https://k8s.ory.sh/helm/charts | hydra(hydra) | 0.63.0 |

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| hamzatalbi | <hamzatalbi831@gmail.com> | <https://github.com/TalbiHamza> |

## Description

A Helm chart for Kubernetes

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| hydra.affinity | object | `{}` |  |
| hydra.configmap.hashSumEnabled | bool | `true` | switch to false to prevent checksum annotations being maintained and propogated to the pods |
| hydra.cronjob.janitor.affinity | object | `{}` | Configure node affinity |
| hydra.cronjob.janitor.annotations | object | `{}` | Set custom cron job level annotations |
| hydra.cronjob.janitor.automountServiceAccountToken | bool | `true` | Set automounting of the SA token in job's pod |
| hydra.cronjob.janitor.customArgs | list | `[]` | Configure the arguments of the entrypoint, overriding the default value |
| hydra.cronjob.janitor.customCommand | list | `[]` | Configure a custom entrypoint, overriding the default value |
| hydra.cronjob.janitor.extraContainers | string | `""` | If you want to add extra sidecar containers. |
| hydra.cronjob.janitor.extraEnv | list | `[]` | Array of extra envs to be passed to the cronjob. This takes precedence over deployment variables. Kubernetes format is expected. Value is processed with Helm `tpl` - name: FOO   value: BAR |
| hydra.cronjob.janitor.extraInitContainers | string | `""` | If you want to add extra init containers. These are processed before the migration init container. |
| hydra.cronjob.janitor.extraVolumeMounts | list | `[]` |  |
| hydra.cronjob.janitor.extraVolumes | list | `[]` | If you want to mount external volume |
| hydra.cronjob.janitor.labels | object | `{}` | Set custom cron job level labels |
| hydra.cronjob.janitor.nodeSelector | object | `{}` | Configure node labels for pod assignment |
| hydra.cronjob.janitor.podMetadata | object | `{"annotations":{},"labels":{}}` | Specify pod metadata, this metadata is added directly to the pod, and not higher objects |
| hydra.cronjob.janitor.podMetadata.annotations | object | `{}` | Extra pod level annotations |
| hydra.cronjob.janitor.podMetadata.labels | object | `{}` | Extra pod level labels |
| hydra.cronjob.janitor.podSecurityContext | object | `{}` |  |
| hydra.cronjob.janitor.resources | object | `{"limits":{},"requests":{}}` | We usually recommend not to specify default resources and to leave this as a conscious choice for the user.  This also increases chances charts run on environments with little  resources, such as Minikube. If you do want to specify resources, uncomment the following  lines, adjust them as necessary, and remove the curly braces after 'resources:'.  limits:    cpu: 100m    memory: 128Mi  requests:    cpu: 100m  memory: 128Mi |
| hydra.cronjob.janitor.schedule | string | `"0 */1 * * *"` | Configure how often the cron job is ran |
| hydra.cronjob.janitor.securityContext | object | `{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]},"privileged":false,"readOnlyRootFilesystem":true,"runAsNonRoot":true,"runAsUser":100}` | Configure the containers' SecurityContext for the janitor cronjob |
| hydra.cronjob.janitor.serviceAccount | object | `{"annotations":{"helm.sh/hook":"pre-install, pre-upgrade","helm.sh/hook-delete-policy":"before-hook-creation","helm.sh/hook-weight":"0"},"automountServiceAccountToken":true,"create":true,"name":""}` | Specify the serviceAccountName value. In some situations it is needed to provides specific permissions to Hydra deployments Like for example installing Hydra on a cluster with a PosSecurityPolicy and Istio. Uncoment if it is needed to provide a ServiceAccount for the Hydra deployment. |
| hydra.cronjob.janitor.serviceAccount.annotations | object | `{"helm.sh/hook":"pre-install, pre-upgrade","helm.sh/hook-delete-policy":"before-hook-creation","helm.sh/hook-weight":"0"}` | Annotations to add to the service account |
| hydra.cronjob.janitor.serviceAccount.automountServiceAccountToken | bool | `true` | Set automounting of the SA token |
| hydra.cronjob.janitor.serviceAccount.create | bool | `true` | Specifies whether a service account should be created |
| hydra.cronjob.janitor.serviceAccount.name | string | `""` | The name of the service account to use. If not set and create is true, a name is generated using the fullname template |
| hydra.cronjob.janitor.shareProcessNamespace | bool | `false` | Set sharing process namespace |
| hydra.cronjob.janitor.tolerations | list | `[]` | Configure node tolerations |
| hydra.deployment.annotations | object | `{}` | Set custom deployment level annotations |
| hydra.deployment.automigration | object | `{"extraEnv":[]}` | Parameters for the automigration initContainer |
| hydra.deployment.automigration.extraEnv | list | `[]` | Array of extra envs to be passed to the initContainer. Kubernetes format is expected. Value is processed with Helm `tpl` - name: FOO   value: BAR |
| hydra.deployment.automountServiceAccountToken | bool | `false` |  |
| hydra.deployment.autoscaling | object | `{"behavior":{},"enabled":false,"extraMetrics":[],"maxReplicas":3,"minReplicas":1,"targetCPU":{},"targetMemory":{}}` | Configure HPA |
| hydra.deployment.autoscaling.behavior | object | `{}` | Set custom behavior https://kubernetes.io/docs/tasks/run-application/horizontal-pod-autoscale/#configurable-scaling-behavior |
| hydra.deployment.autoscaling.extraMetrics | list | `[]` | Add extraContainer container resource metrics https://kubernetes.io/docs/tasks/run-application/horizontal-pod-autoscale/#container-resource-metrics |
| hydra.deployment.customLivenessProbe | object | `{}` | Configure a custom livenessProbe. This overwrites the default object |
| hydra.deployment.customReadinessProbe | object | `{}` | Configure a custom readinessProbe. This overwrites the default object |
| hydra.deployment.customStartupProbe | object | `{}` | Configure a custom startupProbe. This overwrites the default object |
| hydra.deployment.dnsConfig | object | `{}` | Configure pod dnsConfig. |
| hydra.deployment.extraContainers | string | `""` | If you want to add extra sidecar containers. |
| hydra.deployment.extraEnv | list | `[]` | Array of extra envs to be passed to the deployment. Kubernetes format is expected. Value is processed with Helm `tpl` - name: FOO   value: BAR |
| hydra.deployment.extraInitContainers | string | `""` | If you want to add extra init containers. These are processed before the migration init container. |
| hydra.deployment.extraVolumeMounts | list | `[]` |  |
| hydra.deployment.extraVolumes | list | `[]` | If you want to mount external volume |
| hydra.deployment.initContainerSecurityContext | object | `{}` |  |
| hydra.deployment.labels | object | `{}` | Set custom deployment level labels |
| hydra.deployment.lifecycle | object | `{}` |  |
| hydra.deployment.nodeSelector | object | `{}` | Node labels for pod assignment. |
| hydra.deployment.podMetadata | object | `{"annotations":{},"labels":{}}` | Specify pod metadata, this metadata is added directly to the pod, and not higher objects |
| hydra.deployment.podMetadata.annotations | object | `{}` | Extra pod level annotations |
| hydra.deployment.podMetadata.labels | object | `{}` | Extra pod level labels |
| hydra.deployment.podSecurityContext.fsGroup | int | `65534` |  |
| hydra.deployment.podSecurityContext.fsGroupChangePolicy | string | `"OnRootMismatch"` |  |
| hydra.deployment.podSecurityContext.runAsGroup | int | `65534` |  |
| hydra.deployment.podSecurityContext.runAsNonRoot | bool | `true` |  |
| hydra.deployment.podSecurityContext.runAsUser | int | `65534` |  |
| hydra.deployment.podSecurityContext.seccompProfile.type | string | `"RuntimeDefault"` |  |
| hydra.deployment.readinessProbe | object | `{"failureThreshold":5,"initialDelaySeconds":5,"periodSeconds":10}` | Default probe timers |
| hydra.deployment.resources | object | `{}` | We usually recommend not to specify default resources and to leave this as a conscious choice for the user.  This also increases chances charts run on environments with little  resources, such as Minikube. If you do want to specify resources, uncomment the following  lines, adjust them as necessary, and remove the curly braces after 'resources:'.  limits:    cpu: 100m    memory: 128Mi  requests:    cpu: 100m  memory: 128Mi |
| hydra.deployment.revisionHistoryLimit | int | `5` | Number of revisions kept in history |
| hydra.deployment.securityContext.allowPrivilegeEscalation | bool | `false` |  |
| hydra.deployment.securityContext.capabilities.drop[0] | string | `"ALL"` |  |
| hydra.deployment.securityContext.privileged | bool | `false` |  |
| hydra.deployment.securityContext.readOnlyRootFilesystem | bool | `true` |  |
| hydra.deployment.securityContext.runAsGroup | int | `65534` |  |
| hydra.deployment.securityContext.runAsNonRoot | bool | `true` |  |
| hydra.deployment.securityContext.runAsUser | int | `65534` |  |
| hydra.deployment.securityContext.seLinuxOptions.level | string | `"s0:c123,c456"` |  |
| hydra.deployment.securityContext.seccompProfile.type | string | `"RuntimeDefault"` |  |
| hydra.deployment.serviceAccount | object | `{"annotations":{},"create":true,"name":""}` | Specify the serviceAccountName value. In some situations it is needed to provides specific permissions to Hydra deployments Like for example installing Hydra on a cluster with a PosSecurityPolicy and Istio. Uncoment if it is needed to provide a ServiceAccount for the Hydra deployment. |
| hydra.deployment.serviceAccount.annotations | object | `{}` | Annotations to add to the service account |
| hydra.deployment.serviceAccount.create | bool | `true` | Specifies whether a service account should be created |
| hydra.deployment.serviceAccount.name | string | `""` | The name of the service account to use. If not set and create is true, a name is generated using the fullname template |
| hydra.deployment.startupProbe | object | `{"failureThreshold":5,"initialDelaySeconds":1,"periodSeconds":1,"successThreshold":1,"timeoutSeconds":2}` | Default probe timers |
| hydra.deployment.strategy.rollingUpdate.maxSurge | string | `"25%"` |  |
| hydra.deployment.strategy.rollingUpdate.maxUnavailable | string | `"25%"` |  |
| hydra.deployment.strategy.type | string | `"RollingUpdate"` |  |
| hydra.deployment.terminationGracePeriodSeconds | int | `60` |  |
| hydra.deployment.tolerations | list | `[]` | Configure node tolerations. |
| hydra.deployment.topologySpreadConstraints | list | `[]` | Configure pod topologySpreadConstraints. |
| hydra.fullnameOverride | string | `""` | Full chart name override |
| hydra.global | object | `{"imageRegistry":null,"podMetadata":{"annotations":{},"labels":{}}}` | Global setting, passed down to all pods |
| hydra.global.imageRegistry | string | `nil` | Overrides the Docker registry globally for all images |
| hydra.global.podMetadata | object | `{"annotations":{},"labels":{}}` | Specify pod metadata, this metadata is added directly to the pod, and not higher objects |
| hydra.global.podMetadata.annotations | object | `{}` | Extra pod level annotations |
| hydra.global.podMetadata.labels | object | `{}` | Extra pod level labels |
| hydra.hydra-maester.adminService.name | string | `""` | The service name value may need to be set if you use `fullnameOverride` for the parent chart |
| hydra.hydra.automigration.customArgs | list | `[]` | Ability to override arguments of the entrypoint. Can be used in-depended of customCommand eg: - sleep 5;   - kratos |
| hydra.hydra.automigration.customCommand | list | `[]` | Ability to override the entrypoint of the automigration container (e.g. to source dynamic secrets or export environment dynamic variables) |
| hydra.hydra.automigration.enabled | bool | `false` |  |
| hydra.hydra.automigration.resources | object | `{}` | resource requests and limits for the automigration initcontainer |
| hydra.hydra.automigration.type | string | `"job"` | Configure the way to execute database migration. Possible values: job, initContainer When set to job, the migration will be executed as a job on release or upgrade. When set to initContainer, the migration will be executed when kratos pod is created Defaults to job |
| hydra.hydra.command | list | `["hydra"]` | Ability to override the entrypoint of hydra container (e.g. to source dynamic secrets or export environment dynamic variables) |
| hydra.hydra.config | object | `{"secrets":{},"serve":{"admin":{"port":4445},"public":{"port":4444},"tls":{"allow_termination_from":["10.0.0.0/8","172.16.0.0/12","192.168.0.0/16"]}},"urls":{"self":{}}}` | The ORY Hydra configuration. For a full list of available settings, check:  https://www.ory.sh/docs/hydra/reference/configuration |
| hydra.hydra.config.secrets | object | `{}` | The secrets have to be provided as a string slice, example: system:   - "OG5XbmxXa3dYeGplQXpQanYxeEFuRUFa"   - "foo bar 123 456 lorem"   - "foo bar 123 456 lorem 1"   - "foo bar 123 456 lorem 2"   - "foo bar 123 456 lorem 3" |
| hydra.hydra.config.urls | object | `{"self":{}}` | Configure the urls used by hydra itself, such as the issuer. Note: some values are required for hydra to start, please refer to https://www.ory.sh/docs/hydra/self-hosted/kubernetes-helm-chart self:   issuer: "https://public.hydra.localhost:4444/" |
| hydra.hydra.customArgs | list | `[]` | Ability to override arguments of the entrypoint. Can be used in-depended of customCommand |
| hydra.hydra.customMigrations.jobs.oel-postgresql-ttl.customArgs[0] | string | `"migrate"` |  |
| hydra.hydra.customMigrations.jobs.oel-postgresql-ttl.customArgs[1] | string | `"postgresql-addons"` |  |
| hydra.hydra.customMigrations.jobs.oel-postgresql-ttl.customArgs[2] | string | `"up"` |  |
| hydra.hydra.customMigrations.jobs.oel-postgresql-ttl.customArgs[3] | string | `"--hydra-db-name"` |  |
| hydra.hydra.customMigrations.jobs.oel-postgresql-ttl.customArgs[4] | string | `"ory_hydra"` |  |
| hydra.hydra.customMigrations.jobs.oel-postgresql-ttl.customArgs[5] | string | `"--pgcron-db-name"` |  |
| hydra.hydra.customMigrations.jobs.oel-postgresql-ttl.customArgs[6] | string | `"postgres"` |  |
| hydra.hydra.customMigrations.jobs.oel-postgresql-ttl.enabled | bool | `false` |  |
| hydra.hydra.customMigrations.jobs.oel-postgresql-ttl.extraEnv | list | `[]` |  |
| hydra.hydra.customMigrations.jobs.oel-postgresql-ttl.nodeSelector | object | `{}` |  |
| hydra.hydra.customMigrations.jobs.oel-postgresql-ttl.resources | object | `{}` |  |
| hydra.hydra.dev | bool | `false` | Enable dev mode, not secure in production environments |
| hydra.image.pullPolicy | string | `"IfNotPresent"` | Image pull policy |
| hydra.image.registry | string | `"docker.io"` | ORY Hydra image registry |
| hydra.image.repository | string | `"oryd/hydra"` | ORY Hydra image |
| hydra.image.tag | string | `"v26.2.0"` | ORY Hydra version |
| hydra.imagePullSecrets | list | `[]` | Image pull secrets |
| hydra.ingress.admin.annotations | object | `{}` |  |
| hydra.ingress.admin.className | string | `""` |  |
| hydra.ingress.admin.enabled | bool | `false` | En-/Disable the api ingress. |
| hydra.ingress.admin.hosts[0].host | string | `"admin.hydra.localhost"` |  |
| hydra.ingress.admin.hosts[0].paths[0].path | string | `"/"` |  |
| hydra.ingress.admin.hosts[0].paths[0].pathType | string | `"ImplementationSpecific"` |  |
| hydra.ingress.public | object | `{"annotations":{},"className":"","enabled":false,"hosts":[{"host":"public.hydra.localhost","paths":[{"path":"/","pathType":"ImplementationSpecific"}]}]}` | Configure ingress for the proxy port. |
| hydra.ingress.public.enabled | bool | `false` | En-/Disable the proxy ingress. |
| hydra.janitor.batchSize | int | `100` | Configure how many records are deleted with each iteration |
| hydra.janitor.cleanupGrants | bool | `false` | Configure if the trust relationships must be cleaned up |
| hydra.janitor.cleanupRequests | bool | `false` | Configure if the consent and authentication requests must be cleaned up |
| hydra.janitor.cleanupTokens | bool | `false` | Configure if the access and refresh tokens must be cleaned up |
| hydra.janitor.enabled | bool | `false` | Enable cleanup of stale database rows by periodically running the janitor command |
| hydra.janitor.limit | int | `10000` | Configure how many records are retrieved from database for deletion |
| hydra.job.annotations | object | `{"helm.sh/hook":"pre-install, pre-upgrade","helm.sh/hook-delete-policy":"before-hook-creation","helm.sh/hook-weight":"1"}` | If you do want to specify annotations, uncomment the following lines, adjust them as necessary, and remove the curly braces after 'annotations:'. |
| hydra.job.automountServiceAccountToken | bool | `true` | Set automounting of the SA token |
| hydra.job.extraContainers | string | `""` | If you want to add extra sidecar containers. |
| hydra.job.extraEnv | list | `[]` | Array of extra envs to be passed to the job. This takes precedence over deployment variables. Kubernetes format is expected. Value is processed with Helm `tpl` - name: FOO   value: BAR |
| hydra.job.extraInitContainers | string | `""` | If you want to add extra init containers. extraInitContainers: |  - name: ...    image: ... |
| hydra.job.extraVolumeMounts | list | `[]` | Array of extra volume mounts to be mounted on the job. This takes precedence over `deployment.extraVolumeMounts` when set, otherwise the deployment's volume mounts are used. |
| hydra.job.extraVolumes | list | `[]` | Array of extra volumes to be mounted on the job. This takes precedence over `deployment.extraVolumes` when set, otherwise the deployment's volumes are used. |
| hydra.job.labels | object | `{}` | Set custom deployment level labels |
| hydra.job.lifecycle | string | `""` | If you want to add lifecycle hooks. |
| hydra.job.nodeSelector | object | `{}` | Node labels for pod assignment. |
| hydra.job.podMetadata | object | `{"annotations":{},"labels":{}}` | Specify pod metadata, this metadata is added directly to the pod, and not higher objects |
| hydra.job.podMetadata.annotations | object | `{}` | Extra pod level annotations |
| hydra.job.podMetadata.labels | object | `{}` | Extra pod level labels |
| hydra.job.resources | object | `{}` | resource requests and limits for the automigration job |
| hydra.job.serviceAccount | object | `{"annotations":{"helm.sh/hook":"pre-install, pre-upgrade","helm.sh/hook-delete-policy":"before-hook-creation","helm.sh/hook-weight":"0"},"create":true,"name":""}` | Specify the serviceAccountName value. In some situations it is needed to provides specific permissions to Hydra deployments Like for example installing Hydra on a cluster with a PosSecurityPolicy and Istio. Uncoment if it is needed to provide a ServiceAccount for the Hydra deployment. |
| hydra.job.serviceAccount.annotations | object | `{"helm.sh/hook":"pre-install, pre-upgrade","helm.sh/hook-delete-policy":"before-hook-creation","helm.sh/hook-weight":"0"}` | Annotations to add to the service account |
| hydra.job.serviceAccount.create | bool | `true` | Specifies whether a service account should be created |
| hydra.job.serviceAccount.name | string | `""` | The name of the service account to use. If not set and create is true, a name is generated using the fullname template |
| hydra.job.shareProcessNamespace | bool | `false` | Set sharing process namespace |
| hydra.job.spec.backoffLimit | int | `10` | Set job back off limit |
| hydra.job.tolerations | list | `[]` | Configure node tolerations. |
| hydra.maester.enabled | bool | `true` |  |
| hydra.nameOverride | string | `""` |  |
| hydra.pdb.enabled | bool | `false` |  |
| hydra.pdb.spec.maxUnavailable | string | `""` |  |
| hydra.pdb.spec.minAvailable | string | `""` |  |
| hydra.priorityClassName | string | `""` | Pod priority https://kubernetes.io/docs/concepts/configuration/pod-priority-preemption/ |
| hydra.replicaCount | int | `1` | Number of ORY Hydra members |
| hydra.secret.enableDefaultAnnotations | bool | `true` | enableDefaultAnnotations set to `true` will add default annotations to the secret. As such the Secret will be managed by helm hooks. |
| hydra.secret.enabled | bool | `true` | switch to false to prevent creating the secret |
| hydra.secret.extraAnnotations | object | `{}` | extraAnnotations to be added to secret. |
| hydra.secret.hashSumEnabled | bool | `true` | switch to false to prevent checksum annotations being maintained and propogated to the pods |
| hydra.secret.nameOverride | string | `""` | Provide custom name of existing secret, or custom name of secret to be created |
| hydra.secret.secretAnnotations | object | `{"helm.sh/hook":"pre-install, pre-upgrade","helm.sh/hook-delete-policy":"before-hook-creation","helm.sh/hook-weight":"0","helm.sh/resource-policy":"keep"}` | Annotations to be added to secret. Annotations are added only when secret is being created. Existing secret will not be modified. |
| hydra.service.admin | object | `{"annotations":{},"enabled":true,"externalTrafficPolicy":"","internalTrafficPolicy":"","labels":{},"loadBalancerIP":"","metricsPath":"/admin/metrics/prometheus","name":"http","port":4445,"type":"ClusterIP"}` | Configures the Kubernetes service for the api port. |
| hydra.service.admin.annotations | object | `{}` | If you do want to specify annotations, uncomment the following lines, adjust them as necessary, and remove the curly braces after 'annotations:'. |
| hydra.service.admin.enabled | bool | `true` | En-/disable the service |
| hydra.service.admin.externalTrafficPolicy | string | `""` | https://kubernetes.io/docs/reference/networking/virtual-ips/#traffic-policies |
| hydra.service.admin.internalTrafficPolicy | string | `""` | https://kubernetes.io/docs/reference/networking/virtual-ips/#traffic-policies |
| hydra.service.admin.loadBalancerIP | string | `""` | The load balancer IP |
| hydra.service.admin.metricsPath | string | `"/admin/metrics/prometheus"` | Path to the metrics endpoint |
| hydra.service.admin.name | string | `"http"` | The service port name. Useful to set a custom service port name if it must follow a scheme (e.g. Istio) |
| hydra.service.admin.port | int | `4445` | The service port |
| hydra.service.admin.type | string | `"ClusterIP"` | The service type |
| hydra.service.public | object | `{"annotations":{},"enabled":true,"externalTrafficPolicy":"","internalTrafficPolicy":"","labels":{},"loadBalancerIP":"","name":"http","port":4444,"type":"ClusterIP"}` | Configures the Kubernetes service for the proxy port. |
| hydra.service.public.annotations | object | `{}` | If you do want to specify annotations, uncomment the following lines, adjust them as necessary, and remove the curly braces after 'annotations:'. |
| hydra.service.public.enabled | bool | `true` | En-/disable the service |
| hydra.service.public.externalTrafficPolicy | string | `""` | https://kubernetes.io/docs/reference/networking/virtual-ips/#traffic-policies |
| hydra.service.public.internalTrafficPolicy | string | `""` | https://kubernetes.io/docs/reference/networking/virtual-ips/#traffic-policies |
| hydra.service.public.loadBalancerIP | string | `""` | The load balancer IP |
| hydra.service.public.name | string | `"http"` | The service port name. Useful to set a custom service port name if it must follow a scheme (e.g. Istio) |
| hydra.service.public.port | int | `4444` | The service port |
| hydra.service.public.type | string | `"ClusterIP"` | The service type |
| hydra.serviceMonitor.enabled | bool | `false` | switch to true to enable creating the ServiceMonitor |
| hydra.serviceMonitor.labels | object | `{}` | Provide additionnal labels to the ServiceMonitor ressource metadata |
| hydra.serviceMonitor.metricRelabelings | list | `[]` | Metric relabeling is applied to samples as the last step before ingestion. Reference: https://prometheus.io/docs/prometheus/latest/configuration/configuration/#metric_relabel_configs |
| hydra.serviceMonitor.relabelings | list | `[]` | Relabeling is a powerful tool to dynamically rewrite the label set of a target before it gets scraped. Reference: https://prometheus.io/docs/prometheus/latest/configuration/configuration/#relabel_config |
| hydra.serviceMonitor.scheme | string | `"http"` | HTTP scheme to use for scraping. |
| hydra.serviceMonitor.scrapeInterval | string | `"60s"` | Interval at which metrics should be scraped |
| hydra.serviceMonitor.scrapeTimeout | string | `"30s"` | Timeout after which the scrape is ended |
| hydra.serviceMonitor.targetLabels | list | `[]` | Additional metric labels |
| hydra.serviceMonitor.tlsConfig | object | `{}` | TLS configuration to use when scraping the endpoint |
| hydra.test.busybox | object | `{"registry":"docker.io","repository":"busybox","tag":"stable"}` | use a busybox image from another repository |
| hydra.test.labels | object | `{}` | Provide additional labels to the test pod |
| hydra.watcher.automountServiceAccountToken | bool | `true` |  |
| hydra.watcher.enabled | bool | `false` |  |
| hydra.watcher.image | string | `"oryd/k8s-toolbox:v0.0.10"` |  |
| hydra.watcher.mountFile | string | `""` | Path to mounted file, which wil be monitored for changes. eg: /etc/secrets/my-secret/foo |
| hydra.watcher.podMetadata | object | `{"annotations":{},"labels":{}}` | Specify pod metadata, this metadata is added directly to the pod, and not higher objects |
| hydra.watcher.podMetadata.annotations | object | `{}` | Extra pod level annotations |
| hydra.watcher.podMetadata.labels | object | `{}` | Extra pod level labels |
| hydra.watcher.podSecurityContext | object | `{}` | pod securityContext for watcher deployment |
| hydra.watcher.resources | object | `{}` |  |
| hydra.watcher.revisionHistoryLimit | int | `5` | Number of revisions kept in history |
| hydra.watcher.securityContext | object | `{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]},"privileged":false,"readOnlyRootFilesystem":true,"runAsNonRoot":true,"runAsUser":100,"seccompProfile":{"type":"RuntimeDefault"}}` | container securityContext for watcher deployment |
| hydra.watcher.watchLabelKey | string | `"ory.sh/watcher"` | Label key used for managing applications |
| prometheus.enabled | bool | `false` | Enables Prometheus Operator monitoring |
| prometheus.grafanaDashboard.enabled | bool | `true` | Add grafana dashboard as a configmap |
| prometheus.grafanaDashboard.label | object | `{"grafana_dashboard":"1"}` | label to apply to the config map. Used by Grafana sidecar to automatically install the dashboard |
| prometheus.rules.enabled | bool | `true` | Enables prometheus operator rules |
| prometheus.rules.labels | object | `{"prometheus":"prometheus-operator-prometheus"}` | Labels to affect to the Prometheus Rules |

## Installing the Chart

### With Helm

To install the chart with the release name `my-release`:

```bash
helm repo add ekp-helm https://edixos.github.io/ekp-helm
helm install ekp-helm/hydra
```

### With ArgoCD

Add new application as:

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: hydra
spec:
  project: infra

  source:
    repoURL: "https://edixos.github.io/ekp-helm"
    targetRevision: "0.1.2"
    chart: hydra
    path: ''
    helm:
      values: |

  destination:
    server: https://kubernetes.default.svc
    namespace: "cnrm-system"
  syncPolicy:
    automated:
      prune: true
```

## Develop

### Update documentation

Chart documentation is generated with [helm-docs](https://github.com/norwoodj/helm-docs) from `values.yaml` file.
After file modification, regenerate README.md with command:

```bash
docker run --rm -it -v $(pwd):/helm --workdir /helm jnorwood/helm-docs:v1.14.2 helm-docs
```

### Run linter

```bash
docker run --rm -it -w /charts -v $(pwd)/../../:/charts quay.io/helmpack/chart-testing:v3.12.0 ct lint --charts /charts/charts/hydra --config /charts/charts/hydra/ct.yaml
```

### Run pluto

In order to check if the api-version used in this chart are not deprecated, or worse, removed, we use pluto to check it:

```
docker run --rm -it -v $(pwd):/apps -v pluto:/pluto alpine/helm:3.17 template hydra . -f tests/pluto/values.yaml --output-dir /pluto
docker run --rm -it -v pluto:/data us-docker.pkg.dev/fairwinds-ops/oss/pluto:v5 detect-files -d /data -o yaml --ignore-deprecations -t "k8s=v1.31.0,cert-manager=v1.17.0,istio=v1.24.0" -o wide
docker volume rm pluto
```

