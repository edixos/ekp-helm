# eso

![Version: 0.2.3](https://img.shields.io/badge/Version-0.2.3-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: v2.11.0](https://img.shields.io/badge/AppVersion-v2.11.0-informational?style=flat-square)

## Prerequisites

- Helm v3
- Config Connector installed (v1.6.0)

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| https://charts.external-secrets.io | eso(external-secrets) | 2.11.0 |

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| wiemaouadi | <wiem.aouadi3@gmail.com> | <https://github.com/wiemaouadi> |
| smileisak | <ikaboubi@gmail.com> | <https://github.com/smileisak> |

## Description

A Helm chart ESO for Kubernetes

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| clusterSecretStores | list | `[]` | List of ClusterSecretStore resources to create alongside ESO. Each entry requires a `name` and a `spec` block (provider-agnostic). Example (Scaleway): clusterSecretStores:   - name: scaleway-secret-manager     spec:       provider:         scaleway:           region: fr-par           projectId: <project-id>           accessKey:             secretRef:               name: scaleway-secret               key: SCW_ACCESS_KEY               namespace: kube-system           secretKey:             secretRef:               name: scaleway-secret               key: SCW_SECRET_KEY               namespace: kube-system |
| eso.affinity | object | `{}` |  |
| eso.bitwarden-sdk-server.enabled | bool | `false` |  |
| eso.bitwarden-sdk-server.namespaceOverride | string | `""` |  |
| eso.certController.affinity | object | `{}` |  |
| eso.certController.create | bool | `true` | Specifies whether a certificate controller deployment be created. |
| eso.certController.deploymentAnnotations | object | `{}` | Annotations to add to Deployment |
| eso.certController.enablePartialCache | bool | `true` | Restrict the cert controller's informer cache to CustomResourceDefinitions and ValidatingWebhookConfigurations carrying the `external-secrets.io/component` label. Disable this only if the CRDs it manages were installed without that label. |
| eso.certController.extraArgs | object | `{}` |  |
| eso.certController.extraEnv | list | `[]` |  |
| eso.certController.extraInitContainers | list | `[]` |  |
| eso.certController.extraVolumeMounts | list | `[]` |  |
| eso.certController.extraVolumes | list | `[]` |  |
| eso.certController.hostAliases | list | `[]` | Specifies `hostAliases` to cert-controller deployment |
| eso.certController.hostNetwork | bool | `false` | Run the certController on the host network |
| eso.certController.hostUsers | bool | `nil` | Specifies if certController pod should use hostUsers or not. If hostNetwork is true, hostUsers should be too. Only available in Kubernetes ≥ 1.33. @schema type: [boolean, null] |
| eso.certController.image.flavour | string | `""` |  |
| eso.certController.image.pullPolicy | string | `"IfNotPresent"` |  |
| eso.certController.image.repository | string | `"ghcr.io/external-secrets/external-secrets"` |  |
| eso.certController.image.tag | string | `""` |  |
| eso.certController.imagePullSecrets | list | `[]` |  |
| eso.certController.livenessProbe.enabled | bool | `false` |  |
| eso.certController.livenessProbe.failureThreshold | int | `5` |  |
| eso.certController.livenessProbe.initialDelaySeconds | int | `10` |  |
| eso.certController.livenessProbe.periodSeconds | int | `10` |  |
| eso.certController.livenessProbe.port | int | `8081` | Set this value to 'live' (for named port) or an integer for liveness probes. @schema type: [string, integer] |
| eso.certController.livenessProbe.successThreshold | int | `1` |  |
| eso.certController.livenessProbe.timeoutSeconds | int | `5` |  |
| eso.certController.log | object | `{"level":"info","timeEncoding":"epoch"}` | Specifies Log Params to the Certificate Controller |
| eso.certController.metrics.listen.auth.enabled | bool | `false` | Enable Kubernetes RBAC-based authentication for certController's metrics endpoint. Requires certController.metrics.listen.secure to be true. Default value is false. |
| eso.certController.metrics.listen.port | int | `8080` |  |
| eso.certController.metrics.listen.secure.certDir | string | `"/etc/tls"` | TLS cert directory path |
| eso.certController.metrics.listen.secure.certFile | string | `"/etc/tls/tls.crt"` | TLS cert file path |
| eso.certController.metrics.listen.secure.enabled | bool | `false` |  |
| eso.certController.metrics.listen.secure.keyFile | string | `"/etc/tls/tls.key"` | TLS key file path |
| eso.certController.metrics.service.annotations | object | `{}` | Additional service annotations |
| eso.certController.metrics.service.enabled | bool | `false` | Enable if you use another monitoring tool than Prometheus to scrape the metrics |
| eso.certController.metrics.service.port | int | `8080` | Metrics service port to scrape |
| eso.certController.networkPolicy | object | `{"egress":[],"enabled":false,"ingress":[{"ports":[{"port":8080,"protocol":"TCP"},{"port":8081,"protocol":"TCP"}]}]}` | Setup a networkPolicy for external-secrets certController |
| eso.certController.networkPolicy.egress | list | `[]` | The egress traffic The minimum egress ports required to function are:   DNS (53/udp, 53/tcp)   API server (80/tcp, 443/tcp, or 6443/tcp) You will need to customize this value to meet your needs |
| eso.certController.networkPolicy.enabled | bool | `false` | Specifies whether the networkPolicy should be created. |
| eso.certController.networkPolicy.ingress | list | `[{"ports":[{"port":8080,"protocol":"TCP"},{"port":8081,"protocol":"TCP"}]}]` | The ingress traffic Should match the health and (optionally) metrics port |
| eso.certController.nodeSelector | object | `{}` |  |
| eso.certController.podAnnotations | object | `{}` | Annotations to add to Pod |
| eso.certController.podDisruptionBudget | object | `{"enabled":false,"minAvailable":1,"nameOverride":""}` | Pod disruption budget - for more details see https://kubernetes.io/docs/concepts/workloads/pods/disruptions/ |
| eso.certController.podLabels | object | `{}` |  |
| eso.certController.podSecurityContext.enabled | bool | `true` |  |
| eso.certController.priorityClassName | string | `""` |  |
| eso.certController.rbac.create | bool | `true` | Specifies whether role and rolebinding resources should be created. |
| eso.certController.readinessProbe.address | string | `""` |  |
| eso.certController.readinessProbe.enabled | bool | `true` |  |
| eso.certController.readinessProbe.failureThreshold | int | `3` |  |
| eso.certController.readinessProbe.initialDelaySeconds | int | `20` |  |
| eso.certController.readinessProbe.periodSeconds | int | `5` |  |
| eso.certController.readinessProbe.port | int | `8081` | Set this value to 'ready' (for named port) or an integer for readiness probes. @schema type: [string, integer] |
| eso.certController.readinessProbe.successThreshold | int | `1` |  |
| eso.certController.readinessProbe.timeoutSeconds | int | `5` |  |
| eso.certController.replicaCount | int | `1` |  |
| eso.certController.requeueInterval | string | `"5m"` |  |
| eso.certController.resources | object | `{}` |  |
| eso.certController.revisionHistoryLimit | int | `10` | Specifies the amount of historic ReplicaSets k8s should keep (see https://kubernetes.io/docs/concepts/workloads/controllers/deployment/#clean-up-policy) |
| eso.certController.runtimeClassName | string | `""` | Pod runtime class name. |
| eso.certController.schedulerName | string | `""` | Pod scheduler name. |
| eso.certController.securityContext.allowPrivilegeEscalation | bool | `false` |  |
| eso.certController.securityContext.capabilities.drop[0] | string | `"ALL"` |  |
| eso.certController.securityContext.enabled | bool | `true` |  |
| eso.certController.securityContext.readOnlyRootFilesystem | bool | `true` |  |
| eso.certController.securityContext.runAsNonRoot | bool | `true` |  |
| eso.certController.securityContext.runAsUser | int | `1000` |  |
| eso.certController.securityContext.seccompProfile.type | string | `"RuntimeDefault"` |  |
| eso.certController.serviceAccount.annotations | object | `{}` | Annotations to add to the service account. |
| eso.certController.serviceAccount.automount | bool | `true` | Automounts the service account token in all containers of the pod |
| eso.certController.serviceAccount.create | bool | `true` | Specifies whether a service account should be created. |
| eso.certController.serviceAccount.extraLabels | object | `{}` | Extra Labels to add to the service account. |
| eso.certController.serviceAccount.name | string | `""` | The name of the service account to use. If not set and create is true, a name is generated using the fullname template. |
| eso.certController.startupProbe.enabled | bool | `false` | Enabled determines if the startup probe should be used or not. By default it's disabled. |
| eso.certController.startupProbe.failureThreshold | int | `30` | Number of consecutive failures before the container is restarted. The startup window is initialDelaySeconds + failureThreshold * periodSeconds. |
| eso.certController.startupProbe.initialDelaySeconds | int | `10` | Number of seconds after the container has started before the startup probe is initiated. |
| eso.certController.startupProbe.periodSeconds | int | `10` | How often (in seconds) to perform the startup probe. |
| eso.certController.strategy | object | `{}` | Set deployment strategy |
| eso.certController.tls | object | `{"ciphers":"","curvePreferences":[],"minVersion":""}` | CertController-specific TLS security profile overrides. When set, these override the global tls.* values for the cert-controller deployment. |
| eso.certController.tls.ciphers | string | `""` | Comma-separated list of TLS cipher suites. If empty, the global tls.ciphers is used. +docs:property |
| eso.certController.tls.curvePreferences | list | `[]` | Ordered list of TLS key exchange curves. If empty, the global tls.curvePreferences is used. +docs:property |
| eso.certController.tls.minVersion | string | `""` | Minimum TLS version supported (e.g. "1.2" or "1.3"). If empty, the global tls.minVersion is used. +docs:property |
| eso.certController.tolerations | list | `[]` |  |
| eso.certController.topologySpreadConstraints | list | `[]` |  |
| eso.commonLabels | object | `{}` | Additional labels added to all helm chart resources. |
| eso.concurrent | int | `1` | Specifies the number of concurrent ExternalSecret Reconciles external-secret executes at a time. |
| eso.controllerClass | string | `""` | If set external secrets will filter matching Secret Stores with the appropriate controller values. |
| eso.crds.annotations | object | `{}` |  |
| eso.crds.conversion.enabled | bool | `false` | Conversion is disabled by default as we stopped supporting v1alpha1. |
| eso.crds.createClusterExternalSecret | bool | `true` | If true, create CRDs for Cluster External Secret. If set to false you must also set processClusterExternalSecret: false. |
| eso.crds.createClusterGenerator | bool | `true` | If true, create CRDs for Cluster Generator. If set to false you must also set processClusterGenerator: false. |
| eso.crds.createClusterPushSecret | bool | `true` | If true, create CRDs for Cluster Push Secret. If set to false you must also set processClusterPushSecret: false. |
| eso.crds.createClusterSecretStore | bool | `true` | If true, create CRDs for Cluster Secret Store. If set to false you must also set processClusterStore: false. |
| eso.crds.createPushSecret | bool | `true` | If true, create CRDs for Push Secret. If set to false you must also set processPushSecret: false. |
| eso.crds.createSecretStore | bool | `true` | If true, create CRDs for Secret Store. If set to false you must also set processSecretStore: false. |
| eso.crds.unsafeServeV1Beta1 | bool | `false` | If true, enable v1beta1 API version serving for ExternalSecret, ClusterExternalSecret, SecretStore, and ClusterSecretStore CRDs. v1beta1 is deprecated. Only enable this for backward compatibility if you have existing v1beta1 resources. Warning: This flag will be removed on 2026.05.01. |
| eso.createOperator | bool | `true` | Specifies whether an external secret operator deployment be created. |
| eso.deploymentAnnotations | object | `{}` | Annotations to add to Deployment |
| eso.dnsConfig | object | `{}` | Specifies `dnsOptions` to deployment |
| eso.dnsPolicy | string | `"ClusterFirst"` | Specifies `dnsPolicy` to deployment |
| eso.enableHTTP2 | bool | `false` | if true, HTTP2 will be enabled for the services created by all controllers, curently metrics and webhook. |
| eso.extendedMetricLabels | bool | `false` | If true external secrets will use recommended kubernetes annotations as prometheus metric labels. |
| eso.extraArgs | object | `{}` |  |
| eso.extraContainers | list | `[]` |  |
| eso.extraEnv | list | `[]` |  |
| eso.extraInitContainers | list | `[]` |  |
| eso.extraObjects | list | `[]` |  |
| eso.extraVolumeMounts | list | `[]` |  |
| eso.extraVolumes | list | `[]` |  |
| eso.fullnameOverride | string | `""` |  |
| eso.genericTargets | object | `{"enabled":false,"resources":[]}` | Enable support for generic targets (ConfigMaps, Custom Resources). Warning: Using generic target. Make sure access policies and encryption are properly configured. When enabled, this grants the controller permissions to create/update/delete ConfigMaps and optionally other resource types specified in generic.resources. |
| eso.genericTargets.enabled | bool | `false` | Enable generic target support |
| eso.genericTargets.resources | list | `[]` | List of additional resource types to grant permissions for. Each entry should specify apiGroup, resources, and verbs. Example: resources:   - apiGroup: "argoproj.io"     resources: ["applications"]     verbs: ["get", "list", "watch", "create", "update", "patch", "delete"] |
| eso.global.affinity | object | `{}` |  |
| eso.global.compatibility.openshift.adaptSecurityContext | string | `"auto"` | Manages the securityContext properties to make them compatible with OpenShift. Possible values: auto - Apply configurations if it is detected that OpenShift is the target platform. force - Always apply configurations. disabled - No modification applied. |
| eso.global.hostAliases | list | `[]` | Global hostAliases to be applied to all deployments |
| eso.global.imagePullSecrets | list | `[]` | Global imagePullSecrets to be applied to all deployments |
| eso.global.nodeSelector | object | `{}` |  |
| eso.global.podAnnotations | object | `{}` | Global pod annotations to be applied to all deployments |
| eso.global.podLabels | object | `{}` | Global pod labels to be applied to all deployments |
| eso.global.repository | string | `""` | Global image repository to be applied to all deployments |
| eso.global.tolerations | list | `[]` |  |
| eso.global.topologySpreadConstraints | list | `[]` |  |
| eso.grafanaDashboard.annotations | object | `{}` | Annotations that ConfigMaps can have to get configured in Grafana, See: sidecar.dashboards.folderAnnotation for specifying the dashboard folder. https://github.com/grafana/helm-charts/tree/main/charts/grafana |
| eso.grafanaDashboard.enabled | bool | `false` | If true creates a Grafana dashboard. |
| eso.grafanaDashboard.extraLabels | object | `{}` | Extra labels to add to the Grafana dashboard ConfigMap. |
| eso.grafanaDashboard.namespace | string | `""` | Namespace where the dashboard ConfigMap should be created. Resolution order: grafanaDashboard.namespace, then namespaceOverride, then the release namespace. |
| eso.grafanaDashboard.sidecarLabel | string | `"grafana_dashboard"` | Label that ConfigMaps should have to be loaded as dashboards. |
| eso.grafanaDashboard.sidecarLabelValue | string | `"1"` | Label value that ConfigMaps should have to be loaded as dashboards. |
| eso.hostAliases | list | `[]` | Specifies `hostAliases` to deployment |
| eso.hostNetwork | bool | `false` | Run the controller on the host network |
| eso.hostUsers | bool | `nil` | Specifies if controller pod should use hostUsers or not. If hostNetwork is true, hostUsers should be too. Only available in Kubernetes ≥ 1.33. @schema type: [boolean, null] |
| eso.image.flavour | string | `""` | The flavour of tag you want to use There are different image flavours available, like distroless and ubi. Please see GitHub release notes for image tags for these flavors. By default, the distroless image is used. |
| eso.image.pullPolicy | string | `"IfNotPresent"` |  |
| eso.image.repository | string | `"ghcr.io/external-secrets/external-secrets"` |  |
| eso.image.tag | string | `""` | The image tag to use. The default is the chart appVersion. |
| eso.imagePullSecrets | list | `[]` |  |
| eso.installCRDs | bool | `true` | If set, install and upgrade CRDs through helm chart. |
| eso.leaderElect | bool | `false` | If true, external-secrets will perform leader election between instances to ensure no more than one instance of external-secrets operates at a time. |
| eso.leaderElectionID | string | "external-secrets-controller" | ID of the lease object used for leader election. Leave empty to use the default ('external-secrets-controller'). Set to a unique value when running multiple independent ESO deployments in the same namespace. |
| eso.leaderElectionLeaseDuration | string | "15s" | Duration that non-leader candidates will wait to force acquire leadership. Increase this along with renewDeadline to tolerate a busy or briefly unavailable API server (for example during control plane maintenance) without churning leadership. Leave empty to use the controller default ('15s'). |
| eso.leaderElectionRenewDeadline | string | "10s" | Duration that the acting leader will retry refreshing leadership before giving up. Must be less than leaderElectionLeaseDuration. Leave empty to use the controller default ('10s'). |
| eso.leaderElectionRetryPeriod | string | "2s" | Duration the leader election client waits between tries of actions. Leave empty to use the controller default ('2s'). |
| eso.livenessProbe.enabled | bool | `false` | Enabled determines if the liveness probe should be used or not. By default it's disabled. |
| eso.livenessProbe.spec | object | `{"address":"","failureThreshold":5,"httpGet":{"path":"/healthz","port":"live"},"initialDelaySeconds":10,"periodSeconds":10,"port":8082,"successThreshold":1,"timeoutSeconds":5}` | The body of the liveness probe settings. |
| eso.livenessProbe.spec.address | string | `""` | Bind address for the health server used by both liveness and readiness probes (--live-addr flag). |
| eso.livenessProbe.spec.failureThreshold | int | `5` | Number of consecutive probe failures that should occur before considering the probe as failed. |
| eso.livenessProbe.spec.httpGet | object | `{"path":"/healthz","port":"live"}` | Handler for liveness probe. |
| eso.livenessProbe.spec.httpGet.path | string | `"/healthz"` | Path for liveness probe. |
| eso.livenessProbe.spec.httpGet.port | string | `"live"` | Set this value to 'live' (for named port) or an an integer for liveness probes. @schema type: [string, integer] |
| eso.livenessProbe.spec.initialDelaySeconds | int | `10` | Delay in seconds for the container to start before performing the initial probe. |
| eso.livenessProbe.spec.periodSeconds | int | `10` | Period in seconds for K8s to start performing probes. |
| eso.livenessProbe.spec.port | int | `8082` | Port for the health server used by both liveness and readiness probes (--live-addr flag). |
| eso.livenessProbe.spec.successThreshold | int | `1` | Number of successful probes to mark probe successful. |
| eso.livenessProbe.spec.timeoutSeconds | int | `5` | Specify the maximum amount of time to wait for a probe to respond before considering it fails. |
| eso.log | object | `{"level":"info","timeEncoding":"epoch"}` | Specifies Log Params to the External Secrets Operator |
| eso.metrics.listen.auth.enabled | bool | `false` | Enable Kubernetes RBAC-based authentication for metrics endpoint. Requires metrics.listen.secure to be true. Default value is false. |
| eso.metrics.listen.port | int | `8080` |  |
| eso.metrics.listen.secure.certDir | string | `"/etc/tls"` | TLS cert directory path |
| eso.metrics.listen.secure.certFile | string | `"/etc/tls/tls.crt"` | TLS cert file path |
| eso.metrics.listen.secure.enabled | bool | `false` |  |
| eso.metrics.listen.secure.keyFile | string | `"/etc/tls/tls.key"` | TLS key file path |
| eso.metrics.service.annotations | object | `{}` | Additional service annotations |
| eso.metrics.service.enabled | bool | `false` | Enable if you use another monitoring tool than Prometheus to scrape the metrics |
| eso.metrics.service.port | int | `8080` | Metrics service port to scrape |
| eso.nameOverride | string | `""` |  |
| eso.namespaceOverride | string | `""` |  |
| eso.networkPolicy | object | `{"egress":[],"enabled":false,"ingress":[{"ports":[{"port":8080,"protocol":"TCP"},{"port":8082,"protocol":"TCP"}]}]}` | Setup a networkPolicy for external-secrets |
| eso.networkPolicy.egress | list | `[]` | The egress traffic The minimum egress ports required to function are:   DNS (53/udp, 53/tcp)   API server (80/tcp, 443/tcp, or 6443/tcp) You will need to customize this value to meet your needs |
| eso.networkPolicy.enabled | bool | `false` | Specifies whether the networkPolicy should be created. |
| eso.networkPolicy.ingress | list | `[{"ports":[{"port":8080,"protocol":"TCP"},{"port":8082,"protocol":"TCP"}]}]` | The ingress traffic Should match the health and (optionally) metrics port |
| eso.nodeSelector | object | `{}` |  |
| eso.openshiftFinalizers | bool | `true` | If true the OpenShift finalizer permissions will be added to RBAC |
| eso.podAnnotations | object | `{}` | Annotations to add to Pod |
| eso.podDisruptionBudget | object | `{"enabled":false,"minAvailable":1,"nameOverride":""}` | Pod disruption budget - for more details see https://kubernetes.io/docs/concepts/workloads/pods/disruptions/ |
| eso.podLabels | object | `{}` |  |
| eso.podSecurityContext.enabled | bool | `true` |  |
| eso.podSpecExtra | object | `{}` | Any extra pod spec on the deployment |
| eso.priorityClassName | string | `""` | Pod priority class name. |
| eso.processClusterExternalSecret | bool | `true` | if true, the operator will process cluster external secret. Else, it will ignore them. When enabled, this adds update/patch permissions on namespaces to handle finalizers for proper cleanup during namespace deletion, preventing race conditions with ExternalSecrets. |
| eso.processClusterGenerator | bool | `true` | if true, the operator will process cluster generator. Else, it will ignore them. |
| eso.processClusterPushSecret | bool | `true` | if true, the operator will process cluster push secret. Else, it will ignore them. |
| eso.processClusterStore | bool | `true` | if true, the operator will process cluster store. Else, it will ignore them. |
| eso.processPushSecret | bool | `true` | if true, the operator will process push secret. Else, it will ignore them. |
| eso.processSecretStore | bool | `true` | if true, the operator will process secret store. Else, it will ignore them. |
| eso.rbac.aggregateToAdmin | bool | `true` | Specifies whether permissions are aggregated to the admin ClusterRole |
| eso.rbac.aggregateToEdit | bool | `true` | Specifies whether permissions are aggregated to the edit ClusterRole |
| eso.rbac.aggregateToView | bool | `true` | Specifies whether permissions are aggregated to the view ClusterRole |
| eso.rbac.create | bool | `true` | Specifies whether role and rolebinding resources should be created. |
| eso.rbac.serviceAccountTokenCreate | bool | `true` | Specifies whether the serviceaccounts/token create permission is included in the controller RBAC. When set to false, users must create per-ServiceAccount Role/RoleBinding with resourceNames constraint to grant ESO token creation for specific ServiceAccounts referenced in SecretStore specs. |
| eso.rbac.servicebindings.create | bool | `true` | Specifies whether a clusterrole to give servicebindings read access should be created. |
| eso.readinessProbe.enabled | bool | `false` | Determines whether the readiness probe is enabled. Disabled by default. Enabling this will auto-start the health server (--live-addr) even if livenessProbe is disabled. Health server address/port are configured via livenessProbe.spec.address and livenessProbe.spec.port. |
| eso.readinessProbe.spec | object | `{"failureThreshold":3,"httpGet":{"path":"/readyz","port":"live"},"initialDelaySeconds":10,"periodSeconds":10,"successThreshold":1,"timeoutSeconds":5}` | The body of the readiness probe settings (standard Kubernetes probe spec). |
| eso.readinessProbe.spec.failureThreshold | int | `3` | Number of consecutive probe failures that should occur before considering the probe as failed. |
| eso.readinessProbe.spec.httpGet | object | `{"path":"/readyz","port":"live"}` | Handler for readiness probe. |
| eso.readinessProbe.spec.httpGet.path | string | `"/readyz"` | Path for readiness probe. |
| eso.readinessProbe.spec.httpGet.port | string | `"live"` | Set this value to 'live' (for named port) or an integer for readiness probes. @schema type: [string, integer] |
| eso.readinessProbe.spec.initialDelaySeconds | int | `10` | Delay in seconds for the container to start before performing the initial probe. |
| eso.readinessProbe.spec.periodSeconds | int | `10` | Period in seconds for K8s to start performing probes. |
| eso.readinessProbe.spec.successThreshold | int | `1` | Number of successful probes to mark probe successful. |
| eso.readinessProbe.spec.timeoutSeconds | int | `5` | Specify the maximum amount of time to wait for a probe to respond before considering it fails. |
| eso.replicaCount | int | `1` |  |
| eso.resources | object | `{}` |  |
| eso.revisionHistoryLimit | int | `10` | Specifies the amount of historic ReplicaSets k8s should keep (see https://kubernetes.io/docs/concepts/workloads/controllers/deployment/#clean-up-policy) |
| eso.runtimeClassName | string | `""` | Pod runtime class name. |
| eso.schedulerName | string | `""` | Pod scheduler name. |
| eso.scopedNamespace | string | `""` | If set external secrets are only reconciled in the provided namespace |
| eso.scopedRBAC | bool | `false` | If true, create scoped RBAC roles and implicitly disable cluster-scoped controllers. Scoped to scopedNamespace if set, otherwise to .Release.Namespace. |
| eso.securityContext.allowPrivilegeEscalation | bool | `false` |  |
| eso.securityContext.capabilities.drop[0] | string | `"ALL"` |  |
| eso.securityContext.enabled | bool | `true` |  |
| eso.securityContext.readOnlyRootFilesystem | bool | `true` |  |
| eso.securityContext.runAsNonRoot | bool | `true` |  |
| eso.securityContext.runAsUser | int | `1000` |  |
| eso.securityContext.seccompProfile.type | string | `"RuntimeDefault"` |  |
| eso.service.ipFamilies | list | `[]` | Sets the families that should be supported and the order in which they should be applied to ClusterIP as well. Can be IPv4 and/or IPv6. |
| eso.service.ipFamilyPolicy | string | `""` | Set the ip family policy to configure dual-stack see [Configure dual-stack](https://kubernetes.io/docs/concepts/services-networking/dual-stack/#services) |
| eso.serviceAccount.annotations | object | `{}` | Annotations to add to the service account. |
| eso.serviceAccount.automount | bool | `true` | Automounts the service account token in all containers of the pod |
| eso.serviceAccount.create | bool | `true` | Specifies whether a service account should be created. |
| eso.serviceAccount.extraLabels | object | `{}` | Extra Labels to add to the service account. |
| eso.serviceAccount.name | string | `""` | The name of the service account to use. If not set and create is true, a name is generated using the fullname template. |
| eso.serviceMonitor.additionalLabels | object | `{}` | Additional labels |
| eso.serviceMonitor.enabled | bool | `false` | Specifies whether to create a ServiceMonitor resource for collecting Prometheus metrics |
| eso.serviceMonitor.honorLabels | bool | `false` | Let prometheus add an exported_ prefix to conflicting labels |
| eso.serviceMonitor.interval | string | `"30s"` | Interval to scrape metrics |
| eso.serviceMonitor.metricRelabelings | list | `[]` | Metric relabel configs to apply to samples before ingestion. [Metric Relabeling](https://prometheus.io/docs/prometheus/latest/configuration/configuration/#metric_relabel_configs) |
| eso.serviceMonitor.namespace | string | `""` | namespace where you want to install ServiceMonitors |
| eso.serviceMonitor.relabelings | list | `[]` | Relabel configs to apply to samples before ingestion. [Relabeling](https://prometheus.io/docs/prometheus/latest/configuration/configuration/#relabel_config) |
| eso.serviceMonitor.renderMode | string | `"skipIfMissing"` | How should we react to missing CRD "`monitoring.coreos.com/v1/ServiceMonitor`"  Possible values: - `skipIfMissing`: Only render ServiceMonitor resources if CRD is present, skip if missing. - `failIfMissing`: Fail Helm install if CRD is not present. - `alwaysRender` : Always render ServiceMonitor resources, do not check for CRD. @schema enum: - skipIfMissing - failIfMissing - alwaysRender @schema |
| eso.serviceMonitor.scrapeTimeout | string | `"25s"` | Timeout if metrics can't be retrieved in given time interval |
| eso.storeRequeueInterval | string | `""` | Default time duration between reconciling (Cluster)SecretStores. |
| eso.strategy | object | `{}` | Set deployment strategy |
| eso.systemAuthDelegator | bool | `false` | If true the system:auth-delegator ClusterRole will be added to RBAC |
| eso.tls | object | `{"ciphers":"","curvePreferences":[],"minVersion":""}` | TLS security profile settings applied to all controller, webhook, and certController deployments. These can be overridden per-component via webhook.tls and certController.tls. |
| eso.tls.ciphers | string | `""` | Comma-separated list of TLS cipher suites (TLS_CIPHER_SUITE names). Does not apply to TLS 1.3. If empty, Go defaults apply. +docs:property |
| eso.tls.curvePreferences | list | `[]` | Ordered list of TLS key exchange curves (e.g. X25519, CurveP256, or decimal CurveID). If empty, Go defaults apply. +docs:property |
| eso.tls.minVersion | string | `""` | Minimum TLS version supported (e.g. "1.2" or "1.3"). If empty, the Go CLI default applies. +docs:property |
| eso.tolerations | list | `[]` |  |
| eso.topologySpreadConstraints | list | `[]` |  |
| eso.vault | object | `{"enableTokenCache":false,"tokenCacheSize":262144}` | Vault token cache configuration |
| eso.vault.enableTokenCache | bool | `false` | Enable Vault token cache. External secrets will reuse the Vault token without creating a new one on each request. |
| eso.vault.tokenCacheSize | int | `262144` | Maximum size of Vault token cache. Only used if enableTokenCache is true. |
| eso.webhook.affinity | object | `{}` |  |
| eso.webhook.annotations | object | `{}` | Annotations to place on validating webhook configuration. |
| eso.webhook.certCheckInterval | string | `"5m"` | Specifies the time to check if the cert is valid |
| eso.webhook.certDir | string | `"/tmp/certs"` |  |
| eso.webhook.certManager.addInjectorAnnotations | bool | `true` | Automatically add the cert-manager.io/inject-ca-from annotation to the webhooks and CRDs. As long as you have the cert-manager CA Injector enabled, this will automatically setup your webhook's CA to the one used by cert-manager. See https://cert-manager.io/docs/concepts/ca-injector |
| eso.webhook.certManager.cert.annotations | object | `{}` | Add extra annotations to the Certificate resource. |
| eso.webhook.certManager.cert.create | bool | `true` | Create a certificate resource within this chart. See https://cert-manager.io/docs/usage/certificate/ |
| eso.webhook.certManager.cert.duration | string | `"8760h0m0s"` | Set the requested duration (i.e. lifetime) of the Certificate. See https://cert-manager.io/docs/reference/api-docs/#cert-manager.io/v1.CertificateSpec One year by default. |
| eso.webhook.certManager.cert.issuerRef | object | `{"group":"cert-manager.io","kind":"Issuer","name":"my-issuer"}` | For the Certificate created by this chart, setup the issuer. See https://cert-manager.io/docs/reference/api-docs/#cert-manager.io/v1.IssuerSpec |
| eso.webhook.certManager.cert.privateKey | object | `{}` | Specific settings on the privateKey and its generation |
| eso.webhook.certManager.cert.renewBefore | string | `""` | How long before the currently issued certificate’s expiry cert-manager should renew the certificate. See https://cert-manager.io/docs/reference/api-docs/#cert-manager.io/v1.CertificateSpec Note that renewBefore should be greater than .webhook.lookaheadInterval since the webhook will check this far in advance that the certificate is valid. |
| eso.webhook.certManager.cert.revisionHistoryLimit | int | `0` | Set the revisionHistoryLimit on the Certificate. See https://cert-manager.io/docs/reference/api-docs/#cert-manager.io/v1.CertificateSpec Defaults to 0 (ignored). |
| eso.webhook.certManager.cert.signatureAlgorithm | string | `""` | Specific settings on the signatureAlgorithm used on the cert. signatureAlgorithm is only valid for cert-manager v1.18.0+ |
| eso.webhook.certManager.enabled | bool | `false` | Enabling cert-manager support will disable the built in secret and switch to using cert-manager (installed separately) to automatically issue and renew the webhook certificate. This chart does not install cert-manager for you, See https://cert-manager.io/docs/ |
| eso.webhook.create | bool | `true` | Specifies whether a webhook deployment be created. If set to false, crds.conversion.enabled should also be set to false otherwise the kubeapi will be hammered because the conversion is looking for a webhook endpoint. |
| eso.webhook.deploymentAnnotations | object | `{}` | Annotations to add to Deployment |
| eso.webhook.extraArgs | object | `{}` |  |
| eso.webhook.extraEnv | list | `[]` |  |
| eso.webhook.extraInitContainers | list | `[]` |  |
| eso.webhook.extraVolumeMounts | list | `[]` |  |
| eso.webhook.extraVolumes | list | `[]` |  |
| eso.webhook.failurePolicy | string | `"Fail"` | Specifies whether validating webhooks should be created with failurePolicy: Fail or Ignore |
| eso.webhook.hostAliases | list | `[]` | Specifies `hostAliases` to webhook deployment |
| eso.webhook.hostNetwork | bool | `false` | Specifies if webhook pod should use hostNetwork or not. |
| eso.webhook.hostUsers | bool | `nil` | Specifies if webhook pod should use hostUsers or not. If hostNetwork is true, hostUsers should be too. Only available in Kubernetes ≥ 1.33. @schema type: [boolean, null] |
| eso.webhook.image.flavour | string | `""` | The flavour of tag you want to use |
| eso.webhook.image.pullPolicy | string | `"IfNotPresent"` |  |
| eso.webhook.image.repository | string | `"ghcr.io/external-secrets/external-secrets"` |  |
| eso.webhook.image.tag | string | `""` | The image tag to use. The default is the chart appVersion. |
| eso.webhook.imagePullSecrets | list | `[]` |  |
| eso.webhook.livenessProbe.enabled | bool | `false` |  |
| eso.webhook.livenessProbe.failureThreshold | int | `5` |  |
| eso.webhook.livenessProbe.initialDelaySeconds | int | `10` |  |
| eso.webhook.livenessProbe.periodSeconds | int | `10` |  |
| eso.webhook.livenessProbe.port | int | `8081` | Set this value to 'live' (for named port) or an integer for liveness probes. @schema type: [string, integer] |
| eso.webhook.livenessProbe.successThreshold | int | `1` |  |
| eso.webhook.livenessProbe.timeoutSeconds | int | `5` |  |
| eso.webhook.log | object | `{"level":"info","timeEncoding":"epoch"}` | Specifies Log Params to the Webhook |
| eso.webhook.lookaheadInterval | string | `""` | Specifies the lookaheadInterval for certificate validity |
| eso.webhook.metrics.listen.auth.enabled | bool | `false` | Enable Kubernetes RBAC-based authentication for webhook's metrics endpoint. Requires webhook.metrics.listen.secure to be true. Default value is false. |
| eso.webhook.metrics.listen.port | int | `8080` |  |
| eso.webhook.metrics.listen.secure.certDir | string | `"/etc/tls"` | TLS cert directory path |
| eso.webhook.metrics.listen.secure.certFile | string | `"/etc/tls/tls.crt"` | TLS cert file path |
| eso.webhook.metrics.listen.secure.enabled | bool | `false` |  |
| eso.webhook.metrics.listen.secure.keyFile | string | `"/etc/tls/tls.key"` | TLS key file path |
| eso.webhook.metrics.service.annotations | object | `{}` | Additional service annotations |
| eso.webhook.metrics.service.enabled | bool | `false` | Enable if you use another monitoring tool than Prometheus to scrape the metrics |
| eso.webhook.metrics.service.port | int | `8080` | Metrics service port to scrape |
| eso.webhook.networkPolicy | object | `{"egress":[],"enabled":false,"ingress":[{"ports":[{"port":8080,"protocol":"TCP"},{"port":8081,"protocol":"TCP"},{"port":10250,"protocol":"TCP"}]}]}` | Setup a networkPolicy for external-secrets webhook |
| eso.webhook.networkPolicy.egress | list | `[]` | The egress traffic The minimum egress ports required to function are:   DNS (53/udp, 53/tcp)   API server (80/tcp, 443/tcp, or 6443/tcp) You will need to customize this value to meet your needs |
| eso.webhook.networkPolicy.enabled | bool | `false` | Specifies whether the networkPolicy should be created. |
| eso.webhook.networkPolicy.ingress | list | `[{"ports":[{"port":8080,"protocol":"TCP"},{"port":8081,"protocol":"TCP"},{"port":10250,"protocol":"TCP"}]}]` | The ingress traffic Should match the webhook, health, and (optionally) metrics port |
| eso.webhook.nodeSelector | object | `{}` |  |
| eso.webhook.podAnnotations | object | `{}` | Annotations to add to Pod |
| eso.webhook.podDisruptionBudget | object | `{"enabled":false,"minAvailable":1,"nameOverride":""}` | Pod disruption budget - for more details see https://kubernetes.io/docs/concepts/workloads/pods/disruptions/ |
| eso.webhook.podLabels | object | `{}` |  |
| eso.webhook.podSecurityContext.enabled | bool | `true` |  |
| eso.webhook.port | int | `10250` | The port the webhook will listen to |
| eso.webhook.priorityClassName | string | `""` | Pod priority class name. |
| eso.webhook.readinessProbe.address | string | `""` |  |
| eso.webhook.readinessProbe.enabled | bool | `true` |  |
| eso.webhook.readinessProbe.failureThreshold | int | `3` |  |
| eso.webhook.readinessProbe.initialDelaySeconds | int | `20` |  |
| eso.webhook.readinessProbe.periodSeconds | int | `5` |  |
| eso.webhook.readinessProbe.port | int | `8081` | Set this value to 'ready' (for named port) or an integer for readiness probes. @schema type: [string, integer] |
| eso.webhook.readinessProbe.successThreshold | int | `1` |  |
| eso.webhook.readinessProbe.timeoutSeconds | int | `5` |  |
| eso.webhook.replicaCount | int | `1` |  |
| eso.webhook.resources | object | `{}` |  |
| eso.webhook.revisionHistoryLimit | int | `10` | Specifies the amount of historic ReplicaSets k8s should keep (see https://kubernetes.io/docs/concepts/workloads/controllers/deployment/#clean-up-policy) |
| eso.webhook.runtimeClassName | string | `""` | Pod runtime class name. |
| eso.webhook.schedulerName | string | `""` | Pod scheduler name. |
| eso.webhook.secretAnnotations | object | `{}` | Annotations to add to Secret |
| eso.webhook.securityContext.allowPrivilegeEscalation | bool | `false` |  |
| eso.webhook.securityContext.capabilities.drop[0] | string | `"ALL"` |  |
| eso.webhook.securityContext.enabled | bool | `true` |  |
| eso.webhook.securityContext.readOnlyRootFilesystem | bool | `true` |  |
| eso.webhook.securityContext.runAsNonRoot | bool | `true` |  |
| eso.webhook.securityContext.runAsUser | int | `1000` |  |
| eso.webhook.securityContext.seccompProfile.type | string | `"RuntimeDefault"` |  |
| eso.webhook.service | object | `{"annotations":{},"enabled":true,"labels":{},"loadBalancerIP":"","type":"ClusterIP"}` | Manage the service through which the webhook is reached. |
| eso.webhook.service.annotations | object | `{}` | Custom annotations for the webhook service. |
| eso.webhook.service.enabled | bool | `true` | Whether the service object should be enabled or not (it is expected to exist). |
| eso.webhook.service.labels | object | `{}` | Custom labels for the webhook service. |
| eso.webhook.service.loadBalancerIP | string | `""` | If the webhook service type is LoadBalancer, you can assign a specific load balancer IP here. Check the documentation of your load balancer provider to see if/how this should be used. |
| eso.webhook.service.type | string | `"ClusterIP"` | The service type of the webhook service. |
| eso.webhook.serviceAccount.annotations | object | `{}` | Annotations to add to the service account. |
| eso.webhook.serviceAccount.automount | bool | `true` | Automounts the service account token in all containers of the pod |
| eso.webhook.serviceAccount.create | bool | `true` | Specifies whether a service account should be created. |
| eso.webhook.serviceAccount.extraLabels | object | `{}` | Extra Labels to add to the service account. |
| eso.webhook.serviceAccount.name | string | `""` | The name of the service account to use. If not set and create is true, a name is generated using the fullname template. |
| eso.webhook.startupProbe.enabled | bool | `false` | Enabled determines if the startup probe should be used or not. By default it's disabled. |
| eso.webhook.startupProbe.failureThreshold | int | `30` | Number of consecutive failures before the container is restarted. The startup window is initialDelaySeconds + failureThreshold * periodSeconds. |
| eso.webhook.startupProbe.initialDelaySeconds | int | `10` | Number of seconds after the container has started before the startup probe is initiated. |
| eso.webhook.startupProbe.periodSeconds | int | `10` | How often (in seconds) to perform the startup probe. |
| eso.webhook.strategy | object | `{}` | Set deployment strategy |
| eso.webhook.tls | object | `{"ciphers":"","curvePreferences":[],"minVersion":""}` | Webhook-specific TLS security profile overrides. When set, these override the global tls.* values for the webhook deployment. |
| eso.webhook.tls.ciphers | string | `""` | Comma-separated list of TLS cipher suites. If empty, the global tls.ciphers is used. +docs:property |
| eso.webhook.tls.curvePreferences | list | `[]` | Ordered list of TLS key exchange curves. If empty, the global tls.curvePreferences is used. +docs:property |
| eso.webhook.tls.minVersion | string | `""` | Minimum TLS version supported (e.g. "1.2" or "1.3"). If empty, the global tls.minVersion is used. +docs:property |
| eso.webhook.tolerations | list | `[]` |  |
| eso.webhook.topologySpreadConstraints | list | `[]` |  |
| prometheus.enabled | bool | `false` | Enables Prometheus Operator monitoring |
| prometheus.grafanaDashboard.enabled | bool | `true` | Add grafana dashboard as a configmap |
| prometheus.grafanaDashboard.label | object | `{"grafana_dashboard":"1"}` | label to apply to the config map. Used by Grafana sidecar to automatically install the dashboard |
| prometheus.rules.enabled | bool | `true` | Enables prometheus operator rules |
| prometheus.rules.labels | object | `{"prometheus":"prometheus-operator-prometheus"}` | Labels to affect to the Prometheus Rules |

## Installing the Chart

### With Helm

To install the chart with the release name `my-release`:

```bash
helm repo add ekp-helm https://edixos.github.io/ekp-helm
helm install ekp-helm/eso
```

### With ArgoCD

Add new application as:

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: eso
spec:
  project: infra

  source:
    repoURL: "https://edixos.github.io/ekp-helm"
    targetRevision: "0.2.3"
    chart: eso
    path: ''

    helm:

      values: |
        name: mysa

  destination:
    server: https://kubernetes.default.svc
    namespace: "cnrm-system"
  syncPolicy:
    automated:
      prune: true
```

## Develop

### Update documentation

Chart documentation is generated with [helm-docs](https://github.com/norwoodj/helm-docs) from `values.yaml` file.
After file modification, regenerate README.md with command:

```bash
docker run --rm -it -v $(pwd):/helm --workdir /helm jnorwood/helm-docs:v1.14.2 helm-docs
```

### Run linter

```bash
docker run --rm -it -w /charts -v $(pwd)/../../:/charts quay.io/helmpack/chart-testing:v3.12.0 ct lint --charts /charts/charts/eso --config /charts/charts/eso/ct.yaml
```

### Run pluto

In order to check if the api-version used in this chart are not deprecated, or worse, removed, we use pluto to check it:

```
docker run --rm -it -v $(pwd):/apps -v pluto:/pluto alpine/helm:3.17 template eso . -f tests/pluto/values.yaml --output-dir /pluto
docker run --rm -it -v pluto:/data us-docker.pkg.dev/fairwinds-ops/oss/pluto:v5 detect-files -d /data -o yaml --ignore-deprecations -t "k8s=v1.31.0,cert-manager=v1.17.0,istio=v1.24.0" -o wide
docker volume rm pluto
```

