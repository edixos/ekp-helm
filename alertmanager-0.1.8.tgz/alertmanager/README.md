# alertmanager

![Version: 0.1.8](https://img.shields.io/badge/Version-0.1.8-informational?style=flat-square) ![AppVersion: v0.27.0](https://img.shields.io/badge/AppVersion-v0.27.0-informational?style=flat-square)

----

[[_TOC_]]

----

## Prerequisites

- Helm v3
- [Prometheus-operator](https://github.com/edixos/ekp-helm/tree/main/charts/kube-prometheus-stack) deployed on the K8S Cluster

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| https://oauth2-proxy.github.io/manifests | oidc(oauth2-proxy) | 10.7.0 |

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| ilyasabdellaoui | <ilyas.abdellaoui21@gmail.com> | <https://github.com/ilyasabdellaoui> |

## Description

Deploies Alertmanager through Prometheus-Operator

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| additionalPeers | list | `[]` | AdditionalPeers allows injecting a set of additional Alertmanagers to peer with to form a highly available cluster. |
| affinity | object | `{}` | Assign custom affinity rules to the alertmanager instance ref: https://kubernetes.io/docs/concepts/configuration/assign-pod-node/ |
| authorizations.enabled | bool | `false` | Enable `envoy-proxy` sidecar to manage rbac access |
| authorizations.envoy.configMap.create | bool | `true` | Create and configure configmap  with name `authorizations.envoy.configMap.name` |
| authorizations.envoy.configMap.name | string | Generated from release chart name | Configmap name to inject into envoy sidecar |
| authorizations.envoy.image.pullPolicy | string | `"Always"` | Container image pull policy |
| authorizations.envoy.image.repository | string | `"docker.io/envoyproxy/envoy-distroless"` | Container name for envoy-proxy |
| authorizations.envoy.image.tag | string | `"v1.22-latest"` |  |
| authorizations.envoy.port | int | `8888` |  |
| authorizations.envoy.resources | object | `{"limits":{"cpu":"100m","memory":"50Mi"},"requests":{"cpu":"5m","memory":"30Mi"}}` | Add resources limits and request to envoy proxy side-car container. |
| authorizations.rbac.resources | object | `{}` | List of resources to protect (name: <rule_name>  ,uri: /<URI>, methods: [<METHOD>], roles: []) |
| clusterAdvertiseAddress | bool | `false` | Explicit address to advertise in cluster. Needs to be provided for non RFC1918 [1] (public) addresses. [1] RFC1918: https://tools.ietf.org/html/rfc1918 |
| clusterName | string | `""` | Alertmanager name |
| commonLabels | object | `{}` | Labels to apply to all resources |
| configMaps | list | `[]` | List of ConfigMaps in the same namespace as the Alertmanager object, which shall be mounted into the Alertmanager Pods. The ConfigMaps are mounted into /etc/alertmanager/configmaps/. |
| configSecret | string | 'alertmanager-{{ fullname }}' | Name of a Kubernetes Secret in the same namespace as the Alertmanager object, which contains configuration for this Alertmanager instance. The secret is mounted into /etc/alertmanager/config and should contains `alertmanager.yaml` key. |
| containers | list | `[]` | Allows to inject additional containers. This is meant to allow adding an authentication proxy to an Alertmanager pod. |
| externalUrl | string | Use ingress host if enabled else generated from Chart name | The external URL the Alertmanager instances will be available under. This is necessary to generate correct URLs. This is necessary if Alertmanager is not served from root of a DNS name. |
| fullnameOverride | string | `""` |  |
| global.argocdAnnotations[0] | string | `"argocd.argoproj.io/sync-options: SkipDryRunOnMissingResource=true"` |  |
| global.enableArgocdAnnotations | bool | `false` | Annotate Custom Resources with `global.argocdAnnotations` |
| image.repository | string | `""` | Override alertmanager image name, use image defined by alertmanager controller if not defined |
| image.tag | string | `""` | Container image tag |
| imagePullSecrets | list | `[]` | Reference to one or more secrets to be used when pulling images ref: https://kubernetes.io/docs/tasks/configure-pod-container/pull-image-private-registry/ |
| ingress.acme.annotations | list | `["kubernetes.io/tls-acme: \"true\""]` | Annotations to add when `ingress.acme.enabled` is true |
| ingress.acme.enabled | bool | `true` | Manage certificates with ACME protocol |
| ingress.annotations."kubernetes.io/ingress.allow-http" | string | `"false"` |  |
| ingress.enabled | bool | `false` | Enables ingress for alertmanager |
| ingress.extraAnnotations | object | `{}` | Map of annotations to add  to th ingress |
| ingress.host | string | `""` | FQDN of the prometheus |
| ingress.labels | object | `{}` | Map of labels to apply to the ingress |
| ingress.path | string | `"/*"` | Path of the incoming request (/* or / if used with nginx) |
| ingress.tls.secretName | string | Generated name based on chart release full name | Name of the secret containing the certificates |
| istio.enabled | bool | `false` | Enables istio features |
| karma.enabled | bool | `false` | Enable karma authentication with htpasswd file |
| karma.groups | list | `["karma"]` | User groups set when authenticated with htpasswd file |
| karma.htpasswd.secretKey | string | `"htpasswd"` | Secret key that contains htpasswd file used to share credentials with karma instance |
| karma.htpasswd.secretName | string | `"karma-secret"` | Secret name that contains htpasswd file used to share credentials with karma instance |
| listenLocal | bool | `false` | ListenLocal makes the Alertmanager server listen on loopback, so that it does not bind against the Pod IP. Note this is only for the Alertmanager UI, not the gossip communication. |
| logFormat | string | `"logfmt"` | Define Log Format Use logfmt (default) or json-formatted logging |
| logLevel | string | `"info"` | Log level for Alertmanager to be configured with. |
| nameOverride | string | `""` |  |
| nodeSelector | object | `{}` | Define which Nodes the Pods are scheduled on. ref: https://kubernetes.io/docs/user-guide/node-selection/ |
| oidc.alphaConfig.annotations | object | `{}` |  |
| oidc.alphaConfig.configData | object | `{}` |  |
| oidc.alphaConfig.configFile | string | `""` |  |
| oidc.alphaConfig.enabled | bool | `false` |  |
| oidc.alphaConfig.existingConfig | string | `nil` |  |
| oidc.alphaConfig.existingSecret | string | `nil` |  |
| oidc.alphaConfig.metricsConfigData | object | `{}` |  |
| oidc.alphaConfig.serverConfigData | object | `{}` |  |
| oidc.authenticatedEmailsFile.annotations | object | `{}` |  |
| oidc.authenticatedEmailsFile.enabled | bool | `false` |  |
| oidc.authenticatedEmailsFile.persistence | string | `"configmap"` |  |
| oidc.authenticatedEmailsFile.restrictedUserAccessKey | string | `""` |  |
| oidc.authenticatedEmailsFile.restricted_access | string | `""` |  |
| oidc.authenticatedEmailsFile.template | string | `""` |  |
| oidc.autoscaling.annotations | object | `{}` |  |
| oidc.autoscaling.behavior | object | `{}` |  |
| oidc.autoscaling.enabled | bool | `false` |  |
| oidc.autoscaling.maxReplicas | int | `10` |  |
| oidc.autoscaling.minReplicas | int | `1` |  |
| oidc.autoscaling.targetCPUUtilizationPercentage | int | `80` |  |
| oidc.checkDeprecation | bool | `true` |  |
| oidc.config.annotations | object | `{}` |  |
| oidc.config.clientID | string | `"XXXXXXX"` |  |
| oidc.config.clientSecret | string | `"XXXXXXXX"` |  |
| oidc.config.configFile | string | `""` |  |
| oidc.config.cookieName | string | `""` |  |
| oidc.config.cookieSecret | string | `"XXXXXXXXXXXXXXXX"` |  |
| oidc.config.emailDomains[0] | string | `"*"` |  |
| oidc.config.existingConfig | string | `nil` |  |
| oidc.config.forceLegacyConfig | bool | `true` |  |
| oidc.config.google | object | `{}` |  |
| oidc.config.requiredSecretKeys[0] | string | `"client-id"` |  |
| oidc.config.requiredSecretKeys[1] | string | `"client-secret"` |  |
| oidc.config.requiredSecretKeys[2] | string | `"cookie-secret"` |  |
| oidc.config.upstreams[0] | string | `"file:///dev/null"` |  |
| oidc.customLabels | object | `{}` | Custom labels to add into metadata |
| oidc.deploymentAnnotations | object | `{}` |  |
| oidc.deploymentLabels | object | `{}` |  |
| oidc.enableServiceLinks | bool | `true` |  |
| oidc.envFrom | list | `[]` |  |
| oidc.extraArgs | object | `{}` |  |
| oidc.extraContainers | list | `[]` |  |
| oidc.extraEnv | list | `[]` |  |
| oidc.extraInitContainers | list | `[]` |  |
| oidc.extraObjects | list | `[]` |  |
| oidc.extraVolumeMounts | list | `[]` |  |
| oidc.extraVolumes | list | `[]` |  |
| oidc.gatewayApi.annotations | object | `{}` |  |
| oidc.gatewayApi.enabled | bool | `false` |  |
| oidc.gatewayApi.gatewayRef | object | `{}` |  |
| oidc.gatewayApi.hostnames | list | `[]` |  |
| oidc.gatewayApi.labels | object | `{}` |  |
| oidc.gatewayApi.rules | list | `[]` |  |
| oidc.global.imagePullSecrets | list | `[]` |  |
| oidc.global.imageRegistry | string | `""` |  |
| oidc.hostAliases | list | `[]` |  |
| oidc.htpasswdFile.enabled | bool | `false` |  |
| oidc.htpasswdFile.entries | list | `[]` |  |
| oidc.htpasswdFile.existingSecret | string | `""` |  |
| oidc.httpScheme | string | `"http"` |  |
| oidc.image.command | list | `[]` |  |
| oidc.image.pullPolicy | string | `"IfNotPresent"` |  |
| oidc.image.registry | string | `""` |  |
| oidc.image.repository | string | `"oauth2-proxy/oauth2-proxy"` |  |
| oidc.image.tag | string | `""` |  |
| oidc.imagePullSecrets | list | `[]` |  |
| oidc.ingress.enabled | bool | `false` |  |
| oidc.ingress.labels | object | `{}` |  |
| oidc.ingress.path | string | `"/"` |  |
| oidc.ingress.pathType | string | `"ImplementationSpecific"` |  |
| oidc.initContainers.waitForRedis.enabled | bool | `true` |  |
| oidc.initContainers.waitForRedis.image.pullPolicy | string | `"IfNotPresent"` |  |
| oidc.initContainers.waitForRedis.image.repository | string | `"alpine"` |  |
| oidc.initContainers.waitForRedis.image.tag | string | `"latest"` |  |
| oidc.initContainers.waitForRedis.kubectlVersion | string | `""` |  |
| oidc.initContainers.waitForRedis.resources | object | `{}` |  |
| oidc.initContainers.waitForRedis.securityContext.allowPrivilegeEscalation | bool | `false` |  |
| oidc.initContainers.waitForRedis.securityContext.capabilities.drop[0] | string | `"ALL"` |  |
| oidc.initContainers.waitForRedis.securityContext.enabled | bool | `true` |  |
| oidc.initContainers.waitForRedis.securityContext.readOnlyRootFilesystem | bool | `true` |  |
| oidc.initContainers.waitForRedis.securityContext.runAsGroup | int | `65534` |  |
| oidc.initContainers.waitForRedis.securityContext.runAsNonRoot | bool | `true` |  |
| oidc.initContainers.waitForRedis.securityContext.runAsUser | int | `65534` |  |
| oidc.initContainers.waitForRedis.securityContext.seccompProfile.type | string | `"RuntimeDefault"` |  |
| oidc.initContainers.waitForRedis.timeout | int | `180` |  |
| oidc.kubeVersion | string | `nil` |  |
| oidc.livenessProbe.enabled | bool | `true` |  |
| oidc.livenessProbe.initialDelaySeconds | int | `0` |  |
| oidc.livenessProbe.timeoutSeconds | int | `1` |  |
| oidc.metrics.enabled | bool | `true` |  |
| oidc.metrics.port | int | `44180` |  |
| oidc.metrics.service.appProtocol | string | `"http"` |  |
| oidc.metrics.serviceMonitor.annotations | object | `{}` |  |
| oidc.metrics.serviceMonitor.bearerTokenFile | string | `""` |  |
| oidc.metrics.serviceMonitor.enabled | bool | `false` |  |
| oidc.metrics.serviceMonitor.interval | string | `"60s"` |  |
| oidc.metrics.serviceMonitor.labels | object | `{}` |  |
| oidc.metrics.serviceMonitor.metricRelabelings | list | `[]` |  |
| oidc.metrics.serviceMonitor.namespace | string | `""` |  |
| oidc.metrics.serviceMonitor.prometheusInstance | string | `"default"` |  |
| oidc.metrics.serviceMonitor.relabelings | list | `[]` |  |
| oidc.metrics.serviceMonitor.scheme | string | `""` |  |
| oidc.metrics.serviceMonitor.scrapeTimeout | string | `"30s"` |  |
| oidc.metrics.serviceMonitor.tlsConfig | object | `{}` |  |
| oidc.namespaceOverride | string | `""` |  |
| oidc.networkPolicy.create | bool | `false` |  |
| oidc.networkPolicy.egress | list | `[]` |  |
| oidc.networkPolicy.ingress | list | `[]` |  |
| oidc.nodeSelector | object | `{}` |  |
| oidc.podAnnotations | object | `{}` |  |
| oidc.podDisruptionBudget.enabled | bool | `true` |  |
| oidc.podDisruptionBudget.maxUnavailable | string | `nil` |  |
| oidc.podDisruptionBudget.minAvailable | int | `1` |  |
| oidc.podDisruptionBudget.unhealthyPodEvictionPolicy | string | `""` |  |
| oidc.podLabels | object | `{}` |  |
| oidc.podSecurityContext | object | `{}` |  |
| oidc.priorityClassName | string | `""` |  |
| oidc.proxyVarsAsSecrets | bool | `true` |  |
| oidc.readinessProbe.enabled | bool | `true` |  |
| oidc.readinessProbe.initialDelaySeconds | int | `0` |  |
| oidc.readinessProbe.periodSeconds | int | `10` |  |
| oidc.readinessProbe.successThreshold | int | `1` |  |
| oidc.readinessProbe.timeoutSeconds | int | `5` |  |
| oidc.redis-ha.enabled | bool | `false` |  |
| oidc.replicaCount | int | `1` |  |
| oidc.resizePolicy | list | `[]` |  |
| oidc.resources | object | `{}` |  |
| oidc.revisionHistoryLimit | int | `10` |  |
| oidc.securityContext.allowPrivilegeEscalation | bool | `false` |  |
| oidc.securityContext.capabilities.drop[0] | string | `"ALL"` |  |
| oidc.securityContext.enabled | bool | `true` |  |
| oidc.securityContext.readOnlyRootFilesystem | bool | `true` |  |
| oidc.securityContext.runAsGroup | int | `2000` |  |
| oidc.securityContext.runAsNonRoot | bool | `true` |  |
| oidc.securityContext.runAsUser | int | `2000` |  |
| oidc.securityContext.seccompProfile.type | string | `"RuntimeDefault"` |  |
| oidc.service.annotations | object | `{}` |  |
| oidc.service.appProtocol | string | `"http"` |  |
| oidc.service.externalTrafficPolicy | string | `""` |  |
| oidc.service.internalTrafficPolicy | string | `""` |  |
| oidc.service.ipDualStack.enabled | bool | `false` |  |
| oidc.service.ipDualStack.ipFamilies[0] | string | `"IPv6"` |  |
| oidc.service.ipDualStack.ipFamilies[1] | string | `"IPv4"` |  |
| oidc.service.ipDualStack.ipFamilyPolicy | string | `"PreferDualStack"` |  |
| oidc.service.portNumber | int | `80` |  |
| oidc.service.targetPort | string | `""` |  |
| oidc.service.trafficDistribution | string | `""` |  |
| oidc.service.type | string | `"ClusterIP"` |  |
| oidc.serviceAccount.annotations | object | `{}` |  |
| oidc.serviceAccount.automountServiceAccountToken | bool | `true` |  |
| oidc.serviceAccount.enabled | bool | `true` |  |
| oidc.serviceAccount.imagePullSecrets | list | `[]` |  |
| oidc.serviceAccount.name | string | `nil` |  |
| oidc.sessionStorage.redis.clientType | string | `"standalone"` |  |
| oidc.sessionStorage.redis.cluster.connectionUrls | list | `[]` |  |
| oidc.sessionStorage.redis.existingSecret | string | `""` |  |
| oidc.sessionStorage.redis.password | string | `""` |  |
| oidc.sessionStorage.redis.passwordKey | string | `"redis-password"` |  |
| oidc.sessionStorage.redis.sentinel.connectionUrls | list | `[]` |  |
| oidc.sessionStorage.redis.sentinel.existingSecret | string | `""` |  |
| oidc.sessionStorage.redis.sentinel.masterName | string | `""` |  |
| oidc.sessionStorage.redis.sentinel.password | string | `""` |  |
| oidc.sessionStorage.redis.sentinel.passwordKey | string | `"redis-sentinel-password"` |  |
| oidc.sessionStorage.redis.standalone.connectionUrl | string | `""` |  |
| oidc.sessionStorage.type | string | `"cookie"` |  |
| oidc.strategy | object | `{}` |  |
| oidc.tolerations | list | `[]` |  |
| paused | bool | `false` | If set to true all actions on the underlying managed objects are not going to be performed, except for delete actions. |
| podAntiAffinity | string | `""` | Pod anti-affinity can prevent the scheduler from placing Prometheus replicas on the same node. The default value "soft" means that the scheduler should *prefer* to not schedule two replica pods onto the same node but no guarantee is provided. The value "hard" means that the scheduler is *required* to not schedule two replica pods onto the same node. The value "" will disable pod anti-affinity so that no anti-affinity rules will be configured. |
| podAntiAffinityTopologyKey | string | `"kubernetes.io/hostname"` | If anti-affinity is enabled sets the topologyKey to use for anti-affinity. This can be changed to, for example, failure-domain.beta.kubernetes.io/zone |
| podDisruptionBudget | object | `{"enabled":true,"maxUnavailable":"","minAvailable":1}` | Configure pod disruption budgets for AlertManager ref: https://kubernetes.io/docs/tasks/run-application/configure-pdb/#specifying-a-poddisruptionbudget This configuration is immutable once created and will require the PDB to be deleted to be changed https://github.com/kubernetes/kubernetes/issues/45398 |
| podMetadata | object | `{}` | Standard object’s metadata. More info: https://github.com/kubernetes/community/blob/master/contributors/devel/sig-architecture/api-conventions.md#metadata Metadata Labels and Annotations gets propagated to the Alertmanager pods. |
| portName | string | `"web"` | PortName to use for Alert Manager. |
| priorityClassName | string | `""` | Priority class assigned to the Pods |
| prometheus.enabled | bool | `true` | Enables prometheus operator resources |
| prometheus.grafanaDashboard.enabled | bool | `true` | If `true`, deploy grafana dashboard |
| prometheus.grafanaDashboard.label | object | `{"grafana_dashboard":"1"}` | Labels to apply to dashboard configmap |
| prometheus.rules.labels | object | `{"prometheus":"prometheus-operator-prometheus"}` | Labels to affect to the Prometheus Rules |
| prometheus.serviceMonitor.annotations | object | `{}` | Map of annotations to apply to the ServiceMonitor |
| prometheus.serviceMonitor.bearerTokenFile | string | `nil` |  |
| prometheus.serviceMonitor.enabled | bool | `true` | Enables prometheus operator service monitor |
| prometheus.serviceMonitor.interval | string | `""` | Scrape interval. If not set, the Prometheus default scrape interval is used. dd |
| prometheus.serviceMonitor.labels | object | `{"prometheus":"prometheus-operator-prometheus"}` | Map of labels to apply to the servicemonitor |
| prometheus.serviceMonitor.metricRelabelings | list | `[]` | metric relabel configs to apply to samples before ingestion. |
| prometheus.serviceMonitor.relabelings | list | `[]` | Relabel configs to apply to samples before ingestion. |
| prometheus.serviceMonitor.scheme | string | `""` | HTTP scheme to use for scraping. Can be used with `tlsConfig` for example if using istio mTLS. |
| prometheus.serviceMonitor.tlsConfig | object | `{}` | TLS configuration to use when scraping the endpoint. For example if using istio mTLS. Of type: https://github.com/prometheus-operator/prometheus-operator/blob/master/Documentation/api.md#tlsconfig |
| replicaCount | int | `3` | Size is the expected size of the alertmanager cluster. The controller will eventually make the size of the running cluster equal to the expected size. |
| resources.limits.cpu | string | `"100m"` |  |
| resources.limits.memory | string | `"500Mi"` |  |
| resources.requests.cpu | string | `"5m"` |  |
| resources.requests.memory | string | `"200Mi"` |  |
| retention | string | `"120h"` | Time duration Alertmanager shall retain data for. Default is '120h', and must match the regular expression [0-9]+(ms|s|m|h) (milliseconds seconds minutes hours). |
| routePrefix | string | `"/"` | The route prefix Alertmanager registers HTTP handlers for. This is useful, if using ExternalURL and a proxy is rewriting HTTP routes of a request, and the actual ExternalURL is still true, but the server serves requests under a different route prefix. For example for use with kubectl proxy. |
| secrets | list | `[]` | List of Secrets in the same namespace as the Alertmanager object, which shall be mounted into the Alertmanager Pods. The Secrets are mounted into /etc/alertmanager/secrets/. |
| securityContext | object | `{"fsGroup":2000,"runAsGroup":2000,"runAsNonRoot":true,"runAsUser":1000}` | SecurityContext holds pod-level security attributes and common container settings. This defaults to non root user with uid 1000 and gid 2000.	*v1.PodSecurityContext	false ref: https://kubernetes.io/docs/tasks/configure-pod-container/security-context/ |
| service.annotations | object | `{}` | Map of annotations to apply to the service |
| service.clusterIP | string | `""` | Cluster IP Only use if service.type is "ClusterIP" |
| service.externalIPs | list | `[]` | List of IP addresses at which the Prometheus server service is available Ref: https://kubernetes.io/docs/user-guide/services/#external-ips |
| service.labels | object | `{}` | Map of labels to apply to the service |
| service.loadBalancerIP | string | `""` | Loadbalancer IP Only use if service.type is "loadbalancer" |
| service.loadBalancerSourceRanges | list | `[]` |  |
| service.nodePort | int | `30090` | Port to expose on each node Only used if service.type is 'NodePort' |
| service.port | int | `9093` | Port for Prometheus Service to listen on |
| service.sessionAffinity | string | `""` |  |
| service.targetPort | int | `9093` | To be used with a proxy extraContainer port |
| service.type | string | `"ClusterIP"` | Service type |
| serviceAccount.annotations | object | `{}` | Annotations for ServiceAccount |
| serviceAccount.automountServiceAccountToken | bool | `false` | automountServiceAccountToken |
| serviceAccount.create | bool | `true` | When `true`, create alertmanager serviceAccount with `serviceAccount.name`. If `serviceAccount.name` is empty, use `.Chart.fullname` value. |
| serviceAccount.name | string | `""` | Name of the ServiceAccount to use to run the Prometheus Pods. If `prometheus.serviceAccount.create` is `false` and no name is defined, use `default`. |
| storage | object | `{}` | Storage is the definition of how storage will be used by the Alertmanager instances. ref: https://github.com/prometheus-operator/prometheus-operator/blob/master/Documentation/user-guides/storage.md |
| tolerations | list | `[]` | If specified, the pod's tolerations. ref: https://kubernetes.io/docs/concepts/configuration/taint-and-toleration/ |
| useExistingSecret | bool | `false` | If true then the user will be responsible to provide a secret with alertmanager configuration So when true the config part will be ignored (including templateFiles) and the one in the secret will be used See `configSecret` |
| volumeMounts | list | `[]` | Additional VolumeMounts on the output StatefulSet definition. |
| volumes | list | `[]` | Additional volumes on the output StatefulSet definition. |

## Installing the Chart

### With Helm

To install the chart with the release name `my-release`:

```bash
helm repo add ekp-helm https://edixos.github.io/ekp-helm
helm install ekp-helm/alertmanager
```

### With ArgoCD

#### Cluster k8s with access to public registry

Add new application as:

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: alertmanager
spec:
  project: infra

  source:
    repoURL: "https://edixos.github.io/ekp-helm"
    targetRevision: "0.1.8"
    chart: alertmanager
    path: ''

    helm:

      values: |
        ""

  destination:
    server: https://kubernetes.default.svc
    namespace: "infra-monitoring"

  ignoreDifferences:
  - group: ""
    kind: Secret
    name: alertmanager-gatekeeper
    jsonPointers:
    - /data/secretId
    - /data/encyptionKey
```

## Develop

### Update documentation

Chart documentation is generated with [helm-docs](https://github.com/norwoodj/helm-docs) from `values.yaml` file.
After file modification, regenerate README.md with command:

```bash
docker run --rm -it -v $(pwd):/helm --workdir /helm jnorwood/helm-docs:v1.14.2 helm-docs
```

### Run linter

```bash
docker run --rm -it -w /charts -v $(pwd)/../../:/charts quay.io/helmpack/chart-testing:v3.12.0 ct lint --charts /charts/charts/alertmanager --config /charts/charts/alertmanager/ct.yaml
```

### Prometheus Rules

Check rules:

```bash
docker run --rm --entrypoint /bin/sh -v $(pwd):/workdir -w /workdir prom/prometheus -c -- "promtool check rules resources/prometheus-rules/*"
```

Test rules:

```bash
docker run --rm --entrypoint /bin/sh -v $(pwd):/workdir -w /workdir prom/prometheus -c -- "promtool test rules tests/prometheus/*"
```

### Run pluto

In order to check if the api-version used in this chart are not deprecated, or worse, removed, we use pluto to check it:

```
docker run --rm -it -v $(pwd):/apps -v pluto:/pluto alpine/helm:3.17 template alertmanager . -f tests/pluto/values.yaml --output-dir /pluto
docker run --rm -it -v pluto:/data us-docker.pkg.dev/fairwinds-ops/oss/pluto:v5 detect-files -d /data -o yaml --ignore-deprecations -t "k8s=v1.31.0,cert-manager=v1.17.0,istio=v1.24.0" -o wide
docker volume rm pluto
```
