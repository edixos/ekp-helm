{{- define "configmap.extra" -}}{{- end }}

{{- define "volumes.extra" -}}{{- end }}

{{- define "tetragon.volumemounts.extra" -}}{{- end }}

{{- define "tetragon.environment.extra" -}}{{- end }}

{{- define "initcontainers.extra" -}}{{- end }}

{{- define "containers.extra" -}}{{- end }}

{{- define "clusterrole.extra" -}}{{- end }}

{{- define "role.extra" -}}{{- end }}

{{- define "operatorconfigmap.extra" -}}{{- end }}

{{- define "operatorclusterrole.extra" -}}{{- end }}
