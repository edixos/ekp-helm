{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "zammad.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "zammad.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "zammad.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "zammad.labels" -}}
helm.sh/chart: {{ include "zammad.chart" . }}
{{ include "zammad.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- with .Values.commonLabels }}
{{ toYaml . }}
{{- end }}
{{- end -}}

{{/*
Pod labels
*/}}
{{- define "zammad.podLabels" -}}
{{ include "zammad.labels" . }}
{{- with .Values.podLabels }}
{{ toYaml . }}
{{- end }}
{{- end -}}

{{/*
Selector labels
*/}}
{{- define "zammad.selectorLabels" -}}
app.kubernetes.io/name: {{ include "zammad.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Common annotations
*/}}
{{- define "zammad.annotations" -}}
{{- with .Values.commonAnnotations }}
{{ toYaml . }}
{{- end }}
{{- end -}}

{{/*
Pod annotations
*/}}
{{- define "zammad.podAnnotations" -}}
{{ include "zammad.annotations" . }}
{{- with .Values.podAnnotations }}
{{ toYaml . }}
{{- end }}
{{- end -}}

{{/*
Create the name of the service account to use
*/}}
{{- define "zammad.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{ default (include "zammad.fullname" .) .Values.serviceAccount.name }}
{{- else -}}
{{ default "default" .Values.serviceAccount.name }}
{{- end -}}
{{- end -}}

{{/*
autowizard secret name
*/}}
{{- define "zammad.autowizardSecretName" -}}
{{- if .Values.secrets.autowizard.useExisting -}}
{{ .Values.secrets.autowizard.secretName }}
{{- else -}}
{{ include "zammad.fullname" . }}-{{ .Values.secrets.autowizard.secretName }}
{{- end -}}
{{- end -}}

{{/*
Name of the ECK Elasticsearch resource. Mirrors the eck-elasticsearch chart's
"elasticsearch.fullname" logic so that ECK-derived names (services, secrets)
stay correct even if elasticsearch.nameOverride/fullnameOverride are changed.
Also fails fast if the result exceeds ECK's 36-character resource name limit,
since the admission webhook's own rejection of an over-long name is opaque.
*/}}
{{- define "zammad.elasticsearchName" -}}
{{- $es := .Values.elasticsearch | default dict -}}
{{- $name := "" -}}
{{- if $es.fullnameOverride -}}
{{- $name = $es.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $base := default "elasticsearch" $es.nameOverride -}}
{{- if contains $base .Release.Name -}}
{{- $name = .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name = printf "%s-%s" .Release.Name $base | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- if gt (len $name) 36 -}}
{{- fail (printf "Elasticsearch resource name %q is %d characters, but the ECK operator caps names at 36. Shorten the release name or set a shorter elasticsearch.nameOverride/fullnameOverride." $name (len $name)) -}}
{{- end -}}
{{- $name -}}
{{- end -}}

{{/*
elasticsearch service host (in-cluster ECK service or external host)
*/}}
{{- define "zammad.elasticsearchHost" -}}
{{- if .Values.zammadConfig.elasticsearch.enabled -}}
{{ include "zammad.elasticsearchName" . }}-es-http
{{- else -}}
{{ .Values.zammadConfig.elasticsearch.host }}
{{- end -}}
{{- end -}}

{{/*
elasticsearch user (ECK creates the "elastic" superuser for the in-cluster service)
*/}}
{{- define "zammad.elasticsearchUser" -}}
{{- if .Values.zammadConfig.elasticsearch.enabled -}}
elastic
{{- else -}}
{{ .Values.zammadConfig.elasticsearch.user }}
{{- end -}}
{{- end -}}

{{/*
elasticsearch secret name
*/}}
{{- define "zammad.elasticsearchSecretName" -}}
{{- if .Values.zammadConfig.elasticsearch.enabled -}}
{{ include "zammad.elasticsearchName" . }}-es-elastic-user
{{- else if .Values.secrets.elasticsearch.useExisting -}}
{{ .Values.secrets.elasticsearch.secretName }}
{{- else -}}
{{ include "zammad.fullname" . }}-{{ .Values.secrets.elasticsearch.secretName }}
{{- end -}}
{{- end -}}

{{/*
elasticsearch secret key (ECK stores the password under the user name "elastic")
*/}}
{{- define "zammad.elasticsearchSecretKey" -}}
{{- if .Values.zammadConfig.elasticsearch.enabled -}}
elastic
{{- else -}}
{{ .Values.secrets.elasticsearch.secretKey }}
{{- end -}}
{{- end -}}

{{/*
postgresql secret name
*/}}
{{- define "zammad.postgresqlSecretName" -}}
{{- if .Values.secrets.postgresql.useExisting -}}
{{ .Values.secrets.postgresql.secretName }}
{{- else -}}
{{ include "zammad.fullname" . }}-{{ .Values.secrets.postgresql.secretName }}
{{- end -}}
{{- end -}}

{{/*
redis secret name
*/}}
{{- define "zammad.redisSecretName" -}}
{{- if .Values.secrets.redis.useExisting -}}
{{ .Values.secrets.redis.secretName }}
{{- else -}}
{{ include "zammad.fullname" . }}-{{ .Values.secrets.redis.secretName }}
{{- end -}}
{{- end -}}

{{/*
redis sentinel secret name
*/}}
{{- define "zammad.redisSentinelSecretName" -}}
{{- if .Values.secrets.redis.sentinel.useExisting -}}
{{ .Values.secrets.redis.sentinel.secretName }}
{{- else -}}
{{ include "zammad.fullname" . }}-{{ .Values.secrets.redis.sentinel.secretName }}
{{- end -}}
{{- end -}}

{{/*
Whether the init job should provision the S3 bucket. This only applies to the
bundled rustfs instance; an external S3 service is never modified, neither via
externalS3Url nor via a complete S3_URL supplied through secrets.s3.
Renders a non-empty string when enabled, so it can be used in "if" conditions.
*/}}
{{- define "zammad.s3.initialisation" -}}
{{- if and .Values.zammadConfig.rustfs.enabled .Values.zammadConfig.rustfs.bucketInitialisation (not .Values.zammadConfig.rustfs.externalS3Url) (not .Values.secrets.s3.useExisting) -}}
true
{{- end -}}
{{- end -}}

{{/*
Name of the resources created by the rustfs subchart. Mirrors the subchart's
"rustfs.fullname" logic so that the derived service name stays correct even if
rustfs.nameOverride/fullnameOverride are changed.
*/}}
{{- define "zammad.rustfsName" -}}
{{- $rustfs := .Values.rustfs | default dict -}}
{{- if $rustfs.fullnameOverride -}}
{{- $rustfs.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $base := default "rustfs" $rustfs.nameOverride -}}
{{- if contains $base .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $base | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
In-cluster S3 endpoint (host:port) of the bundled rustfs subchart. The subchart
appends "-svc" to its fullname for the client facing Service.
*/}}
{{- define "zammad.rustfsEndpoint" -}}
{{- $port := dig "service" "endpoint" "port" 9000 (.Values.rustfs | default dict) -}}
{{ include "zammad.rustfsName" . }}-svc:{{ $port }}
{{- end -}}

{{/*
S3 access URL
*/}}
{{- define "zammad.env.S3_URL" -}}
{{/* Helm silently ignores unknown keys, so without this an upgrade with an unchanged
     values.yaml would leave Zammad without an S3_URL and delete the old attachment
     volume unnoticed. */}}
{{- if or .Values.zammadConfig.minio .Values.minio -}}
{{- $hint := "" -}}
{{- if and .Values.zammadConfig.minio .Values.zammadConfig.minio.enabled -}}
{{- $hint = " The old attachment volume needs to be protected before upgrading, see the data migration in the upgrade notes." -}}
{{- end -}}
{{- fail (printf "zammadConfig.minio/minio were replaced by zammadConfig.rustfs/rustfs in chart 19.0.0.%s" $hint) -}}
{{- end -}}
{{/* Order matters: up to 18.x externalS3Url took precedence over secrets.s3, so
     keep it that way to not silently move an existing installation to a different
     endpoint. */}}
{{- if .Values.zammadConfig.rustfs.externalS3Url -}}
- name: S3_URL
  value: {{ .Values.zammadConfig.rustfs.externalS3Url | quote }}
{{- else if .Values.secrets.s3.useExisting -}}
- name: S3_URL
  valueFrom:
    secretKeyRef:
      name: {{ .Values.secrets.s3.secretName }}
      key: {{ .Values.secrets.s3.secretKey }}
{{- else if .Values.zammadConfig.rustfs.enabled -}}
{{- $bucket := .Values.zammadConfig.rustfs.bucket -}}
{{- $region := dig "config" "rustfs" "region" "zammad" (.Values.rustfs | default dict) -}}
{{- if .Values.rustfs.secret.existingSecret -}}
- name: RUSTFS_ACCESS_KEY
  valueFrom:
    secretKeyRef:
      key: RUSTFS_ACCESS_KEY
      name: {{ .Values.rustfs.secret.existingSecret }}
- name: RUSTFS_SECRET_KEY
  valueFrom:
    secretKeyRef:
      key: RUSTFS_SECRET_KEY
      name: {{ .Values.rustfs.secret.existingSecret }}
- name: S3_URL
  value: "http://$(RUSTFS_ACCESS_KEY):$(RUSTFS_SECRET_KEY)@{{ include "zammad.rustfsEndpoint" . }}/{{ $bucket }}?region={{ $region }}&force_path_style=true"
{{- else -}}
- name: S3_URL
  value: "http://{{ .Values.rustfs.secret.rustfs.access_key }}:{{ .Values.rustfs.secret.rustfs.secret_key }}@{{ include "zammad.rustfsEndpoint" . }}/{{ $bucket }}?region={{ $region }}&force_path_style=true"
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Redis Variables
*/}}
{{- define "zammad.env.redisVariables" -}}
{{- if .Values.zammadConfig.redis.sentinel.username }}
- name: REDIS_USERNAME
  value: "{{ .Values.zammadConfig.redis.username }}"
{{- end }}
{{- if or .Values.zammadConfig.redis.pass .Values.secrets.redis.useExisting }}
- name: REDIS_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ include "zammad.redisSecretName" . }}
      key: {{ .Values.secrets.redis.secretKey }}
{{- end }}
# sentinel
{{- if .Values.zammadConfig.redis.sentinel.enabled }}
- name: REDIS_SENTINELS
{{- if .Values.zammadConfig.redis.enabled }}
{{- if not (and .Values.redis.sentinel.enabled (eq .Values.redis.architecture "replication")) }}
{{ fail "zammadConfig.redis.sentinel.enabled requires redis.sentinel.enabled=true and redis.architecture=replication when the bundled Redis subchart is used (zammadConfig.redis.enabled=true); the Sentinel service is only created in that combination." }}
{{- end }}
  value: "{{ .Release.Name }}-redis-sentinel:26379"
{{- else }}
  value: "{{ join "," .Values.zammadConfig.redis.sentinel.sentinels }}"
{{- end }}
- name: REDIS_SENTINEL_NAME
  value: "{{ .Values.zammadConfig.redis.sentinel.masterName | default "mymaster" }}"
{{- if .Values.zammadConfig.redis.sentinel.username }}
- name: REDIS_SENTINEL_USERNAME
  value: "{{ .Values.zammadConfig.redis.sentinel.username }}"
{{- end }}
{{- if or .Values.zammadConfig.redis.sentinel.pass .Values.secrets.redis.useExisting }}
- name: REDIS_SENTINEL_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ include "zammad.redisSentinelSecretName" . }}
      key: {{ .Values.secrets.redis.sentinel.secretKey }}
{{- end }}
{{- else }}
# standalone
- name: REDIS_URL
  value: "redis{{ if .Values.zammadConfig.redis.tls }}s{{ end }}://{{ .Values.zammadConfig.redis.username }}:$(REDIS_PASSWORD)@{{ if .Values.zammadConfig.redis.enabled }}{{ .Release.Name }}-redis{{ else }}{{ .Values.zammadConfig.redis.host }}{{ end }}:{{ .Values.zammadConfig.redis.port }}"
{{- end }}
{{- end }}

{{/*
environment variables for the Zammad Rails stack
*/}}
{{- define "zammad.env" -}}
{{ include "zammad.env.redisVariables" . }}
- name: MEMCACHE_SERVERS
  value: "{{ if .Values.zammadConfig.memcached.enabled }}{{ .Release.Name }}-memcached{{ else }}{{ .Values.zammadConfig.memcached.host }}{{ end }}:{{ .Values.zammadConfig.memcached.port }}"
- name: RAILS_TRUSTED_PROXIES
  value: "{{ .Values.zammadConfig.railsserver.trustedProxies }}"
- name: POSTGRESQL_HOST
  value: {{ if .Values.zammadConfig.postgresql.enabled }}{{ .Release.Name }}-postgres{{ else }}{{ .Values.zammadConfig.postgresql.host }}{{ end }}
- name: POSTGRESQL_PORT
  value: {{ .Values.zammadConfig.postgresql.port | toString | toYaml }}
- name: POSTGRESQL_USER
  value: {{ .Values.zammadConfig.postgresql.user }}
- name: POSTGRESQL_PASS
  valueFrom:
    secretKeyRef:
      name: {{ include "zammad.postgresqlSecretName" . }}
      key: {{ .Values.secrets.postgresql.secretKey }}
- name: POSTGRESQL_DB
  value: {{ .Values.zammadConfig.postgresql.db }}
- name: POSTGRESQL_OPTIONS
  value: {{ .Values.zammadConfig.postgresql.options }}
{{ include "zammad.env.S3_URL" . }}
- name: TMP # All zammad containers need the possibility to create temporary files, e.g. for file uploads or image resizing.
  value: {{ .Values.zammadConfig.railsserver.tmpdir }}
{{- with .Values.extraEnv }}
{{ toYaml . }}
{{- end }}
{{- if .Values.autoWizard.enabled }}
- name: AUTOWIZARD_RELATIVE_PATH
  value: tmp/auto_wizard/auto_wizard.json
{{- end }}
{{- end -}}

{{/*
environment variable to let Rails fail during startup if migrations are pending
*/}}
{{- define "zammad.env.failOnPendingMigrations" -}}
# Let containers fail if migrations are pending.
- name: RAILS_CHECK_PENDING_MIGRATIONS
  value: 'true'
{{- end -}}

{{/*
volume mounts for the Zammad Rails stack
*/}}
{{- define "zammad.volumeMounts" -}}
- name: {{ include "zammad.fullname" . }}-tmp
  mountPath: /tmp
- name: {{ include "zammad.fullname" . }}-tmp
  mountPath: /opt/zammad/tmp
{{- if .Values.zammadConfig.storageVolume.enabled }}
- name: {{ include "zammad.fullname" . }}-storage
  mountPath: /opt/zammad/storage
{{- end -}}
{{- if .Values.autoWizard.enabled }}
- name: autowizard
  mountPath: "/opt/zammad/tmp/auto_wizard"
{{- end }}
{{- with .Values.zammadConfig.customVolumeMounts }}
{{ toYaml . }}
{{- end -}}
{{- end -}}

{{/*
volumes for the Zammad Rails stack
*/}}
{{- define "zammad.volumes" -}}
- name: {{ include "zammad.fullname" . }}-tmp
  {{- toYaml .Values.zammadConfig.tmpDirVolume | nindent 2 }}
{{- if .Values.zammadConfig.storageVolume.enabled }}
{{- if .Values.zammadConfig.storageVolume.existingClaim }}
- name: {{ include "zammad.fullname" . }}-storage
  persistentVolumeClaim:
    claimName: {{ .Values.zammadConfig.storageVolume.existingClaim | default (include "zammad.fullname" .) }}
{{- else }}
  {{ fail "Please provide an existing PersistentVolumeClaim with ReadWriteMany access if you enable .Values.zammadConfig.storageVolume." }}
{{- end -}}
{{- end -}}
{{- if .Values.autoWizard.enabled }}
- name: autowizard
  secret:
    secretName: {{ include "zammad.autowizardSecretName" . }}
    items:
    - key: {{ .Values.secrets.autowizard.secretKey }}
      path: auto_wizard.json
{{- end }}
{{- with .Values.zammadConfig.customVolumes }}
{{ toYaml . }}
{{- end -}}
{{- end -}}

{{/*
shared configuration for Zammad Pods
*/}}
{{- define "zammad.podSpec" -}}
{{- with .Values.image.imagePullSecrets }}
imagePullSecrets:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- if .Values.serviceAccount.create }}
serviceAccountName: {{ include "zammad.serviceAccountName" . }}
{{- end }}
{{- with .Values.nodeSelector }}
nodeSelector:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with .Values.affinity }}
affinity:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with .Values.tolerations }}
tolerations:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with .Values.securityContext }}
securityContext:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- end -}}

{{/*
init containers for Zammad Pods
*/}}
{{- define "zammad.podSpec.initContainers" -}}
{{- if .Values.zammadConfig.initContainers.volumePermissions.enabled }}
- name: zammad-volume-permissions
  image: "{{ .Values.zammadConfig.initContainers.volumePermissions.image.repository }}:{{ .Values.zammadConfig.initContainers.volumePermissions.image.tag }}"
  imagePullPolicy: {{ .Values.zammadConfig.initContainers.volumePermissions.image.pullPolicy }}
  command:
    {{- .Values.zammadConfig.initContainers.volumePermissions.command | toYaml | nindent 4 }}
  {{- with .Values.zammadConfig.initContainers.volumePermissions.resources }}
  resources:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- with .Values.zammadConfig.initContainers.volumePermissions.securityContext }}
  securityContext:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  volumeMounts:
    {{- include "zammad.volumeMounts" . | nindent 4 }}
{{- end }}
{{- end -}}

{{/*
shared configuration for Zammad Deployment Pods
*/}}
{{- define "zammad.podSpec.deployment" -}}
{{ include "zammad.podSpec" . }}
initContainers:
{{ include "zammad.podSpec.initContainers" . | nindent 2 }}
{{- end -}}

{{/*
shared configuration for Zammad containers
*/}}
{{- define "zammad.containerSpec" -}}
image: "{{ .Values.image.repository }}:{{ .Values.image.tag | default .Chart.AppVersion }}"
imagePullPolicy: {{ .Values.image.pullPolicy }}
{{- with .containerConfig.startupProbe }}
startupProbe:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with .containerConfig.livenessProbe }}
livenessProbe:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with .containerConfig.readinessProbe }}
readinessProbe:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with .containerConfig.resources }}
resources:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with .containerConfig.securityContext }}
securityContext:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- end -}}
