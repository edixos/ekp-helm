<p align="center">
    <a href="https://artifacthub.io/packages/helm/cloudpirates-redis/redis"><img src="https://img.shields.io/endpoint?url=https://artifacthub.io/badge/repository/cloudpirates-redis" /></a>
</p>

# Redis Helm Chart

An open source, in-memory data structure store used as a database, cache, and message broker.

## Quick Start

### Prerequisites

- Kubernetes 1.24+
- Helm 3.2.0+
- PV provisioner support in the underlying infrastructure (if persistence is enabled)

### Installation

Add the CloudPirates repository:

To install the chart with the release name `my-redis`:

```bash
helm install my-redis oci://registry-1.docker.io/cloudpirates/redis
```

To install with custom values:

```bash
helm install my-redis oci://registry-1.docker.io/cloudpirates/redis -f my-values.yaml
```

Or install directly from the local chart:

```bash
helm install my-redis ./charts/redis
```

### Getting Started

1. Get the Redis connection details:

```bash
# Get password
kubectl get secret my-redis -o jsonpath="{.data.redis-password}" | base64 -d

# Get full connection URI
kubectl get secret my-redis -o jsonpath="{.data.uri}" | base64 -d

# Get individual connection fields
kubectl get secret my-redis -o jsonpath="{.data.host}" | base64 -d
kubectl get secret my-redis -o jsonpath="{.data.port}" | base64 -d
kubectl get secret my-redis -o jsonpath="{.data.username}" | base64 -d
```

2. Connect to Redis from inside the cluster:

```bash
kubectl run redis-client --rm --tty -i --restart='Never' \
    --image redis:8.2.0 -- bash

# Inside the pod:
REDISCLI_AUTH="$REDIS_PASSWORD" redis-cli -h my-redis
```

## Security & Signature Verification

This Helm chart is cryptographically signed with Cosign to ensure authenticity and prevent tampering.

**Public Key:**

```
-----BEGIN PUBLIC KEY-----
MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE5U+rM2d3hDjgP5T3cLShuuQIU9vR
Z4/G+Nug6q5vRa+C3qUA1wXjbaJFAfcIrv5VjmYAYOj13shnPpp3Zh4fnQ==
-----END PUBLIC KEY-----
```

To verify the helm chart before installation, copy the public key to the file `cosign.pub` and run cosign:

```bash
cosign verify --key cosign.pub registry-1.docker.io/cloudpirates/redis:<version>
```

## Configuration

### Global parameters

| Parameter                 | Description                           | Default |
| ------------------------- | ------------------------------------- | ------- |
| `global.imageRegistry`    | Global Docker image registry override | `""`    |
| `global.imagePullSecrets` | Global Docker registry secret names   | `[]`    |

### Image Configuration

| Parameter          | Description            | Default                                                                         |
| ------------------ | ---------------------- | ------------------------------------------------------------------------------- |
| `image.registry`   | Redis image registry   | `docker.io`                                                                     |
| `image.repository` | Redis image repository | `redis`                                                                         |
| `image.tag`        | Redis image tag        | `8.4.0@sha256:43355efd22490e31ca14b9d569367d05121e2be61fd8e47937563ae2a80952ae` |
| `image.pullPolicy` | Image pull policy      | `Always`                                                                        |

### Common Parameters

| Parameter              | Description                                                                                                                                                                             | Default         |
| ---------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------- |
| `nameOverride`         | String to partially override redis.fullname                                                                                                                                             | `""`            |
| `fullnameOverride`     | String to fully override redis.fullname                                                                                                                                                 | `""`            |
| `namespaceOverride`    | String to override the namespace for all resources                                                                                                                                      | `""`            |
| `clusterDomain`        | Kubernetes cluster domain                                                                                                                                                               | `cluster.local` |
| `commonLabels`         | Labels to add to all deployed objects                                                                                                                                                   | `{}`            |
| `commonAnnotations`    | Annotations to add to all deployed objects                                                                                                                                              | `{}`            |
| `architecture`         | Redis architecture. `standalone`: Single instance, `cluster`: Multi-master cluster, `replication`: Master-replica (use `sentinel.enabled` to control automatic failover)                | `standalone`    |
| `replicaCount`         | Number of Redis instances (when `architecture=replication\|cluster`). As cluster or replication with Sentinel: total instances. Replication without Sentinel: 1 master + (n-1) replicas | `3`             |
| `clusterReplicaCount`  | Number of replicas to be created for each master when `architecture=cluster`.                                                                                                           | `0`             |
| `revisionHistoryLimit` | Number of revisions to keep in history for rollback (set to 0 for unlimited)                                                                                                            | `10`            |

### Pod labels and annotations

| Parameter        | Description                           | Default |
| ---------------- | ------------------------------------- | ------- |
| `podLabels`      | Map of labels to add to the pods      | `{}`    |
| `podAnnotations` | Map of annotations to add to the pods | `{}`    |

### Service Configuration

| Parameter             | Description                    | Default     |
| --------------------- | ------------------------------ | ----------- |
| `service.annotations` | Kubernetes service annotations | `{}`        |
| `service.type`        | Kubernetes service type        | `ClusterIP` |
| `service.port`        | Redis service port             | `6379`      |
| `service.nodePort`    | NodePort value for NodePort and LoadBalancer service types | `""` |
| `service.clusterPort` | Redis cluster service port     | `16379`     |

### Authentication

| Parameter                        | Description                                                  | Default |
| -------------------------------- | ------------------------------------------------------------ | ------- |
| `auth.enabled`                   | Enable Redis authentication                                  | `true`  |
| `auth.sentinel`                  | Enable authentication for Redis sentinels using the shared Redis password (with `auth.acl`, the `auth.acl.defaultUsername` user's password) | `true`  |
| `auth.metrics`                   | Enable authentication for Redis metrics sidecar              | `true`  |
| `auth.password`                  | Redis password (if empty, random password will be generated) | `""`    |
| `auth.existingSecret`            | Name of existing secret containing Redis password            | `""`    |
| `auth.existingSecretPasswordKey` | Key in existing secret containing Redis password             | `""`    |
| `auth.acl.enabled`               | Enable custom ACL rules from a secret file                   | `false` |
| `auth.acl.existingSecret`        | Name of existing secret containing ACL rules                 | `""`    |
| `auth.acl.existingSecretACLKey`  | Key in existing secret containing ACL rules                  | `""`    |
| `auth.acl.existingFilePath`      | Path to existing ACL file injected by Vault Agent Injector (mutually exclusive with existingSecret) | `""`    |
| `auth.acl.defaultUsername`       | ACL username in the ACL file used as the main/default Redis user (e.g. for probes and clients) | `default` |
| `auth.acl.sentinelUsername`      | ACL username in the ACL file Sentinel uses to authenticate to the monitored Redis instances | `sentinel` |

#### Connection Details Secret

When `auth.enabled` is `true` and no `auth.existingSecret` or `auth.acl.enabled` is set, the chart creates a Secret containing full connection details:

| Key              | Description                                                                 |
| ---------------- | --------------------------------------------------------------------------- |
| `redis-password` | The Redis password (base64 encoded)                                         |
| `host`           | The Redis service hostname: `<fullname>.<namespace>.svc` (base64 encoded)   |
| `port`           | The Redis service port (base64 encoded). Uses `tls.port` when TLS is enabled |
| `username`       | The Redis username: `default` (base64 encoded)                              |
| `uri`            | Full connection URI: `redis://default:<password>@<host>:<port>` (base64 encoded). Uses `rediss://` scheme when TLS is enabled |

#### ACL Configuration

Redis ACL (Access Control List) allows fine-grained access control with user-specific permissions. When ACL is enabled, all users including the 'default' user must be explicitly configured in the ACL file.

**Using Kubernetes Secret (existingSecret):**

```yaml
auth:
  acl:
    enabled: true
    existingSecret: "my-redis-acl"
    existingSecretACLKey: "users.acl"
```

**Using Vault Agent Injector (existingFilePath):**

```yaml
auth:
  acl:
    enabled: true
    existingFilePath: "/vault/secrets/redis-acl"
```

**ACL File Format Example:**

```
user default on >masterpassword ~* &* +@all
user readonly on >readonlypassword ~* +@read
user sentinel on >sentinelpassword allchannels +multi +slaveof +ping +exec +subscribe +config|rewrite +role +publish +info +client|setname +client|kill +script|kill
```

**Notes:**

- `existingSecret` and `existingFilePath` are mutually exclusive
- When using `existingFilePath`, no volume mounting is performed - the file must be available at the specified path
- The ACL file must contain at least the user named by `auth.acl.defaultUsername` (`default` unless overridden)
- For Sentinel deployments, include a user named by `auth.acl.sentinelUsername` (`sentinel` unless overridden), or the `defaultUsername` user will be used instead. Sentinel logs in to Redis as this user, so it needs the monitoring permissions shown in the example above (from the [Redis Sentinel docs](https://redis.io/docs/latest/operate/oss_and_stack/management/sentinel/#redis-access-control-list-authentication)); without them Sentinel cannot detect failures or fail over
- `auth.acl.sentinelUsername` only covers Sentinel's connections *to* Redis. With `auth.sentinel`, clients connect to the Sentinel port with the `defaultUsername` user's password; use [Sentinel ACL Configuration](#sentinel-acl-configuration) for separate Sentinel credentials
- This is separate from Sentinel's own ACL, which secures connections *to* the Sentinel process itself - see [Sentinel ACL Configuration](#sentinel-acl-configuration)

### TLS/SSL Configuration

| Parameter                       | Description                                                                                                                | Default    |
| ------------------------------- | -------------------------------------------------------------------------------------------------------------------------- | ---------- |
| `tls.enabled`                   | Enable TLS/SSL for Redis connections                                                                                       | `false`    |
| `tls.existingSecret`            | Name of an existing secret containing TLS certificates (expected keys: tls.crt, tls.key, ca.crt)                           | `""`       |
| `tls.certFilename`              | Server certificate filename in the secret                                                                                  | `tls.crt`  |
| `tls.certKeyFilename`           | Server certificate key filename in the secret                                                                              | `tls.key`  |
| `tls.certCAFilename`            | CA certificate filename in the secret                                                                                      | `ca.crt`   |
| `tls.port`                      | TLS port for Redis                                                                                                         | `6380`     |
| `tls.authClients`               | Require clients to authenticate with a valid client certificate                                                            | `true`     |
| `tls.client.existingSecret`     | Name of an existing secret containing client TLS certificates (expected keys: tls.crt, tls.key). Used for probes.          | `""`       |
| `tls.client.certFilename`       | Client certificate filename in the secret                                                                                  | `tls.crt`  |
| `tls.client.certKeyFilename`    | Client certificate key filename in the secret                                                                              | `tls.key`  |

### Redis Configuration

| Parameter                     | Description                          | Default                |
| ----------------------------- | ------------------------------------ | ---------------------- |
| `config.mountPath`            | Redis configuration mount path       | `/usr/local/etc/redis` |
| `config.content`              | Custom Redis configuration as string | See values.yaml        |
| `config.existingConfigmap`    | Name of existing ConfigMap to use    | `""`                   |
| `config.existingConfigmapKey` | Key in existing ConfigMap            | `""`                   |

### Redis Cluster Configuration (only applicable when `architecture=cluster`)

| Parameter | Description | Default |
| --------- | ----------- | ------- |
| `cluster.announceHostnames` | Enable hostname-based announcements for Redis Cluster (recommended for Kubernetes). When enabled, Redis announces pod hostnames instead of IPs, making the cluster more resilient to pod restarts | `false` |
| `cluster.announceHostnamesOverride` | Map of hostnames to announce for Redis Cluster topology. Overrides the default behavior of announcing pod hostnames. Useful for external access with LoadBalancers. Only works if `announceHostnames` is `true` (e.g. `0: foo-bar-0`) | `{}` |
| `cluster.announceIpsOverride` | Map of IPs to announce for Redis Cluster topology. Overrides the default behavior of announcing pod IPs. Useful for external access with LoadBalancers. Only works if `announceHostnames` is `false` (e.g. `0: 1.2.3.4`) | `{}` |
| `cluster.startupSleepTime` | Seconds to sleep in the init container before configuring Redis Cluster. Useful when persistence is disabled: gives the cluster time to detect a failed master and elect a new one before the restarting pod rejoins, preventing the old master from re-entering as master with an empty dataset. Set to `0` to disable | `0` |
| `cluster.config.nodeTimeout` | Cluster node timeout in milliseconds | `15000` |
| `cluster.config.requireFullCoverage` | Require full coverage to accept queries | `true` |

### Metrics

| Parameter                                  | Description                                                                             | Default                    |
| ------------------------------------------ | --------------------------------------------------------------------------------------- | -------------------------- |
| `metrics.enabled`                          | Start a sidecar Prometheus exporter to expose Redis metrics                             | `false`                    |
| `metrics.image.registry`                   | Redis exporter image registry                                                           | `docker.io`                |
| `metrics.image.repository`                 | Redis exporter image repository                                                         | `oliver006/redis_exporter` |
| `metrics.image.tag`                        | Redis exporter image tag                                                                | `v1.80.1-alpine`           |
| `metrics.image.pullPolicy`                 | Redis exporter image pull policy                                                        | `Always`                   |
| `metrics.resources`                        | Resource limits and requests for metrics container                                      | `{}`                       |
| `metrics.extraArgs`                        | Extra arguments for Redis exporter (e.g. `--redis.addr`, `--web.listen-address`)        | `[]`                       |
| `metrics.tls`                              | Enable TLS for Redis metrics exporter endpoints                                         | `false`                    |
| `metrics.port`                             | Port that the metrics server and endpoint is running on                                 | `9121`                     |
| `metrics.service.enabled`                  | Enable the dedicated metrics service                                                    | `true`                     |
| `metrics.service.type`                     | Metrics service type                                                                    | `ClusterIP`                |
| `metrics.service.name`                     | Metrics service name                                                                    | `http-metrics`             |
| `metrics.service.port`                     | Metrics service port                                                                    | `9121`                     |
| `metrics.service.annotations`              | Additional custom annotations for Metrics service                                       | `{}`                       |
| `metrics.service.loadBalancerIP`           | LoadBalancer IP if metrics service type is `LoadBalancer`                               | `""`                       |
| `metrics.service.loadBalancerSourceRanges` | Addresses allowed when metrics service is `LoadBalancer`                                | `[]`                       |
| `metrics.service.clusterIP`                | Static clusterIP or None for headless services when metrics service type is `ClusterIP` | `""`                       |
| `metrics.service.nodePort`                 | NodePort value for LoadBalancer and NodePort service types                              | `""`                       |
| `metrics.serviceMonitor.enabled`           | Create ServiceMonitor resource(s) for scraping metrics using Prometheus Operator        | `false`                    |
| `metrics.serviceMonitor.namespace`         | Namespace in which to create ServiceMonitor resource(s)                                 | `""`                       |
| `metrics.serviceMonitor.interval`          | Interval at which metrics should be scraped                                             | `30s`                      |
| `metrics.serviceMonitor.scrapeTimeout`     | Timeout after which the scrape is ended                                                 | `""`                       |
| `metrics.serviceMonitor.relabelings`       | Additional relabeling of metrics                                                        | `[]`                       |
| `metrics.serviceMonitor.metricRelabelings` | Additional metric relabeling of metrics                                                 | `[]`                       |
| `metrics.serviceMonitor.honorLabels`       | Honor metrics labels                                                                    | `false`                    |
| `metrics.serviceMonitor.selector`          | Prometheus instance selector labels                                                     | `{}`                       |
| `metrics.serviceMonitor.annotations`       | Additional custom annotations for the ServiceMonitor                                    | `{}`                       |
| `metrics.serviceMonitor.namespaceSelector` | Namespace selector for ServiceMonitor                                                   | `{}`                       |

### Pod Disruption Budget

| Parameter            | Description                                                    | Default |
| -------------------- | -------------------------------------------------------------- | ------- |
| `pdb.enabled`        | Enable Pod Disruption Budget                                   | `false` |
| `pdb.minAvailable`   | Minimum number/percentage of pods that should remain scheduled | `1`     |
| `pdb.maxUnavailable` | Maximum number/percentage of pods that may be made unavailable | `""`    |

### Persistence

| Parameter                   | Description                                                 | Default         |
| --------------------------- | ----------------------------------------------------------- | --------------- |
| `persistence.enabled`       | Enable persistent storage                                   | `true`          |
| `persistence.storageClass`  | Storage class for persistent volume                         | `""`            |
| `persistence.accessMode`    | Access mode for persistent volume                           | `ReadWriteOnce` |
| `persistence.size`          | Size of persistent volume                                   | `8Gi`           |
| `persistence.mountPath`     | Mount path for Redis data                                   | `/data`         |
| `persistence.annotations`   | Annotations for persistent volume claims                    | `{}`            |
| `persistence.existingClaim` | The name of an existing PVC to use for persistence          | `""`            |
| `persistence.subPath`       | The subdirectory of the volume to mount to                  | `""`            |
| `persistence.labels`        | Map of labels to add to the Persistent Volume Claims (PVCs) | `""`            |

### Persistent Volume Claim Retention Policy

| Parameter                                          | Description                                                                    | Default    |
| -------------------------------------------------- | ------------------------------------------------------------------------------ | ---------- |
| `persistentVolumeClaimRetentionPolicy.enabled`     | Enable Persistent volume retention policy for the StatefulSet                  | `false`    |
| `persistentVolumeClaimRetentionPolicy.whenDeleted` | Volume retention behavior that applies when the StatefulSet is deleted         | `"Retain"` |
| `persistentVolumeClaimRetentionPolicy.whenScaled`  | Volume retention behavior when the replica count of the StatefulSet is reduced | `"Retain"` |

### Resource Management

| Parameter   | Description                                | Default |
| ----------- | ------------------------------------------ | ------- |
| `resources` | Resource limits and requests for Redis pod | `{}`    |

### Pod Assignment / Eviction

| Parameter                   | Description                                    | Default |
| --------------------------- | ---------------------------------------------- | ------- |
| `nodeSelector`              | Node selector for pod assignment               | `{}`    |
| `priorityClassName`         | Priority class for pod eviction                | `""`    |
| `tolerations`               | Tolerations for pod assignment                 | `[]`    |
| `affinity`                       | Affinity rules for pod assignment                                                          | `{}`    |
| `terminationGracePeriodSeconds`  | Seconds Kubernetes waits for pod to terminate gracefully (recommended: 60 for Sentinel)   | `30`    |
| `topologySpreadConstraints`      | Topology spread constraints for pod assignment                                             | `[]`    |

### Security Context

| Parameter                                           | Description                       | Default          |
| --------------------------------------------------- | --------------------------------- | ---------------- |
| `containerSecurityContext.runAsUser`                | User ID to run the container      | `999`            |
| `containerSecurityContext.runAsGroup`               | Group ID to run the container     | `999`            |
| `containerSecurityContext.runAsNonRoot`             | Run as non-root user              | `true`           |
| `containerSecurityContext.privileged`               | Set container's privileged mode   | `false`          |
| `containerSecurityContext.allowPrivilegeEscalation` | Allow privilege escalation        | `false`          |
| `containerSecurityContext.readOnlyRootFilesystem`   | Read-only root filesystem         | `true`           |
| `containerSecurityContext.capabilities.drop`        | Linux capabilities to be dropped  | `["ALL"]`        |
| `containerSecurityContext.seccompProfile.type`      | Seccomp profile for the container | `RuntimeDefault` |
| `podSecurityContext.fsGroup`                        | Pod's Security Context fsGroup    | `999`            |

### Health Checks

#### Liveness Probe

| Parameter                           | Description                                     | Default |
| ----------------------------------- | ----------------------------------------------- | ------- |
| `livenessProbe.enabled`             | Enable liveness probe                           | `true`  |
| `livenessProbe.initialDelaySeconds` | Initial delay before starting probes            | `30`    |
| `livenessProbe.periodSeconds`       | How often to perform the probe                  | `10`    |
| `livenessProbe.timeoutSeconds`      | Timeout for each probe attempt                  | `5`     |
| `livenessProbe.failureThreshold`    | Number of failures before pod is restarted      | `6`     |
| `livenessProbe.successThreshold`    | Number of successes to mark probe as successful | `1`     |

#### Readiness Probe

| Parameter                            | Description                                     | Default |
| ------------------------------------ | ----------------------------------------------- | ------- |
| `readinessProbe.enabled`             | Enable readiness probe                          | `true`  |
| `readinessProbe.initialDelaySeconds` | Initial delay before starting probes            | `5`     |
| `readinessProbe.periodSeconds`       | How often to perform the probe                  | `10`    |
| `readinessProbe.timeoutSeconds`      | Timeout for each probe attempt                  | `5`     |
| `readinessProbe.failureThreshold`    | Number of failures before pod is marked unready | `6`     |
| `readinessProbe.successThreshold`    | Number of successes to mark probe as successful | `1`     |

### Redis Sentinel Configuration (High Availability)

Redis Sentinel provides high availability for Redis through automatic failover. When enabled in `replication` mode, Sentinel monitors the master and replicas, and promotes a replica to master if the current master becomes unavailable. When disabled with `replication` mode, pod-0 is always the master.

| Parameter                                     | Description                                                                                   | Default     |
| --------------------------------------------- | --------------------------------------------------------------------------------------------- | ----------- |
| `sentinel.enabled`                            | Enable Redis Sentinel for high availability. When disabled, pod-0 is master (manual failover) | `false`     |
| `sentinel.image.registry`                     | Redis Sentinel image registry                                                                 | `docker.io` |
| `sentinel.image.repository`                   | Redis Sentinel image repository                                                               | `redis`     |
| `sentinel.image.tag`                          | Redis Sentinel image tag                                                                      | `8.8.1`     |
| `sentinel.image.pullPolicy`                   | Sentinel image pull policy                                                                    | `Always`    |
| `sentinel.config.announceHostnames`           | Use the hostnames instead of the IP in "announce-ip" commands                                 | `true`      |
| `sentinel.masterName`                         | Name of the master server                                                                     | `mymaster`  |
| `sentinel.monitorTarget`                      | Override Sentinel master discovery with an explicit hostname or IP (multi-region/multi-cluster) | `""`        |
| `sentinel.idSeed`                             | Seed for a stable Sentinel id across restarts; defaults to the release fullname                 | `""`        |
| `sentinel.quorum`                             | Number of Sentinels needed to agree on master failure                                         | `2`         |
| `sentinel.downAfterMilliseconds`              | Time in ms after master is declared down                                                      | `30000`     |
| `sentinel.failoverTimeout`                    | Timeout for failover in ms                                                                    | `180000`    |
| `sentinel.parallelSyncs`                      | Number of replicas to reconfigure during failover                                             | `1`         |
| `sentinel.loglevel`                           | Sentinel log level (debug, verbose, notice, warning). When 'debug', full config is logged     | `notice`    |
| `sentinel.port`                               | Sentinel port                                                                                 | `26379`     |
| `sentinel.service.type`                       | Kubernetes service type for Sentinel                                                          | `ClusterIP` |
| `sentinel.service.port`                       | Sentinel service port                                                                         | `26379`     |
| `sentinel.resources`                          | Resource limits and requests for Sentinel pods                                                | `{}`        |
| `sentinel.extraVolumeMounts`                  | Additional volume mounts for Sentinel container                                               | `[]`        |
| `sentinel.redisShutdownWaitFailover`          | Whether Redis waits for Sentinel failover before shutdown (zero-downtime upgrades)            | `true`      |
| `sentinel.preStop.enabled`                    | Enable preStop hook for Sentinel container (waits for failover before terminating)            | `true`      |
| `sentinel.livenessProbe.enabled`              | Enable liveness probe                                                                         | `true`      |
| `sentinel.livenessProbe.initialDelaySeconds`  | Initial delay before starting probes                                                          | `30`        |
| `sentinel.livenessProbe.periodSeconds`        | How often to perform the probe                                                                | `10`        |
| `sentinel.livenessProbe.timeoutSeconds`       | Timeout for each probe attempt                                                                | `5`         |
| `sentinel.livenessProbe.failureThreshold`     | Number of failures before pod is restarted                                                    | `6`         |
| `sentinel.livenessProbe.successThreshold`     | Number of successes to mark probe as successful                                               | `1`         |
| `sentinel.readinessProbe.enabled`             | Enable readiness probe                                                                        | `true`      |
| `sentinel.readinessProbe.initialDelaySeconds` | Initial delay before starting probes                                                          | `5`         |
| `sentinel.readinessProbe.periodSeconds`       | How often to perform the probe                                                                | `10`        |
| `sentinel.readinessProbe.timeoutSeconds`      | Timeout for each probe attempt                                                                | `5`         |
| `sentinel.readinessProbe.failureThreshold`    | Number of failures before pod is marked unready                                               | `6`         |
| `sentinel.readinessProbe.successThreshold`    | Number of successes to mark probe as successful                                               | `1`         |
| `sentinel.masterService.affinity`             | Affinity rules for the master discovery deployment (defaults to `affinity` if not set)        | `{}`        |

### Sentinel ACL Configuration

Sentinel can run its own independent ACL, securing connections *to* the Sentinel process itself (e.g. `redis-cli` clients, the preStop failover hook, and the master-discovery controller). This is separate from `auth.acl`, which secures the monitored Redis instances - the two can be enabled independently or together.

| Parameter                            | Description                                                        | Default              |
| ------------------------------------- | ------------------------------------------------------------------- | --------------------- |
| `sentinel.acl.enabled`                | Enable custom ACL rules for Sentinel from a secret file            | `false`                |
| `sentinel.acl.existingSecret`         | Name of existing secret containing the Sentinel ACL rules          | `""`                    |
| `sentinel.acl.existingSecretACLKey`   | Key in existing secret containing the Sentinel ACL rules           | `""`                    |
| `sentinel.acl.existingFilePath`       | Path to existing Sentinel ACL file injected by Vault Agent Injector (mutually exclusive with existingSecret) | `""` |
| `sentinel.acl.defaultUsername`        | ACL username in the Sentinel ACL file used to authenticate to Sentinel | `default`           |

**Using Kubernetes Secret (existingSecret):**

```yaml
sentinel:
  acl:
    enabled: true
    existingSecret: "my-sentinel-acl"
    existingSecretACLKey: "sentinel-users.acl"
```

**ACL File Format Example:**

```
user default on >sentinelpassword ~* &* +@all
```

**Notes:**

- `existingSecret` and `existingFilePath` are mutually exclusive
- The ACL file must contain at least the user named by `sentinel.acl.defaultUsername`
- A user is disabled unless its line includes `on`, and has no Pub/Sub channel permissions unless it is granted `&*` (or `allchannels`). Sentinel-aware clients subscribe to Sentinel events such as `+switch-master`, so the user they authenticate as needs channel permissions, or they get `NOPERM`
- Setting the `aclfile` directive alone is what enables ACL auth on the Sentinel process; no other configuration is needed for clients to authenticate with the users it defines
- Sentinels authenticate to each other with the Sentinel ACL user's credentials: `sentinel sentinel-user` / `sentinel sentinel-pass` are set to the `sentinel.acl.defaultUsername` user and its password from the ACL file

### ServiceAccount

| Parameter                                     | Description                                                                                                                             | Default |
| --------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------- | ------- |
| `serviceAccount.annotations`                  | Additional custom annotations for the ServiceAccount                                                                                    | `{}`    |
| `serviceAccount.automountServiceAccountToken` | Automount service account token inside the Redis pods                                                                                   | `false` |
| `serviceAccount.create`                       | Enable the creation of a ServiceAccount                                                                                                 | `false` |
| `serviceAccount.name`                         | Name of the ServiceAccount to use. If not set and `serviceAccount.create` is `true`, a name is generated using the `fullname` template. | `""`    |

### Additional Configuration

| Parameter             | Description                                                             | Default |
| --------------------- | ----------------------------------------------------------------------- | ------- |
| `extraEnvVars`        | Additional environment variables to set                                 | `[]`    |
| `extraVolumes`        | Additional volumes to add to the pod                                    | `[]`    |
| `extraVolumeMounts`   | Additional volume mounts for Redis container                            | `[]`    |
| `extraObjects`        | A list of additional Kubernetes objects to deploy alongside the release | `[]`    |
| `extraPorts`          | Additional ports to be exposed by Services and StatefulSet              | `[]`    |
| `extraInitContainers` | Additional init containers to add to the pod                            | `[]`    |
| `extraContainers`     | Additional containers to add to the pod                                 | `[]`    |
| `dnsConfig`           | DNS configuration for the pod                                           | `{}`    |

### Custom Scripts and Hooks

| Parameter                        | Description                                                                  | Default |
| -------------------------------- | ---------------------------------------------------------------------------- | ------- |
| `customScripts.postStart.enabled` | Enable postStart lifecycle hook                                             | `false` |
| `customScripts.postStart.command` | Command to execute in postStart hook                                        | `[]`    |
| `customScripts.preStop.enabled`   | Enable preStop lifecycle hook (overrides default Sentinel preStop hook)     | `false` |
| `customScripts.preStop.command`   | Command to execute in preStop hook                                          | `[]`    |

### Configurations for the Job-Template

| Parameter                     | Description                                                                        | Default |
| ----------------------------- | ---------------------------------------------------------------------------------- | ------- |
| `clusterInitJob.resources`    | Resource limits and requests for clusterInit Job                                   | `{}`    |
| `clusterInitJob.nodeSelector` | Node selector for the clusterInit Job (defaults to `.Values.nodeSelector` if unset)| `{}`    |
| `clusterInitJob.tolerations`  | Tolerations for the clusterInit Job (defaults to `.Values.tolerations` if unset)   | `[]`    |
| `clusterInitJob.affinity`     | Affinity rules for the clusterInit Job (defaults to `.Values.affinity` if unset)   | `{}`    |

#### Extra Objects

You can use the `extraObjects` array to deploy additional Kubernetes resources (such as NetworkPolicies, ConfigMaps, etc.) alongside the release. This is useful for customizing your deployment with extra manifests that are not covered by the default chart options.

**Helm templating is supported in any field, but all template expressions must be quoted.** For example, to use the release namespace, write `namespace: "{{ .Release.Namespace }}"`.

**Example: Deploy a NetworkPolicy with templating**

```yaml
extraObjects:
  - apiVersion: networking.k8s.io/v1
    kind: NetworkPolicy
    metadata:
      name: allow-dns
      namespace: "{{ .Release.Namespace }}"
    spec:
      podSelector: {}
      policyTypes:
        - Egress
      egress:
        - to:
            - namespaceSelector:
                matchLabels:
                  kubernetes.io/metadata.name: kube-system
              podSelector:
                matchLabels:
                  k8s-app: kube-dns
        - ports:
            - port: 53
              protocol: UDP
            - port: 53
              protocol: TCP
```

All objects in `extraObjects` will be rendered and deployed with the release. You can use any valid Kubernetes manifest, and reference Helm values or built-in objects as needed (just remember to quote template expressions).

## Examples

### Basic Deployment

```bash
helm install my-redis ./charts/redis
```

### Using Existing Secret for Authentication

```yaml
# values-external-secret.yaml
auth:
  enabled: true
  existingSecret: "redis-credentials"
  existingSecretPasswordKey: "password"
```

### High Availability with Redis Sentinel

Deploy Redis with master-replica architecture and Sentinel for automatic failover:

```yaml
# values-ha.yaml
architecture: replication
replicaCount: 2

sentinel:
  enabled: true
  quorum: 2
  downAfterMilliseconds: 30000
  failoverTimeout: 180000
  redisShutdownWaitFailover: true  # Redis waits for failover before shutdown
  preStop:
    enabled: true  # Sentinel waits for failover before terminating

# Required for graceful failover during helm upgrades
terminationGracePeriodSeconds: 60

auth:
  enabled: true
```

```bash
helm install my-redis ./charts/redis -f values-ha.yaml
```

After deployment, you'll have:

- 1 Redis master instance
- 2 Redis replica instances
- 3 Redis Sentinel instances (for monitoring and failover)

**Connecting to Redis with Sentinel:**

```bash
# Get the Redis password
REDIS_PASSWORD=$(kubectl get secret my-redis -o jsonpath="{.data.redis-password}" | base64 -d)

# Connect to Sentinel to discover the current master
kubectl run redis-client --rm --tty -i --restart='Never' \
    --image redis:8.2.1 -- bash

# Inside the pod:
redis-cli -h my-redis-sentinel -p 26379 sentinel get-master-addr-by-name mymaster

# Connect to the current master (address from previous command)
REDISCLI_AUTH="$REDIS_PASSWORD" redis-cli -h <master-ip> -p 6379
```

### Master-Replica without Sentinel

Deploy Redis with replication but without Sentinel for scenarios where automatic failover is not needed:

```yaml
architecture: replication
replicaCount: 3 # 1 master + 2 replicas
sentinel:
  enabled: false

auth:
  enabled: true
```

After deployment, you'll have:

- 1 Redis master instance (pod-0, always the master)
- 2 Redis replica instances (pod-1, pod-2)
- No automatic failover (manual intervention required if master fails)

**Key differences from Sentinel mode:**

- Pod-0 is always the master, other pods are always replicas
- No automatic failover - if the master fails, manual intervention is required
- Simpler setup with fewer components
- Lower resource usage (no Sentinel containers)

### Cluster mode

Deploy Redis Cluster with 6 nodes - 3 master and 3 replicas for automated failover:

```yaml
# values-cluster.yaml
architecture: cluster
replicaCount: 6
clusterReplicaCount: 1
```

```bash
helm install my-redis ./charts/redis -f values-cluster.yaml
```

**Key differences with replication**

- Redis Cluster supports single database only
- Data is automatically divided across multiple nodes for improved performance
- With cluster-aware client, user can connect to any node (directly or via service) and requests will be automatically redirected, based on MOVED response

#### External access

A Redis Cluster client connects to one node and is then redirected to the others using the addresses returned by `CLUSTER NODES` / `CLUSTER SLOTS`. Inside Kubernetes the chart announces pod hostnames/IPs, which clients outside the cluster cannot reach. Enable `cluster.externalAccess` so each node announces an externally-reachable address and (optionally) gets its own Service.

Because a Redis node must announce a fixed address, the external addresses have to be known up front — pre-allocate one static `LoadBalancer` IP per pod (or use `NodePort` with the nodes' external IPs). Provide exactly one entry per pod in `cluster.externalAccess.addresses` (ordinal `0` first).

```yaml
# values-cluster-external.yaml
architecture: cluster
replicaCount: 6
clusterReplicaCount: 1
cluster:
  externalAccess:
    enabled: true
    # One externally-reachable address per pod (pod-0 first). IPs use cluster-announce-ip,
    # hostnames use cluster-announce-hostname.
    addresses:
      - 203.0.113.10
      - 203.0.113.11
      - 203.0.113.12
      - 203.0.113.13
      - 203.0.113.14
      - 203.0.113.15
    service:
      type: LoadBalancer
      # Pre-allocated static LoadBalancer IPs, matching the addresses above
      loadBalancerIPs:
        - 203.0.113.10
        - 203.0.113.11
        - 203.0.113.12
        - 203.0.113.13
        - 203.0.113.14
        - 203.0.113.15
```

Each per-pod Service exposes both the client port (`service.port`) and the cluster bus port (`service.clusterPort`); both must be reachable by clients and by the other nodes.

## Upgrading

To upgrade your Redis installation:

```bash
helm upgrade my-redis cloudpirates/redis
```

### Upgrading from 0.34.x to 0.35.0 or later with `auth.acl` and Sentinel

0.35.0 changed how a `sentinel` user in the `auth.acl` file (or the user named by `auth.acl.sentinelUsername`) is used:

| | 0.34.x (StatefulSet mode) | 0.35.0 and later |
| --- | --- | --- |
| Password clients send to the Sentinel port (`requirepass`) | the `sentinel` user's password | the `auth.acl.defaultUsername` user's password |
| User Sentinel logs in to Redis as | `default` | the `auth.acl.sentinelUsername` user (`sentinel auth-user`) |

If your clients authenticate to Sentinel with the `sentinel` user's password, or that user has no command permissions, do the following before upgrading:

1. Grant the `auth.acl.sentinelUsername` user the monitoring permissions shown in [ACL File Format Example](#acl-configuration), otherwise Sentinel cannot detect failures or fail over:

   ```
   user sentinel on >sentinelpassword allchannels +multi +slaveof +ping +exec +subscribe +config|rewrite +role +publish +info +client|setname +client|kill +script|kill
   ```

2. To keep a separate credential for clients connecting to Sentinel, enable a [Sentinel ACL](#sentinel-acl-configuration). Clients that only send a password authenticate as the Sentinel ACL's `default` user, so putting the previous `sentinel` password there lets them keep working unchanged:

   ```
   # key sentinel-users.acl in Secret my-sentinel-acl
   user default on >previous-sentinel-password ~* &* +@all
   ```

   ```yaml
   sentinel:
     acl:
       enabled: true
       existingSecret: "my-sentinel-acl"
   ```

   Without a Sentinel ACL, clients need the `auth.acl.defaultUsername` user's password.

## Uninstalling

To uninstall/delete the Redis deployment:

```bash
helm delete my-redis
```

## Getting Support

For issues related to this Helm chart, please check:

- [Redis Documentation](https://redis.io/docs/latest/)
- [Kubernetes Documentation](https://kubernetes.io/docs/)
- [Create an issue](https://github.com/CloudPirates-io/helm-charts/issues)
