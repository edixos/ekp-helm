# kube-ovn-v2

![Version: 0.1.12](https://img.shields.io/badge/Version-0.1.12-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 1.17.0](https://img.shields.io/badge/AppVersion-1.17.0-informational?style=flat-square)

## Prerequisites

- Helm v3
- Config Connector installed (v1.6.0)

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| https://kubeovn.github.io/kube-ovn/ | kube-ovn(kube-ovn-v2) | v1.17.0 |

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| hamzatalbi | <hamzatalbi831@gmail.com> | <https://github.com/TalbiHamza> |

## Description

Helm chart for Kube-OVN

## Values

### ACL sampling configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| kube-ovn.aclSampling | object | "{}" | Experimental OVN ACL sampling for NetworkPolicy events. |
| kube-ovn.aclSampling.allowProbabilityPercent | float | `1` | Sampling probability percentage for allowed decisions. Fractional percentages are supported. |
| kube-ovn.aclSampling.appIDEstablished | int | `103` | OVN sampling application ID for established ACL sessions. |
| kube-ovn.aclSampling.appIDNew | int | `102` | OVN sampling application ID for new ACL sessions. |
| kube-ovn.aclSampling.collectorIDAllow | int | `1` | OVN sample collector ID for allowed decisions. |
| kube-ovn.aclSampling.collectorIDDefaultDeny | int | `2` | OVN sample collector ID for default-deny decisions. |
| kube-ovn.aclSampling.defaultDenyProbabilityPercent | float | `100` | Sampling probability percentage for default-deny decisions. Fractional percentages are supported. |
| kube-ovn.aclSampling.enabled | bool | `false` | Enable controller-side ACL sampling and node-local psample delivery. |
| kube-ovn.aclSampling.localGroupID | int | `142` | Linux psample multicast group ID used for local delivery. |
| kube-ovn.aclSampling.setID | int | `142` | OVN sample collector set ID shared by controller and agents. |

### CNI agent configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| kube-ovn.agent | object | "{}" | Configuration for kube-ovn-cni, the agent responsible for handling CNI requests from the CRI. |
| kube-ovn.agent.annotations | object | `{}` | Annotations to be added to all top-level agent objects (resources under templates/agent) |
| kube-ovn.agent.extraEnv | list | `[]` | Extra environment variables to be added to kube-ovn-cni pods. |
| kube-ovn.agent.gatewayNetfilterDetectTimeout | string | `""` | Maximum time to wait for the kube-proxy mode during cold start; leave empty to use the daemon default of 30s. |
| kube-ovn.agent.gatewayNetfilterMode | string | `""` | Gateway netfilter backend: auto, iptables, or nftables; leave empty to use the daemon default of auto. |
| kube-ovn.agent.image | object | `{"pullPolicy":"","registry":"","repository":"","tag":""}` | Override image settings for kube-ovn-cni. Empty fields fall back to the global kube-ovn image. |
| kube-ovn.agent.image.pullPolicy | string | `""` | Pull policy override for this component image. Defaults to `.image.pullPolicy`. |
| kube-ovn.agent.image.registry | string | `""` | Registry override for this component image. This becomes the rendered image address. Defaults to `.global.registry.address`. |
| kube-ovn.agent.image.repository | string | `""` | Repository override for this component image. Defaults to `.global.images.kubeovn.repository`. |
| kube-ovn.agent.image.tag | string | `""` | Tag override for this component image. Defaults to `.global.images.kubeovn.tag`. |
| kube-ovn.agent.kubeProxyModeEndpoint | string | `""` | Local kube-proxy proxyMode endpoint; leave empty to use the daemon default endpoint. |
| kube-ovn.agent.labels | object | `{}` | Labels to be added to all top-level agent objects (resources under templates/agent) |
| kube-ovn.agent.metrics | object | "{}" | Agent metrics configuration. |
| kube-ovn.agent.metrics.port | int | `10665` | Configure the port on which the agent service will serve metrics. |
| kube-ovn.agent.mirroring | object | "{}" | Mirroring of the traffic for debug or analysis. https://kubeovn.github.io/docs/stable/en/guide/mirror/ |
| kube-ovn.agent.mirroring.enabled | bool | `false` | Enable mirroring of the traffic. |
| kube-ovn.agent.mirroring.interface | string | `"mirror0"` | Interface on which to send the mirrored traffic. |
| kube-ovn.agent.podAnnotations | object | `{}` | Annotations to be added to the agent pods (kube-ovn-cni) |
| kube-ovn.agent.podLabels | object | `{}` | Labels to be added to the agent pods (kube-ovn-cni) |
| kube-ovn.agent.resources | object | `{"limits":{"cpu":"1000m","ephemeral-storage":"1Gi","memory":"1Gi"},"requests":{"cpu":"100m","memory":"100Mi"}}` | Agent daemon resource limits & requests. ref: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/ |
| kube-ovn.agent.serviceMonitor | object | "{}" | Agent serviceMonitor configuration. |
| kube-ovn.agent.serviceMonitor.enabled | bool | `false` | Enable the deployment of the ServiceMonitor for the agent. |

### CNI agent configuration.

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| kube-ovn.agent.dpdkTunnelInterface | string | `"br-phy"` | "" |
| kube-ovn.agent.interface | string | `""` | "" |

### API Network Attachment Definition configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| kube-ovn.apiNad | object | "{}" | API NetworkAttachmentDefinition to give some pods (CoreDNS, NAT GW) in custom VPCs access to the K8S API. This requires Multus to be installed. |
| kube-ovn.apiNad.enabled | bool | `false` | Enable the creation of the API NAD. |
| kube-ovn.apiNad.name | string | `"ovn-kubernetes-api"` | Name of the NAD. |
| kube-ovn.apiNad.provider | string | `"{{ .Values.apiNad.name }}.{{ .Values.namespace }}.ovn"` | Name of the provider, must be in the form "nadName.nadNamespace.ovn". |
| kube-ovn.apiNad.subnet | object | "{}" | Subnet associated with the NAD, it will have full access to the API server. |
| kube-ovn.apiNad.subnet.cidrBlock | string | `"100.100.0.0/16,fd00:100:100::/112"` | CIDR block used by the API subnet. |
| kube-ovn.apiNad.subnet.name | string | `"ovn-kubernetes-api"` | Name of the subnet. |
| kube-ovn.apiNad.subnet.protocol | string | `"Dual"` | Protocol for the API subnet. |

### BGP speaker configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| kube-ovn.bgpSpeaker | object | "{}" | Configuration for kube-ovn-speaker, the BGP speaker announcing routes to the external world. |
| kube-ovn.bgpSpeaker.annotations | object | `{}` | Annotations to be added to all top-level kube-ovn-speaker objects (resources under templates/speaker) |
| kube-ovn.bgpSpeaker.args | list | `[]` | Args passed to the kube-ovn-speaker pod. |
| kube-ovn.bgpSpeaker.configMap | string | `""` | The name of the configMap that will be mounted in the kube-ovn-speaker pod. The ConfigMap can provide YAML configuration files for kube-ovn-speaker. To use a specific file, pass its mounted file path via '--config' or set 'KUBE_OVN_BGP_SPEAKER_CONFIG_FILE'. |
| kube-ovn.bgpSpeaker.configMapMountPath | string | `"/etc/kube-ovn/"` | Directory where the ConfigMap will be mounted in the kube-ovn-speaker pod. |
| kube-ovn.bgpSpeaker.enabled | bool | `false` | Enable the kube-ovn-speaker. |
| kube-ovn.bgpSpeaker.extraEnv | list | `[]` | Extra environment variables to be added to kube-ovn-speaker pods. |
| kube-ovn.bgpSpeaker.image | object | `{"pullPolicy":"","registry":"","repository":"","tag":""}` | Override image settings for kube-ovn-speaker. Empty fields fall back to the global kube-ovn image. |
| kube-ovn.bgpSpeaker.image.pullPolicy | string | `""` | Pull policy override for this component image. Defaults to `.image.pullPolicy`. |
| kube-ovn.bgpSpeaker.image.registry | string | `""` | Registry override for this component image. This becomes the rendered image address. Defaults to `.global.registry.address`. |
| kube-ovn.bgpSpeaker.image.repository | string | `""` | Repository override for this component image. Defaults to `.global.images.kubeovn.repository`. |
| kube-ovn.bgpSpeaker.image.tag | string | `""` | Tag override for this component image. Defaults to `.global.images.kubeovn.tag`. |
| kube-ovn.bgpSpeaker.labels | object | `{}` | Labels to be added to all top-level kube-ovn-speaker objects (resources under templates/speaker) |
| kube-ovn.bgpSpeaker.nodeSelector | object | `{}` | Node selector to restrict the deployment of the speaker to specific nodes. |
| kube-ovn.bgpSpeaker.podAnnotations | object | `{}` | Annotations to be added to kube-ovn-speaker pods. |
| kube-ovn.bgpSpeaker.podLabels | object | `{}` | Labels to be added to kube-ovn-speaker pods. |
| kube-ovn.bgpSpeaker.resources | object | `{"limits":{},"requests":{"cpu":"500m","memory":"300Mi"}}` | kube-ovn-speaker resource limits & requests. ref: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/ |

### OVN-central daemon configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| kube-ovn.central | object | "{}" | Configuration for ovn-central, the daemon containing the northbound/southbound DBs and northd. |
| kube-ovn.central.annotations | object | `{}` | Annotations to be added to all top-level ovn-central objects (resources under templates/central) |
| kube-ovn.central.extraEnv | list | `[]` | Extra environment variables to be added to ovn-central pods. |
| kube-ovn.central.hcp | object | `{"enabled":false,"namespace":"hcp","nbAddress":"","replicas":3,"sbAddress":"","service":{"nbNodePort":30641,"sbNodePort":30642,"type":"NodePort"},"storage":{"size":"5Gi","storageClassName":""}}` | Deploy ovn-central as a PVC-backed StatefulSet that can be exposed to workload clusters. |
| kube-ovn.central.image | object | `{"pullPolicy":"","registry":"","repository":"","tag":""}` | Override image settings for ovn-central. Empty fields fall back to the global kube-ovn image. |
| kube-ovn.central.image.pullPolicy | string | `""` | Pull policy override for this component image. Defaults to `.image.pullPolicy`. |
| kube-ovn.central.image.registry | string | `""` | Registry override for this component image. This becomes the rendered image address. Defaults to `.global.registry.address`. |
| kube-ovn.central.image.repository | string | `""` | Repository override for this component image. Defaults to `.global.images.kubeovn.repository`. |
| kube-ovn.central.image.tag | string | `""` | Tag override for this component image. Defaults to `.global.images.kubeovn.tag`. |
| kube-ovn.central.labels | object | `{}` | Labels to be added to all top-level ovn-central objects (resources under templates/central) |
| kube-ovn.central.nodeAffinity | object | `{"preferredDuringSchedulingIgnoredDuringExecution":[],"requiredDuringSchedulingIgnoredDuringExecution":[]}` | More information on formatting nodeAffinity can be found at https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/#node-affinity |
| kube-ovn.central.podAnnotations | object | `{}` | Annotations to be added to ovn-central pods. |
| kube-ovn.central.podLabels | object | `{}` | Labels to be added to ovn-central pods. |
| kube-ovn.central.resources | object | `{"limits":{"cpu":"3","ephemeral-storage":"1Gi","memory":"4Gi"},"requests":{"cpu":"300m","memory":"200Mi"}}` | ovn-central resource limits & requests. ref: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/ |
| kube-ovn.central.tolerations | list | `[{"effect":"NoSchedule","operator":"Exists"},{"effect":"NoExecute","operator":"Exists"},{"key":"CriticalAddonsOnly","operator":"Exists"}]` | Tolerations for ovn-central pods. |

### OVN-central daemon configuration.

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| kube-ovn.central.ovnLeaderProbeInterval | int | `5` | "" |
| kube-ovn.central.ovnNorthdNThreads | int | `1` | "" |
| kube-ovn.central.ovnNorthdProbeInterval | int | `5000` | "" |

### Global parameters

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| kube-ovn.clusterDomain | string | `"cluster.local"` | Domain used by the cluster. |
| kube-ovn.fullnameOverride | string | `""` | Full name override. |
| kube-ovn.global | object | `{"images":{"kubeovn":{"repository":"kube-ovn","tag":"v1.17.0"}},"registry":{"address":"docker.io/kubeovn","imagePullSecrets":[]}}` | Global configuration. |
| kube-ovn.image | object | "{}" | Image configuration. |
| kube-ovn.image.pullPolicy | string | `"IfNotPresent"` | Pull policy for all images. |
| kube-ovn.masterNodes | list | `[]` | Comma-separated list of IPs for each master node. If not specified, fallback to auto-identifying masters based on "masterNodesLabels" |
| kube-ovn.masterNodesLabels | object | `{"kube-ovn/role":"master"}` | Label used to auto-identify masters. Any node that has any of these labels will be considered a master node. Note: This feature uses Helm "lookup" function, which is not compatible with tools such as ArgoCD. |
| kube-ovn.nameOverride | string | `""` | Name override. |
| kube-ovn.namespace | string | `"kube-system"` | Namespace in which the CNI is deployed. |

### CNI configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| kube-ovn.cni | object | "{}" | CNI binary/configuration injected on the nodes. |
| kube-ovn.cni.binaryDirectory | string | `"/opt/cni/bin"` | Location on the node where the agent will inject the Kube-OVN binary. |
| kube-ovn.cni.configDirectory | string | `"/etc/cni/net.d"` | Location of the CNI configuration on the node. |
| kube-ovn.cni.configPriority | string | `"01"` | Priority of Kube-OVN within the CNI configuration directory on the node. Should be a string representing a double-digit integer. |
| kube-ovn.cni.installCNIPlugins | bool | `true` | Whether to install the bundled CNI plugins besides kube-ovn. |
| kube-ovn.cni.localConfigFile | string | `"/kube-ovn/01-kube-ovn.conflist"` | Location of the CNI configuration inside the agent's pod. |
| kube-ovn.cni.mountConfigDirectory | string | `"/etc/cni/net.d"` | Location of the CNI configuration to be mounted inside the pod. |
| kube-ovn.cni.mountToolingDirectory | bool | `false` | Whether to mount the node's tooling directory into the pod. |
| kube-ovn.cni.nonPrimaryCNI | bool | `false` | Whether to use Kube-OVN as non-primary CNI. When set to true, Kube-OVN will not allocate/handle primary network interfaces. Interfaces are created using Network Attachment Definitions (NADs) |
| kube-ovn.cni.toolingDirectory | string | `"/usr/local/bin"` | Location on the node where the CNI will install Kube-OVN's tooling. |

### Kube-OVN controller configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| kube-ovn.controller | object | "{}" | Configuration for kube-ovn-controller, the controller responsible for syncing K8s with OVN. |
| kube-ovn.controller.annotations | object | `{}` | Annotations to be added to all top-level kube-ovn-controller objects (resources under templates/controller) |
| kube-ovn.controller.extraEnv | list | `[]` | Extra environment variables to be added to kube-ovn-controller pods. |
| kube-ovn.controller.image | object | `{"pullPolicy":"","registry":"","repository":"","tag":""}` | Override image settings for kube-ovn-controller. Empty fields fall back to the global kube-ovn image. |
| kube-ovn.controller.image.pullPolicy | string | `""` | Pull policy override for this component image. Defaults to `.image.pullPolicy`. |
| kube-ovn.controller.image.registry | string | `""` | Registry override for this component image. This becomes the rendered image address. Defaults to `.global.registry.address`. |
| kube-ovn.controller.image.repository | string | `""` | Repository override for this component image. Defaults to `.global.images.kubeovn.repository`. |
| kube-ovn.controller.image.tag | string | `""` | Tag override for this component image. Defaults to `.global.images.kubeovn.tag`. |
| kube-ovn.controller.labels | object | `{}` | Labels to be added to all top-level kube-ovn-controller objects (resources under templates/controller) |
| kube-ovn.controller.leaderElection | object | `{"leaseDuration":"","renewDeadline":"","retryPeriod":""}` | Leader election timing configuration. |
| kube-ovn.controller.leaderElection.leaseDuration | string | `""` | Duration non-leader candidates wait after observing a renewal before attempting to acquire leadership. Empty uses the controller default of 30s. |
| kube-ovn.controller.leaderElection.renewDeadline | string | `""` | Duration the acting leader retries refreshing leadership before giving up. Empty uses the controller default of 20s. |
| kube-ovn.controller.leaderElection.retryPeriod | string | `""` | Duration leader election clients wait between attempts. Empty uses the controller default of 6s. |
| kube-ovn.controller.metrics | object | "{}" | Controller metrics configuration. |
| kube-ovn.controller.metrics.port | int | `10660` | Configure the port on which the controller service will serve metrics. |
| kube-ovn.controller.nodeAffinity | object | `{"preferredDuringSchedulingIgnoredDuringExecution":[],"requiredDuringSchedulingIgnoredDuringExecution":[]}` | More information on formatting nodeAffinity can be found at https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/#node-affinity |
| kube-ovn.controller.podAnnotations | object | `{}` | Annotations to be added to kube-ovn-controller pods. |
| kube-ovn.controller.podLabels | object | `{}` | Labels to be added to kube-ovn-controller pods. |
| kube-ovn.controller.resources | object | `{"limits":{"cpu":"1000m","ephemeral-storage":"1Gi","memory":"1Gi"},"requests":{"cpu":"200m","memory":"200Mi"}}` | kube-ovn-controller resource limits & requests. ref: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/ |
| kube-ovn.controller.serviceMonitor | object | "{}" | Controller serviceMonitor configuration. |
| kube-ovn.controller.serviceMonitor.enabled | bool | `false` | Enable the deployment of the ServiceMonitor for the Kube-OVN controller. |
| kube-ovn.controller.tolerations | list | `[{"effect":"NoSchedule","operator":"Exists"},{"key":"CriticalAddonsOnly","operator":"Exists"}]` | Tolerations for kube-ovn-controller pods. |

### Extra objects

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| kube-ovn.extraObjects | list | `[]` | Array of extra K8s manifests to deploy. Note: Supports use of custom Helm templates (Go templating) |

### Opt-in/out Features

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| kube-ovn.features | object | `{"ENABLE_ANP":false,"ENABLE_BIND_LOCAL_IP":true,"ENABLE_DNS_NAME_RESOLVER":false,"LS_CT_SKIP_DST_LPORT_IPS":true,"LS_DNAT_MOD_DL_DST":true,"OVSDB_CON_TIMEOUT":3,"OVSDB_INACTIVITY_TIMEOUT":10,"SET_GENEVE_TX_OFF":false,"SET_VXLAN_TX_OFF":false,"enableExternalVpcs":false,"enableGwNftableLoadbalancerService":false,"enableGwNftableServiceClusterIp":false,"enableHardwareOffload":false,"enableHostTunnelSrc":false,"enableKeepVmIps":true,"enableLiveMigrationOptimization":true,"enableLoadbalancer":true,"enableLoadbalancerService":false,"enableNatGateways":true,"enableNetworkPolicies":true,"enableOvnInterconnections":false,"enableOvnIpsec":false,"enableRecompute":false,"enableSecureServing":false,"enableTproxy":false,"enableU2OInterconnections":false}` | Features of Kube-OVN we wish to enable/disable. |
| kube-ovn.features.enableExternalVpcs | bool | `false` | Enable external VPCs |
| kube-ovn.features.enableGwNftableLoadbalancerService | bool | `false` | Enable Kube-OVN nftable share DNAT based loadbalancer services on vpc nat gateway. Mutually exclusive with enableLoadbalancerService. |
| kube-ovn.features.enableGwNftableServiceClusterIp | bool | `false` | Enable ClusterIP services through nftable share DNAT on a VPC NAT gateway. Mutually exclusive with enableLoadbalancer. |
| kube-ovn.features.enableHardwareOffload | bool | `false` | Enable hardware offloads |
| kube-ovn.features.enableHostTunnelSrc | bool | `false` | Allow a /32 address to be selected as the tunnel source (required on clouds that assign /32 to the host interface) |
| kube-ovn.features.enableKeepVmIps | bool | `true` | Enable persistent VM IPs |
| kube-ovn.features.enableLiveMigrationOptimization | bool | `true` | Enable optimized live migrations for VMs |
| kube-ovn.features.enableLoadbalancer | bool | `true` | Enable Kube-OVN loadbalancers |
| kube-ovn.features.enableLoadbalancerService | bool | `false` | Enable Kube-OVN loadbalancer services (one forwarding Pod per LoadBalancer Service). Mutually exclusive with enableGwNftableLoadbalancerService; it needs a ClusterIP data plane behind it, either enableLoadbalancer or enableGwNftableServiceClusterIp. |
| kube-ovn.features.enableNatGateways | bool | `true` | Enable NAT gateways |
| kube-ovn.features.enableNetworkPolicies | bool | `true` | Enable Kube-OVN network policies |
| kube-ovn.features.enableOvnInterconnections | bool | `false` | Enable OVN interconnections |
| kube-ovn.features.enableOvnIpsec | bool | `false` | Enable IPSEC |
| kube-ovn.features.enableRecompute | bool | `false` | Enable periodic ovn-controller recompute |
| kube-ovn.features.enableSecureServing | bool | `false` | Enable secure serving |
| kube-ovn.features.enableTproxy | bool | `false` | Enable TProxy |
| kube-ovn.features.enableU2OInterconnections | bool | `false` | Enable underlay to overlay interconnections |

### Grafana dashboards configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| kube-ovn.grafanaDashboards | object | "{}" | Configuration of the Grafana dashboard ConfigMaps, automatically picked up by the kube-prometheus-stack Grafana sidecar. One ConfigMap is emitted per dashboard under dist/monitoring. |
| kube-ovn.grafanaDashboards.annotations | object | `{}` | Annotations added to the dashboard ConfigMaps. |
| kube-ovn.grafanaDashboards.datasource | string | `"Prometheus"` | Name of the Grafana Prometheus datasource the dashboards should use. The bundled JSON files were exported from Grafana with `${DS_PROMETHEUS}` placeholders that are only resolved during UI import, not when loaded by the sidecar. The chart rewrites those placeholders to this value at render time so panels resolve to an existing datasource.  Must match `^[A-Za-z0-9_.-]+$`. The value is interpolated verbatim into dashboard JSON, so characters like quotes, backslashes or newlines would produce invalid JSON; the chart fails rendering if the constraint is violated. If your datasource name contains other characters, rename it. |
| kube-ovn.grafanaDashboards.enabled | bool | `false` | Enable the deployment of the Grafana dashboard ConfigMaps. |
| kube-ovn.grafanaDashboards.labels | object | `{"grafana_dashboard":"1"}` | Labels added to the dashboard ConfigMaps. The default label matches the kube-prometheus-stack Grafana sidecar convention. |
| kube-ovn.grafanaDashboards.namespace | string | `""` | Namespace override for the dashboard ConfigMaps. Defaults to .Values.namespace when empty. |

### OVN IC controller configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| kube-ovn.ic | object | "{}" | Configuration for the OVN interconnection (IC) controller. |
| kube-ovn.ic.extraEnv | list | `[]` | Extra environment variables to be added to ovn-ic-controller pods. |
| kube-ovn.ic.image | object | `{"pullPolicy":"","registry":"","repository":"","tag":""}` | Override image settings for the OVN IC controller. Empty fields fall back to the global kube-ovn image. |
| kube-ovn.ic.image.pullPolicy | string | `""` | Pull policy override for this component image. Defaults to `.image.pullPolicy`. |
| kube-ovn.ic.image.registry | string | `""` | Registry override for this component image. This becomes the rendered image address. Defaults to `.global.registry.address`. |
| kube-ovn.ic.image.repository | string | `""` | Repository override for this component image. Defaults to `.global.images.kubeovn.repository`. |
| kube-ovn.ic.image.tag | string | `""` | Tag override for this component image. Defaults to `.global.images.kubeovn.tag`. |
| kube-ovn.ic.nodeAffinity | object | `{"preferredDuringSchedulingIgnoredDuringExecution":[],"requiredDuringSchedulingIgnoredDuringExecution":[]}` | More information on formatting nodeAffinity can be found at https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/#node-affinity |
| kube-ovn.ic.tolerations | list | `[{"effect":"NoSchedule","operator":"Exists"},{"effect":"NoExecute","operator":"Exists"},{"key":"CriticalAddonsOnly","operator":"Exists"}]` | Tolerations for ovn-ic-controller pods. |

### Kubelet configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| kube-ovn.kubelet | object | "{}" | Kubelet configuration. |
| kube-ovn.kubelet.directory | string | `"/var/lib/kubelet"` | Directory in which the kubelet operates. |
| kube-ovn.logging.directory | string | `"/var/log"` | Directory in which to write the logs. |

### Logging configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| kube-ovn.logging | object | "{}" | Logging configuration for all the daemons. |

### OVN monitoring daemon configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| kube-ovn.monitor | object | "{}" | Configuration for kube-ovn-monitor, the agent monitoring and returning metrics for the northbound/southbound DBs and northd. |
| kube-ovn.monitor.annotations | object | `{}` | Annotations to be added to all top-level kube-ovn-monitor objects (resources under templates/monitor) |
| kube-ovn.monitor.extraEnv | list | `[]` | Extra environment variables to be added to kube-ovn-monitor pods. |
| kube-ovn.monitor.image | object | `{"pullPolicy":"","registry":"","repository":"","tag":""}` | Override image settings for kube-ovn-monitor. Empty fields fall back to the global kube-ovn image. |
| kube-ovn.monitor.image.pullPolicy | string | `""` | Pull policy override for this component image. Defaults to `.image.pullPolicy`. |
| kube-ovn.monitor.image.registry | string | `""` | Registry override for this component image. This becomes the rendered image address. Defaults to `.global.registry.address`. |
| kube-ovn.monitor.image.repository | string | `""` | Repository override for this component image. Defaults to `.global.images.kubeovn.repository`. |
| kube-ovn.monitor.image.tag | string | `""` | Tag override for this component image. Defaults to `.global.images.kubeovn.tag`. |
| kube-ovn.monitor.labels | object | `{}` | Labels to be added to all top-level kube-ovn-monitor objects (resources under templates/monitor) |
| kube-ovn.monitor.metrics | object | "{}" | kube-ovn-monitor metrics configuration. |
| kube-ovn.monitor.metrics.port | int | `10661` | Configure the port on which the kube-ovn-monitor service will serve metrics. |
| kube-ovn.monitor.nodeAffinity | object | `{"preferredDuringSchedulingIgnoredDuringExecution":[],"requiredDuringSchedulingIgnoredDuringExecution":[]}` | More information on formatting nodeAffinity can be found at https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/#node-affinity |
| kube-ovn.monitor.podAnnotations | object | `{}` | Annotations to be added to kube-ovn-monitor pods. |
| kube-ovn.monitor.podLabels | object | `{}` | Labels to be added to kube-ovn-monitor pods. |
| kube-ovn.monitor.replicas | int | `1` | Number of kube-ovn-monitor replicas. |
| kube-ovn.monitor.resources | object | `{"limits":{"cpu":"200m","ephemeral-storage":"1Gi","memory":"200Mi"},"requests":{"cpu":"200m","memory":"200Mi"}}` | kube-ovn-monitor resource limits & requests. ref: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/ |
| kube-ovn.monitor.serviceMonitor | object | "{}" | kube-ovn-monitor serviceMonitor configuration. |
| kube-ovn.monitor.serviceMonitor.enabled | bool | `false` | Enable the deployment of the ServiceMonitor for the kube-ovn-monitor. |
| kube-ovn.monitor.tolerations | list | `[{"effect":"NoSchedule","operator":"Exists"},{"key":"CriticalAddonsOnly","operator":"Exists"}]` | Tolerations for kube-ovn-monitor pods. |

### NAT gateways configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| kube-ovn.natGw | object | "{}" | Configuration for the NAT gateways. |
| kube-ovn.natGw.bgpSpeaker | object | "{}" | Configuration of the BGP sidecar for when a NAT gateway is running in BGP mode. |
| kube-ovn.natGw.bgpSpeaker.apiNadProvider | string | `"{{ .Values.apiNad.name }}.{{ .Values.namespace }}.ovn"` | Network attachment definition used to reach the API server when running on BGP mode. By default, equals the value set at ".apiNad.provider", you will need to set ".apiNad.enabled" to true. See https://kubeovn.github.io/docs/stable/en/advance/with-bgp/ |
| kube-ovn.natGw.bgpSpeaker.image | object | "{}" | Image used by the NAT gateway sidecar. |
| kube-ovn.natGw.bgpSpeaker.image.pullPolicy | string | `"IfNotPresent"` | Image pull policy. |
| kube-ovn.natGw.bgpSpeaker.image.repository | string | `"docker.io/kubeovn/kube-ovn"` | Image repository. |
| kube-ovn.natGw.bgpSpeaker.image.tag | string | `"v1.17.0"` | Image tag. |
| kube-ovn.natGw.image | object | "{}" | Image used by the NAT gateway. |
| kube-ovn.natGw.image.pullPolicy | string | `"IfNotPresent"` | Image pull policy. |
| kube-ovn.natGw.image.repository | string | `"docker.io/kubeovn/vpc-nat-gateway"` | Image repository. |
| kube-ovn.natGw.image.tag | string | `"v1.17.0"` | Image tag. |
| kube-ovn.natGw.namePrefix | string | `"vpc-nat-gw"` | Prefix appended to the name of the NAT gateways when generating the Pods. If this value is changed after NAT GWs have been provisioned, every NAT gateway will need to be manually destroyed and recreated. |

### Network Policies

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| kube-ovn.networkPolicies | object | "{}" | Configuration for network policies |
| kube-ovn.networkPolicies.enforcement | string | `"standard"` | Enforcement level of network policies when they get applied (can be: standard, lax). Enforcement "standard" blocks everything except what is allowed by the network policies. Enforcement "lax" is similar to "standard" with the exception that ARP/DHCPv4/DHCPv6/ICMPv4/ICMPv6 is allowed by default. This mode is useful when using Kubevirt and VMs with IPs configured via Kube-OVN's DHCP. |

### Network parameters of the CNI

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| kube-ovn.networking | object | "{}" | General configuration of the network created by Kube-OVN. |
| kube-ovn.networking.defaultVpcName | string | `"ovn-cluster"` | Name of the default VPC once it is generated in the cluster. Pods in the default subnet live in this VPC. |
| kube-ovn.networking.enableCompact | bool | `false` | "" |
| kube-ovn.networking.enableEcmp | bool | `false` | "" |
| kube-ovn.networking.enableEipSnat | bool | `true` | Enable EIP and SNAT. |
| kube-ovn.networking.enableMetrics | bool | `true` | Enable listening on the metrics endpoint for the CNI daemons. |
| kube-ovn.networking.enableSsl | bool | `false` | Deploy the CNI with SSL encryption in between components. |
| kube-ovn.networking.exchangeLinkName | bool | `false` | "" |
| kube-ovn.networking.excludeIps | string | `""` | IPs to exclude from IPAM in the default subnet. |
| kube-ovn.networking.externalGatewayConfigNs | string | `""` | Namespace where ovn-external-gw-config ConfigMap is located. Empty means it will use the same namespace as the controller (PodNamespace). |
| kube-ovn.networking.externalGatewaySwitch | string | `""` | The name of the external gateway switch (OVS bridge providing external network). Empty means the default "external" is used. |
| kube-ovn.networking.join | object | "{}" | Configuration of the "join" subnet, used by the nodes to contact (join) the pods in the default subnet. If .networking.stack is set to IPv4, only the .v4 key is used. If .networking.stack is set to IPv6, only the .v6 key is used. If .networking.stack is set to Dual, both keys are used. |
| kube-ovn.networking.join.cidr | object | "{}" | CIDR used by the join subnet. |
| kube-ovn.networking.join.cidr.v4 | string | `"100.64.0.0/16"` | IPv4 CIDR. |
| kube-ovn.networking.join.cidr.v6 | string | `"fd00:100:64::/112"` | IPv6 CIDR. |
| kube-ovn.networking.join.subnetName | string | `"join"` | Name of the join subnet once it gets generated in the cluster. |
| kube-ovn.networking.kubeOvnTlsRotationInterval | string | `"8760h"` | How often kube-ovn-controller checks kube-ovn-tls for renewal. Set to 0 to disable. |
| kube-ovn.networking.maxMtu | int | `0` | Upper bound applied to the auto-detected pod MTU (0 disables the cap). Useful when the underlay uses jumbo frames but pod traffic egresses to a 1500-byte path (e.g. the internet), where the uncapped value would cause fragmentation or PMTUD-dependent blackholes. Ignored when .networking.pods.mtu is set. This applies to custom and default subnets. |
| kube-ovn.networking.networkType | string | `"geneve"` | Network type can be "geneve" or "vlan". |
| kube-ovn.networking.nodeLocalDnsIp | string | `""` | Comma-separated string of NodeLocal DNS IP addresses. |
| kube-ovn.networking.podNicType | string | `"veth-pair"` | NIC type used on pods to connect them to the CNI. |
| kube-ovn.networking.pods | object | "{}" | Configuration for the default pod subnet. If .networking.stack is set to IPv4, only the .v4 key is used. If .networking.stack is set to IPv6, only the .v6 key is used. If .networking.stack is set to Dual, both keys are used. |
| kube-ovn.networking.pods.cidr | object | "{}" | CIDR used by the pods subnet. |
| kube-ovn.networking.pods.cidr.v4 | string | `"10.16.0.0/16"` | IPv4 CIDR. |
| kube-ovn.networking.pods.cidr.v6 | string | `"fd00:10:16::/112"` | IPv6 CIDR. |
| kube-ovn.networking.pods.enableGatewayChecks | bool | `true` | Enable default gateway checks. |
| kube-ovn.networking.pods.enableLogicalGateways | bool | `false` | Enable logical gateways. |
| kube-ovn.networking.pods.gateways | object | "{}" | Gateways used in the pod subnet. |
| kube-ovn.networking.pods.gateways.v4 | string | `"10.16.0.1"` | IPv4 gateway. |
| kube-ovn.networking.pods.gateways.v6 | string | `"fd00:10:16::1"` | IPv6 gateway. |
| kube-ovn.networking.pods.mtu | int | `0` | MTU of the subnet. If set to 0, the MTU is auto-detected. Refer to .networking.maxMtu to cap the MTU. |
| kube-ovn.networking.pods.subnetName | string | `"ovn-default"` | Name of the pod subnet once it gets generated in the cluster. |
| kube-ovn.networking.services | object | "{}" | Configuration for the service subnet. If .networking.stack is set to IPv4, only the .v4 key is used. If .networking.stack is set to IPv6, only the .v6 key is used. If .networking.stack is set to Dual, both keys are used. |
| kube-ovn.networking.services.cidr | object | "{}" | CIDR used by the service subnet. |
| kube-ovn.networking.services.cidr.v4 | string | `"10.96.0.0/12"` | IPv4 CIDR. |
| kube-ovn.networking.services.cidr.v6 | string | `"fd00:10:96::/112"` | IPv6 CIDR. |
| kube-ovn.networking.skipConntrackDstCidrs | string | `""` | Comma-separated list of destination IP CIDRs that should skip conntrack processing. |
| kube-ovn.networking.stack | string | `"IPv4"` | Protocol(s) used by Kube-OVN to allocate IPs to pods and services. Can be either IPv4, IPv6 or Dual. |
| kube-ovn.networking.tlsCipherSuites | list | `[]` | Go TLS cipher suite names. OVN DB server only supports suites mapped by dist/images/ovn-db-ssl-options.sh. |
| kube-ovn.networking.tlsMaxVersion | string | `""` | Maximum TLS version for OVN NB/SB database server and kube-ovn secure-serving endpoints. Supported values: TLS10, TLS11, TLS12, TLS13. Empty uses the component default. |
| kube-ovn.networking.tlsMinVersion | string | `""` | Minimum TLS version for OVN NB/SB database server and kube-ovn secure-serving endpoints. Supported values: TLS10, TLS11, TLS12, TLS13. Empty uses the component default. |
| kube-ovn.networking.tunnelType | string | `"geneve"` | Tunnel type can be "geneve", "vxlan" or "stt". |
| kube-ovn.networking.vlan | object | `{"id":"100","interfaceName":"","name":"ovn-vlan","providerName":"provider"}` | Configuration if we're running on top of a VLAN. |

### OVS/OVN daemons configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| kube-ovn.ovsOvn | object | "{}" | Configuration for ovs-ovn, the Open vSwitch/Open Virtual Network daemons. |
| kube-ovn.ovsOvn.affinity | object | `{}` | Affinity for ovs-ovn pods. |
| kube-ovn.ovsOvn.annotations | object | `{}` | Annotations to be added to all top-level ovs-ovn objects (resources under templates/ovs-ovn) |
| kube-ovn.ovsOvn.disableModulesManagement | bool | `false` | Disable auto-loading of kernel modules by OVS. If this is disabled, you will have to enable the Open vSwitch kernel module yourself. |
| kube-ovn.ovsOvn.dpdkHybrid | object | "{}" | DPDK-hybrid support for OVS. ref: https://kubeovn.github.io/docs/v1.12.x/en/advance/dpdk/ |
| kube-ovn.ovsOvn.dpdkHybrid.affinity | object | `{}` | Affinity for the ovs-ovn-dpdk DaemonSet. |
| kube-ovn.ovsOvn.dpdkHybrid.enabled | bool | `false` | Enables DPDK-hybrid support on OVS. |
| kube-ovn.ovsOvn.dpdkHybrid.image | object | `{"pullPolicy":"","registry":"","repository":"","tag":""}` | Override image settings for ovs-ovn-dpdk. Empty fields fall back to the global kube-ovn image and the DPDK tag below. |
| kube-ovn.ovsOvn.dpdkHybrid.image.pullPolicy | string | `""` | Pull policy override for this component image. Defaults to `.image.pullPolicy`. |
| kube-ovn.ovsOvn.dpdkHybrid.image.registry | string | `""` | Registry override for this component image. This becomes the rendered image address. Defaults to `.global.registry.address`. |
| kube-ovn.ovsOvn.dpdkHybrid.image.repository | string | `""` | Repository override for this component image. Defaults to `.global.images.kubeovn.repository`. |
| kube-ovn.ovsOvn.dpdkHybrid.image.tag | string | `""` | Tag override for this component image. Defaults to `.ovsOvn.dpdkHybrid.tag`. |
| kube-ovn.ovsOvn.dpdkHybrid.nodeSelector | object | `{"kubernetes.io/os":"linux","ovn.kubernetes.io/ovs_dp_type":"userspace"}` | Node selector to restrict the deployment of DPDK-hybrid OVS to specific nodes. |
| kube-ovn.ovsOvn.dpdkHybrid.resources | object | `{"limits":{"cpu":"2","ephemeral-storage":"1Gi","hugepages-2Mi":"1Gi","memory":"1000Mi"},"requests":{"cpu":"200m","memory":"200Mi"}}` | ovs-ovn resource limits & requests when DPDK-hybrid is enabled. ref: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/ |
| kube-ovn.ovsOvn.dpdkHybrid.tag | string | `"v1.17.0"` | DPDK image tag. |
| kube-ovn.ovsOvn.extraEnv | list | `[]` | Extra environment variables to be added to ovs-ovn pods. |
| kube-ovn.ovsOvn.image | object | `{"pullPolicy":"","registry":"","repository":"","tag":""}` | Override image settings for ovs-ovn. Empty fields fall back to the global kube-ovn image. |
| kube-ovn.ovsOvn.image.pullPolicy | string | `""` | Pull policy override for this component image. Defaults to `.image.pullPolicy`. |
| kube-ovn.ovsOvn.image.registry | string | `""` | Registry override for this component image. This becomes the rendered image address. Defaults to `.global.registry.address`. |
| kube-ovn.ovsOvn.image.repository | string | `""` | Repository override for this component image. Defaults to `.global.images.kubeovn.repository`. |
| kube-ovn.ovsOvn.image.tag | string | `""` | Tag override for this component image. Defaults to `.global.images.kubeovn.tag`. |
| kube-ovn.ovsOvn.labels | object | `{}` | Labels to be added to all top-level ovs-ovn objects (resources under templates/ovs-ovn) |
| kube-ovn.ovsOvn.nodeSelector | object | `{"kubernetes.io/os":"linux"}` | Node selector to restrict the deployment of ovs-ovn to specific nodes. |
| kube-ovn.ovsOvn.ovnDirectory | string | `"/etc/origin/ovn"` | Directory on the node where Open Virtual Network (OVN) lives. |
| kube-ovn.ovsOvn.ovsDirectory | string | `"/etc/origin/openvswitch"` | Directory on the node where Open vSwitch (OVS) lives. |
| kube-ovn.ovsOvn.ovsIpsecKeysDirectory | string | `"/etc/origin/ovs_ipsec_keys"` | Directory on the node where Open vSwitch (OVS) IPSEC keys live. |
| kube-ovn.ovsOvn.podAnnotations | object | `{}` | Annotations to be added to ovs-ovn pods. |
| kube-ovn.ovsOvn.podLabels | object | `{}` | Labels to be added to ovs-ovn pods. |
| kube-ovn.ovsOvn.resources | object | `{"limits":{"cpu":"2","ephemeral-storage":"1Gi","memory":"1000Mi"},"requests":{"cpu":"200m","memory":"200Mi"}}` | ovs-ovn resource limits & requests. ref: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/ |
| kube-ovn.ovsOvn.updateStrategy | object | `{"maxSurge":1,"maxUnavailable":0,"type":"RollingUpdate"}` | ovs-ovn DaemonSet update strategy. ref: https://kubernetes.io/docs/tasks/manage-daemon/update-daemon-set/#daemonset-update-strategy |
| kube-ovn.ovsOvn.upgrade | object | `{"enabled":true}` | Upgrade logic for OVS/OVN. |

### Performance configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| kube-ovn.performance | object | "{}" | Performance tuning parameters. |
| kube-ovn.performance.gcInterval | int | `360` | "" |
| kube-ovn.performance.inspectInterval | int | `20` | "" |

### Ping daemon configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| kube-ovn.pinger | object | "{}" | Configuration for kube-ovn-pinger, the agent monitoring and returning metrics for OVS/external connectivity. |
| kube-ovn.pinger.annotations | object | `{}` | Annotations to be added to all top-level kube-ovn-pinger objects (resources under templates/pinger) |
| kube-ovn.pinger.extraEnv | list | `[]` | Extra environment variables to be added to kube-ovn-pinger pods. |
| kube-ovn.pinger.image | object | `{"pullPolicy":"","registry":"","repository":"","tag":""}` | Override image settings for kube-ovn-pinger. Empty fields fall back to the global kube-ovn image. |
| kube-ovn.pinger.image.pullPolicy | string | `""` | Pull policy override for this component image. Defaults to `.image.pullPolicy`. |
| kube-ovn.pinger.image.registry | string | `""` | Registry override for this component image. This becomes the rendered image address. Defaults to `.global.registry.address`. |
| kube-ovn.pinger.image.repository | string | `""` | Repository override for this component image. Defaults to `.global.images.kubeovn.repository`. |
| kube-ovn.pinger.image.tag | string | `""` | Tag override for this component image. Defaults to `.global.images.kubeovn.tag`. |
| kube-ovn.pinger.labels | object | `{}` | Labels to be added to all top-level kube-ovn-pinger objects (resources under templates/pinger) |
| kube-ovn.pinger.metrics | object | "{}" | kube-ovn-pinger metrics configuration. |
| kube-ovn.pinger.metrics.port | int | `8080` | Configure the port on which the kube-ovn-monitor service will serve metrics. |
| kube-ovn.pinger.podAnnotations | object | `{}` | Annotations to be added to kube-ovn-pinger pods. |
| kube-ovn.pinger.podLabels | object | `{}` | Labels to be added to kube-ovn-pinger pods. |
| kube-ovn.pinger.resources | object | `{"limits":{"cpu":"200m","ephemeral-storage":"1Gi","memory":"400Mi"},"requests":{"cpu":"100m","memory":"100Mi"}}` | kube-ovn-pinger resource limits & requests. ref: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/ |
| kube-ovn.pinger.serviceMonitor | object | "{}" | Ping daemon serviceMonitor configuration. |
| kube-ovn.pinger.serviceMonitor.enabled | bool | `false` | Enable the deployment of the ServiceMonitor for the pinger. |
| kube-ovn.pinger.targets | object | "{}" | Remote targets used by the pinger daemon to determine if the CNI works and has external connectivity. |
| kube-ovn.pinger.targets.externalAddresses | object | "{}" | Raw IPv4/6 on which to issue pings. |
| kube-ovn.pinger.targets.externalAddresses.v4 | string | `"1.1.1.1"` | IPv4 address. |
| kube-ovn.pinger.targets.externalAddresses.v6 | string | `"2606:4700:4700::1111"` | IPv6 address. |
| kube-ovn.pinger.targets.externalDomain | object | "{}" | Domains to resolve and to ping. Make sure the v6 domain resolves both A and AAAA records, while the v4 only resolves A records. |
| kube-ovn.pinger.targets.externalDomain.v4 | string | `"kube-ovn.io."` | Domain name resolving to an IPv4 only (A record) |
| kube-ovn.pinger.targets.externalDomain.v6 | string | `"google.com."` | Domain name resolving to an IPv6 and IPv4 only (A/AAAA record) |

### PrometheusRule configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| kube-ovn.prometheusRule | object | "{}" | Configuration of the PrometheusRule shipping baseline Kube-OVN alerts. Requires prometheus-operator CRDs to be installed in the cluster.  Prerequisite: most bundled rules query metrics exposed by the controller, the OVN monitor, the pinger and the agent. Scrape-dependent alerts only fire when those metrics are actually being scraped, which means **either**:   1. enabling the matching ServiceMonitors shipped by this chart      (`controller.serviceMonitor.enabled`, `monitor.serviceMonitor.enabled`,      `pinger.serviceMonitor.enabled`, `agent.serviceMonitor.enabled`), **or**   2. configuring an external scrape (PodMonitor, custom scrape config, etc.)      that produces samples for the same job/metric labels.  When neither is true, scrape-dependent alerts stay inactive. Note however that `absent()`-style alerts (e.g. KubeOvnControllerAbsent) still fire in that configuration, because "no target" is precisely what they report. If you want to skip them until scraping is wired up, silence/inhibit them in Alertmanager or leave `prometheusRule.enabled` off. |
| kube-ovn.prometheusRule.additionalGroups | list | `[]` | Extra rule groups appended to the bundled groups. Each item must follow the PrometheusRule `spec.groups[]` schema. |
| kube-ovn.prometheusRule.annotations | object | `{}` | Extra annotations added to the PrometheusRule. |
| kube-ovn.prometheusRule.enabled | bool | `false` | Enable the deployment of the bundled PrometheusRule. |
| kube-ovn.prometheusRule.labels | object | `{}` | Extra labels added to the PrometheusRule. Typically used to match the `release` selector of a kube-prometheus-stack installation. |
| kube-ovn.prometheusRule.namespace | string | `""` | Namespace override for the PrometheusRule. Defaults to .Values.namespace when empty. |

### Validating webhook configuration

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| kube-ovn.validatingWebhook | object | "{}" | Configuration of the validating webhook used to verify custom resources before they are pushed to Kubernetes. Make sure cert-manager is installed for the generation of certificates for the webhook. See https://kubeovn.github.io/docs/stable/en/guide/webhook/ |
| kube-ovn.validatingWebhook.annotations | object | `{}` | Annotations to be added to all top-level kube-ovn-webhook objects (resources under templates/webhook) |
| kube-ovn.validatingWebhook.certificate.create | bool | `true` | Create the webhook Certificate and self-signed Issuer. Set to false to manage your own cert-manager Certificate and issuer outside this chart; the webhook remains enabled. See the README for required resource names and upgrade considerations. |
| kube-ovn.validatingWebhook.enabled | bool | `false` | Enable the deployment of the validating webhook. |
| kube-ovn.validatingWebhook.extraEnv | list | `[]` | Extra environment variables to be added to kube-ovn-webhook pods. |
| kube-ovn.validatingWebhook.image | object | `{"pullPolicy":"","registry":"","repository":"","tag":""}` | Override image settings for kube-ovn-webhook. Empty fields fall back to the global kube-ovn image. |
| kube-ovn.validatingWebhook.image.pullPolicy | string | `""` | Pull policy override for this component image. Defaults to `.image.pullPolicy`. |
| kube-ovn.validatingWebhook.image.registry | string | `""` | Registry override for this component image. This becomes the rendered image address. Defaults to `.global.registry.address`. |
| kube-ovn.validatingWebhook.image.repository | string | `""` | Repository override for this component image. Defaults to `.global.images.kubeovn.repository`. |
| kube-ovn.validatingWebhook.image.tag | string | `""` | Tag override for this component image. Defaults to `.global.images.kubeovn.tag`. |
| kube-ovn.validatingWebhook.labels | object | `{}` | Labels to be added to all top-level kube-ovn-webhook objects (resources under templates/webhook) |
| kube-ovn.validatingWebhook.podAnnotations | object | `{}` | Annotations to be added to kube-ovn-webhook pods. |
| kube-ovn.validatingWebhook.podLabels | object | `{}` | Labels to be added to kube-ovn-webhook pods. |
| kube-ovn.validatingWebhook.tolerations | list | `[{"effect":"NoSchedule","operator":"Exists"}]` | Tolerations for kube-ovn-webhook pods. |

### Other Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| kube-ovn.central.hcp.nbAddress | string | `""` | OVN NB address used by workload clusters, for example tcp:ovn-nb.example.com:6641. |
| kube-ovn.central.hcp.sbAddress | string | `""` | OVN SB address used by workload clusters, for example tcp:ovn-sb.example.com:6642. |
| kube-ovn.central.nodeAffinity.preferredDuringSchedulingIgnoredDuringExecution | list | `[]` | - antarctica-west1 |
| kube-ovn.central.nodeAffinity.requiredDuringSchedulingIgnoredDuringExecution | list | `[]` | - antarctica-west1 |
| kube-ovn.controller.nodeAffinity.preferredDuringSchedulingIgnoredDuringExecution | list | `[]` | - antarctica-west1 |
| kube-ovn.controller.nodeAffinity.requiredDuringSchedulingIgnoredDuringExecution | list | `[]` | - antarctica-west1 |
| kube-ovn.ic.nodeAffinity.preferredDuringSchedulingIgnoredDuringExecution | list | `[]` | - antarctica-west1 |
| kube-ovn.ic.nodeAffinity.requiredDuringSchedulingIgnoredDuringExecution | list | `[]` | - antarctica-west1 |
| kube-ovn.ipsec.certManager.enabled | bool | `false` |  |
| kube-ovn.ipsec.certManager.issuerName | string | `"kube-ovn"` |  |
| kube-ovn.ipsec.certificateDuration | int | `63072000` |  |
| kube-ovn.ipsec.priority | int | `-5` |  |
| kube-ovn.ipsec.requestTimeout | string | `"300s"` |  |
| kube-ovn.ipsec.resources.limits.cpu | string | `"1000m"` |  |
| kube-ovn.ipsec.resources.limits.memory | string | `"256Mi"` |  |
| kube-ovn.ipsec.resources.requests.cpu | string | `"10m"` |  |
| kube-ovn.ipsec.resources.requests.memory | string | `"64Mi"` |  |
| kube-ovn.monitor.nodeAffinity.preferredDuringSchedulingIgnoredDuringExecution | list | `[]` | - antarctica-west1 |
| kube-ovn.monitor.nodeAffinity.requiredDuringSchedulingIgnoredDuringExecution | list | `[]` | - antarctica-west1 |
| kube-ovn.ovsOvn.upgrade.enabled | bool | `true` | Enable post-upgrade hooks to run upgrade logic of OVS/OVN. |
| prometheus.enabled | bool | `false` | Enables Prometheus Operator monitoring |
| prometheus.grafanaDashboard.enabled | bool | `false` | Add grafana dashboard as a configmap |
| prometheus.grafanaDashboard.label | object | `{"grafana_dashboard":"1"}` | label to apply to the config map. Used by Grafana sidecar to automatically install the dashboard |
| prometheus.rules.enabled | bool | `false` | Enables prometheus operator rules |
| prometheus.rules.labels | object | `{"prometheus":"prometheus-operator-prometheus"}` | Labels to affect to the Prometheus Rules |
| prometheus.serviceMonitor.annotations | object | `{}` | Map of annotations to apply to the ServiceMonitor |
| prometheus.serviceMonitor.bearerTokenFile | string | `"/var/run/secrets/kubernetes.io/serviceaccount/token"` | Path to bearer token file for authentication |
| prometheus.serviceMonitor.enabled | bool | `false` | Enables prometheus operator service monitor |
| prometheus.serviceMonitor.interval | string | `"15s"` | Scrape interval. If not set, defaults to 15s |
| prometheus.serviceMonitor.labels | object | `{"prometheus":"prometheus-operator-prometheus"}` | Map of labels to apply to the servicemonitor |
| prometheus.serviceMonitor.metricRelabelings | list | `[]` | metric relabel configs to apply to samples before ingestion. |
| prometheus.serviceMonitor.namespace | string | `"monitoring"` | Namespace where the ServiceMonitor will be created (default: monitoring) |
| prometheus.serviceMonitor.relabelings | list | `[]` | Relabel configs to apply to samples before ingestion. |
| prometheus.serviceMonitor.scheme | string | `""` | HTTP scheme to use for scraping. Can be used with `tlsConfig` for example if using istio mTLS. |
| prometheus.serviceMonitor.scrapeTimeout | string | `""` | Scrape timeout. If not set, Prometheus uses its default |
| prometheus.serviceMonitor.selectorLabels | object | `{}` | Override selector labels for the ServiceMonitor (default: app: kube-ovn-controller) |
| prometheus.serviceMonitor.targetNamespace | string | `"kube-system"` | Target namespace to monitor (where kube-ovn is installed, default: kube-system) |
| prometheus.serviceMonitor.tlsConfig | object | `{}` | TLS configuration to use when scraping the endpoint. For example if using istio mTLS. Of type: https://github.com/prometheus-operator/prometheus-operator/blob/master/Documentation/api.md#tlsconfig |

## Installing the Chart

### With Helm

To install the chart with the release name `my-release`:

```bash
helm repo add ekp-helm https://edixos.github.io/ekp-helm
helm install ekp-helm/kube-ovn-v2
```

### With ArgoCD

Add new application as:

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: kube-ovn-v2
spec:
  project: infra

  source:
    repoURL: "https://edixos.github.io/ekp-helm"
    targetRevision: "0.1.12"
    chart: kube-ovn-v2
    path: ''
    helm:
      values: |

  destination:
    server: https://kubernetes.default.svc
    namespace: "cnrm-system"
  syncPolicy:
    automated:
      prune: true
```

## Develop

### Update documentation

Chart documentation is generated with [helm-docs](https://github.com/norwoodj/helm-docs) from `values.yaml` file.
After file modification, regenerate README.md with command:

```bash
docker run --rm -it -v $(pwd):/helm --workdir /helm jnorwood/helm-docs:v1.14.2 helm-docs
```

### Run linter

```bash
docker run --rm -it -w /charts -v $(pwd)/../../:/charts quay.io/helmpack/chart-testing:v3.12.0 ct lint --charts /charts/charts/kube-ovn-v2 --config /charts/charts/kube-ovn-v2/ct.yaml
```

### Run pluto

In order to check if the api-version used in this chart are not deprecated, or worse, removed, we use pluto to check it:

```
docker run --rm -it -v $(pwd):/apps -v pluto:/pluto alpine/helm:3.17 template kube-ovn-v2 . -f tests/pluto/values.yaml --output-dir /pluto
docker run --rm -it -v pluto:/data us-docker.pkg.dev/fairwinds-ops/oss/pluto:v5 detect-files -d /data -o yaml --ignore-deprecations -t "k8s=v1.31.0,cert-manager=v1.17.0,istio=v1.24.0" -o wide
docker volume rm pluto
```

